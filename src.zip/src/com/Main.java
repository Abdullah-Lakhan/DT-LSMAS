package com;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.cloudbus.cloudsim.Log;
import org.junit.Test;

import com.algorithm.HCOC;
import com.algorithm.IHEFT;
import com.algorithm.MyScheduler;
import com.algorithm.Private;
import com.algorithm.SSPPH;
import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.constant.NodeType;
import com.engine.MyEngine;
import com.generator.sparkapp.AbstractGenerateSparkApp;
import com.generator.sparkapp.GenerateCyberShakeSparkApp;
import com.generator.sparkapp.GenerateGenomeSparkApp;
import com.generator.sparkapp.GenerateLigoSparkApp;
import com.generator.sparkapp.GenerateMontageSparkApp;
import com.generator.sparkapp.GenerateSiphtSparkApp;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;
import com.result.Result;
import com.utils.CalculateUtils;
import com.utils.Print;
import com.utils.RandomNumberUtils;
import com.utils.SparkAppUtils;

public class Main {

	static DecimalFormat df = new DecimalFormat("#.00");

	@Test
	public void test() {
		System.out.println(new DecimalFormat("#.00").format(3.1415926));
		System.out.println(Double.valueOf(new DecimalFormat("#.00").format(0)));
		System.out.println(Math.random());
		double num = Math.random();
		System.out.println(CalculateUtils.compareDouble(num, 0.2) < 0);
	}

	public static void main(String[] args) {
		try {
//			testPrivateNumber();
//			correct(); // 取值范围：1，2，3
//			correctSD(); // 取值范围：1，2，3
//			compare();
			compareCyberShake();
//			compareMontage();
//			compareGenome();
//			compareSipht();
//			compareLigo();
			// launch();
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("The simulation has been terminated due to an unexpected error");
		}
	}

	private static void compareLigo() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				AbstractGenerateSparkApp sparkApp = new GenerateLigoSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_LIGO, Constant.NUM_OF_JOBS[i],
						instance);
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				
//				SparkApplication application = new SparkApplication(Constant.NUM_OF_JOBS[i], instance, 1);
				
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

				// 初始化任务
				if (application == null) {
					throw new Exception();
				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results, Constant.SPARK_LIGO);
		results.clear();
		System.out.println("finish");
		
	}
	
	private static void compareCyberShake() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				AbstractGenerateSparkApp sparkApp = new GenerateCyberShakeSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE, Constant.NUM_OF_JOBS[i],
						instance);
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				
//				SparkApplication application = new SparkApplication(Constant.NUM_OF_JOBS[i], instance, 1);
				
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

				// 初始化任务
				if (application == null) {
					throw new Exception();
				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results);
		results.clear();
		System.out.println("finish");
		
	}

	private static void compareMontage() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				AbstractGenerateSparkApp sparkApp = new GenerateMontageSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_MONTAGE, Constant.NUM_OF_JOBS[i],
						instance);
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				
//				SparkApplication application = new SparkApplication(Constant.NUM_OF_JOBS[i], instance, 2);
				
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

				// 初始化任务
				if (application == null) {
					throw new Exception();
				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results);
		results.clear();
		System.out.println("finish");
	}

	/**
	 * Sipht类型科学工作流算法比较 
	 * @throws Exception 
	 */
	private static void compareSipht() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				// 生成工作流
				AbstractGenerateSparkApp sparkApp = new GenerateSiphtSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_SIPHT, Constant.NUM_OF_JOBS[i],
						instance);
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				
//                SparkApplication application = new SparkApplication(Constant.NUM_OF_JOBS[i], instance, 4);
				
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

//				// 初始化任务
//				if (application == null) {
//					throw new Exception();
//				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results);
		results.clear();
		System.out.println("finish");
		
	}

	/**
	 * Genome类型科学工作流算法比较
	 * @throws Exception 
	 */
	private static void compareGenome() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				AbstractGenerateSparkApp sparkApp = new GenerateGenomeSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_GENOME, Constant.NUM_OF_JOBS[i],
						instance);
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				
//                SparkApplication application = new SparkApplication(Constant.NUM_OF_JOBS[i], instance, 3);
				
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

				// 初始化任务
				if (application == null) {
					throw new Exception();
				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results);
		results.clear();
		System.out.println("finish");
	}

	/**
	 * 测试私有云中虚拟机数量
	 * 
	 * @throws Exception
	 */
	private static void testPrivateNumber() throws Exception {
		// TODO Auto-generated method stub
		// 测试在Job数量为15时的私有云虚拟机个数最大值。（即满足2.0截止期约束）
		//
		int jobnumber = 15;
		double theta = 2;
//		AbstractGenerateSparkApp sparkApp = new GenerateMontageSparkApp();
//		String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_MONTAGE, jobnumber, 0);
		String filename = "E:\\paper\\data\\Spark应用\\montage\\jobNumber_15/app_0.xml";

		// 初始化任务
		SparkApplication application = SparkAppUtils.getSparkApp(filename);
//		SparkApplication application = getSparkApplication();
		if (application == null) {
			throw new Exception();
		}
		double makespan = getEFT(application);
		double deadline = theta * makespan;
		// 设置截止期
		application.setDeadline(deadline);

		// 初始化资源
		int privateNumber = 0;
		MyResourcePool resourcePool = new MyResourcePool();
		initResources(resourcePool, privateNumber);
		// 应用调度
		MyScheduler scheduler = null;
		scheduler = new Private();

		MyEngine engine = new MyEngine(resourcePool, application, scheduler);
		engine.process();
		// 获得需要的私有云虚拟机个数
		System.out.println("完工时间：" + scheduler.getMakespan());
		System.out.println("截止期：" + deadline);
		System.out.println("需要的私有云虚拟机个数：" + scheduler.resourcePool.getPrivateCloud().size());
	}

	//
	private static void correct() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				// 生成多个Spark应用实例
				// int instance = 0;
				AbstractGenerateSparkApp sparkApp = new GenerateCyberShakeSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE, Constant.NUM_OF_JOBS[i],
						instance);

				// 初始化任务
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				if (application == null) {
					throw new Exception();
				}
				//
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);

						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 至此，生成了一个确定的实例；RPD是要针对算法的参数来计算的
						for (int SS = 1; SS <= 3; SS++) {
							for (int RSS = 1; RSS <= 3; RSS++) {
								for (int PSS = 1; PSS <= 3; PSS++) {
									for (int SD = 1; SD <= 3; SD++) {
										double startTime = System.currentTimeMillis();
										MyScheduler scheduler = null;
										scheduler = new SSPPH();
										Map<String, Integer> map = new HashMap<>();
										map.put("SD", SD);
										map.put("SS", SS);
										map.put("PSS", PSS);
										map.put("RSS", RSS);
										MyEngine engine = new MyEngine(resourcePool, application, scheduler);
										engine.process(map);
										double endTime = System.currentTimeMillis();
										result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, SD,
												SS, RSS, PSS, scheduler.getMakespan(), scheduler.getCost(),
												endTime - startTime);
										tempResults.add(result);
										// 重置应用
										application.reset();
										// 重置租赁资源信息
										resourcePool.reset();
									}
								}
							}
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
			}
		}
		Print print = new Print();
		print.exportToExcel_TS(results, "参数测定");
		results.clear();
		System.out.println("finish");
	}

//	//
//	private static void correctSD() throws Exception {
//		// 记录结果
//		List<Result> results = new ArrayList<Result>();
//		List<Result> tempResults = new ArrayList<Result>();
//		Result result;
//
//		// 单次生成一个工作流，解析，并执行
//		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
//			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
//				AbstractGenerateSparkApp sparkApp = new GenerateCyberShakeSparkApp();
//				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE, Constant.NUM_OF_JOBS[i],
//						instance);
//
//				// 初始化任务
//				SparkApplication application = SparkAppUtils.getSparkApp(filename);
//				if (application == null) {
//					throw new Exception();
//				}
//				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
//						double theta = Constant.TIME_OF_DEADLINE[j];
//						double makespan = getEFT(application);
//						double deadline = theta * makespan;
//						// 设置截止期
//						application.setDeadline(deadline);
//
//						// 初始化资源
//						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						MyResourcePool resourcePool = new MyResourcePool();
//						initResources(resourcePool, privateNumber);
//
//						// 参数校正：SD
//						for (int SS = 1; SS <= 3; SS++) {
//							for (int RSS = 1; RSS <= 3; RSS++) {
//								for (int PSS = 1; PSS <= 3; PSS++) {
//									for (int SD = 1; SD <= 3; SD++) {
//										double startTime = System.currentTimeMillis();
//										MyScheduler scheduler = null;
//										scheduler = new RBSAS();
//										MyEngine engine = new MyEngine(resourcePool, application, scheduler);
//										engine.process();
//										double endTime = System.currentTimeMillis();
//										result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, SD,
//												SS, RSS, PSS, scheduler.getMakespan(), scheduler.getCost(),
//												endTime - startTime);
//										tempResults.add(result);
//										// 重置应用
//										application.reset();
//										// 重置租赁资源信息
//										resourcePool.reset();
//									}
//									results.addAll(getRPD(tempResults));
//									tempResults.clear();
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//		Print print = new Print();
//		print.exportToExcel_TS(results, "参数测定SD");
//		results.clear();
//		System.out.println("finish");
//	}

	/**
	 * 启动调度 如果要实现多轮实验的话，可在launch中设置循环
	 * 
	 * @throws Exception
	 */
	private static void compare() throws Exception {
		// 记录结果
		List<Result> results = new ArrayList<Result>();
		List<Result> tempResults = new ArrayList<Result>();
		Result result;

		// 单次生成一个工作流，解析，并执行
		for (int i = 0; i < Constant.NUM_OF_JOBS.length; i++) {
			for (int instance = 0; instance < Constant.INSTANCE_NUM; instance++) {
				// 生成两种科学工作流//
				AbstractGenerateSparkApp sparkApp = new GenerateCyberShakeSparkApp();
				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE, Constant.NUM_OF_JOBS[i],
						instance);
//				AbstractGenerateSparkApp sparkApp = new GenerateMontageSparkApp();
//				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_MONTAGE, Constant.NUM_OF_JOBS[i],
//						instance);
//				AbstractGenerateSparkApp sparkApp = new GenerateGenomeSparkApp();
//				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_GENOME, Constant.NUM_OF_JOBS[i],
//						instance);
//				AbstractGenerateSparkApp sparkApp = new GenerateSiphtSparkApp();
//				String filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_SIPHT, Constant.NUM_OF_JOBS[i],
//						instance);
//				for (int type = 0; type < Constant.TYPE_NUM.length; type++) {
//					AbstractGenerateSparkApp sparkApp = null;
//					String filename = new String();
//					switch (Constant.TYPE_NUM[type]) {
//					case 0: {
//						sparkApp = new GenerateCyberShakeSparkApp();
//						filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE, Constant.NUM_OF_JOBS[i],
//								instance);
//						break;
//					}
//					case 1: {
//						sparkApp = new GenerateMontageSparkApp();
//						filename = sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_MONTAGE, Constant.NUM_OF_JOBS[i],
//								instance);
//						break;
//					}
//					}
				// 确定私有云中虚拟机数量上限
//				int highLevel = calHighLevel();

				// 初始化任务
				SparkApplication application = SparkAppUtils.getSparkApp(filename);
				if (application == null) {
					throw new Exception();
				}
				for (int p = 0; p < Constant.PRIVATE_VM_NUM.length; p++) {
//				for (int p = 0; p < Constant.PRIVATE_VM_FACTOR.length; p++) {
					for (int j = 0; j < Constant.TIME_OF_DEADLINE.length; j++) {
						double theta = Constant.TIME_OF_DEADLINE[j];
						double makespan = getEFT(application);
						double deadline = theta * makespan;
						// 设置截止期
						application.setDeadline(deadline);
						// 初始化资源
						int privateNumber = (int) Constant.PRIVATE_VM_NUM[p];
//						int privateNumber = (int) (highLevel * Constant.PRIVATE_VM_FACTOR[p]);
						MyResourcePool resourcePool = new MyResourcePool();
						initResources(resourcePool, privateNumber);

						// 算法比较
						for (int Algorithm = 1; Algorithm <= 3; Algorithm++) {
							double startTime = System.currentTimeMillis();
							MyScheduler scheduler = compareAlgorithm(application, deadline, Algorithm, resourcePool);
							double endTime = System.currentTimeMillis();
							result = new Result(Constant.NUM_OF_JOBS[i], theta, privateNumber, instance, Algorithm,
									scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
							tempResults.add(result);
							// 重置应用
							application.reset();
							// 重置租赁资源信息
							resourcePool.reset();
						}
						results.addAll(getRPD(tempResults));
						tempResults.clear();
					}
				}
//				}
			}
		}
		Print print = new Print();
		print.exportToExcel_Node(results);
		results.clear();
		System.out.println("finish");
	}

	/**
	 * 计算私有云中虚拟机数量上限
	 * @return
	 */
	private static int calHighLevel() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * 算法比较
	 * 
	 * @param application
	 * @param deadline
	 * @param Algorithm
	 * @param resourcePool
	 * @return
	 */
	private static MyScheduler compareAlgorithm(SparkApplication application, double deadline, int Algorithm,
			MyResourcePool resourcePool) {
		MyScheduler scheduler = null;
		switch (Algorithm) {
		case 1:
			Map<String, Integer> map = new HashMap<>();
			map.put("SD", 1);
			map.put("SS", 1);
			map.put("PSS", 1);
			map.put("RSS", 1);
			scheduler = new SSPPH();
			MyEngine engine = new MyEngine(resourcePool, application, scheduler);
			engine.process(map);
			break;
		case 2:
			scheduler = new IHEFT();
			MyEngine engine2 = new MyEngine(resourcePool, application, scheduler);
			engine2.process();
			break;
		case 3:
			scheduler = new HCOC();
			MyEngine engine3 = new MyEngine(resourcePool, application, scheduler);
			engine3.process();
			break;
		default:
			scheduler = new SSPPH();
			MyEngine engine4 = new MyEngine(resourcePool, application, scheduler);
			engine4.process();
		}
//		MyEngine engine = new MyEngine(resourcePool, application, scheduler);
//		engine.process();
		return scheduler;
	}

	/**
	 * 计算此次任务和资源状态下，调度结果的RPD
	 * 
	 * @param tempResults
	 * @return
	 */
	private static List<Result> getRPD(List<Result> results) {
		double minCost = getMinCost(results);
		for (Result result : results) {
			result.RPD = (result.cost - minCost) / minCost;
			try {
				result.RPD = Double.valueOf(df.format(result.RPD));
			} catch (NumberFormatException e) {
				e.printStackTrace();
				System.out.println(result);
			}
		}
		return results;
	}

	/**
	 * 获得本次调度中，不同结果中的最小租赁成本
	 * 
	 * @param results
	 * @return
	 */
	private static double getMinCost(List<Result> results) {
		double minCost = Double.MAX_VALUE;
		for (Result result : results) {
			if (minCost > result.cost) {
				minCost = result.cost;
			}
		}
		return minCost;
	}

	/**
	 * 计算该Spark应用的最早结束时间，作为截止期设定的参数
	 * 
	 * @param application
	 * 
	 * @return
	 */
	private static double getEFT(SparkApplication application) {
		SparkApplication app = application;
		// 0. 最快执行速度和最快带宽
		double v = Constant.highVM.getProcessSpeed();
		double bw = Math.max(Constant.BANDWIDTH_INTER, Constant.BANDWIDTH_INTRA);

		// 1. 估计任务执行时间，Stage执行时间
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				double max = Double.MIN_VALUE;
				for (int k = 0; k < stage.taskNum; k++) {
					Task task = stage.taskList.get(k);
					task.setEstimateProcessTime(task.instructions / v); // 时间单位为秒
					Map<Task, Integer> map = task.getPrecursorTask();
					double transmissionTime = Double.MIN_VALUE;
					for (Entry<Task, Integer> entry : map.entrySet()) {
						double tmp = entry.getValue() / bw;
						transmissionTime = Math.max(transmissionTime, tmp);
					}
					task.setEstimateTotalTime(task.getEstimateProcessTime() + transmissionTime);
					max = Math.max(max, task.getEstimateTotalTime());
				}
				stage.estimateDuration = max;
			}
		}

		// 2. 估计Job、Stage最早时间参数
		double maxEFT = Double.MIN_VALUE;
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			if (job.parentJobs.size() == 0) {
				job.EST = 0;
			} else {
				List<Job> parentJobs = job.parentJobs;
				double max = Double.MIN_VALUE;
				for (Job parent : parentJobs) {
					max = Math.max(max, parent.EFT);
				}
				job.EST = max;
			}
			// 更新其中Stage的时间参数
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				if (stage.parentStages.size() == 0) {
					stage.EST = stage.job.EST;
				} else {
					List<Stage> parentStages = stage.parentStages;
					double max = Double.MIN_VALUE;
					for (Stage parent : parentStages) {
						max = Math.max(max, parent.EFT);
					}
					stage.EST = max;
				}
				stage.EFT = stage.EST + stage.estimateDuration;
				maxEFT = Math.max(maxEFT, stage.EFT);
			}
			job.EFT = maxEFT;
		}
		return maxEFT;
	}

	/**
	 * 初始化资源
	 * 
	 * @param privateNumber
	 */
	private static void initResources(MyResourcePool resourcePool, int privateNumber) {
		// 初始化云中资源
		List<MyVM> list = initPrivateCloud(privateNumber);
		resourcePool.setPrivateCloud(list);
		List<MyVMType> typeList = initPublicCloud();
		resourcePool.setPublicVMType(typeList);
		resourcePool.setRentVm(new ArrayList<MyVM>()); // 已租赁资源为空
	}

	/**
	 * 初始化私有云资源
	 * 
	 * @param privateNumber
	 * 
	 * @return 私有云资源列表
	 */
	private static List<MyVM> initPrivateCloud(int privateNumber) {
		List<MyVM> list = new ArrayList<>();
		// 私有云中机器个数
		// int count = RandomNumberUtils.getRandomNumber(Constant.PRIVATE_VM_MIN,
		// Constant.PRIVATE_VM_MAX);
		int count = privateNumber;
		for (int i = 0; i < count; i++) {
			MyVM vm = new MyVM();
			vm.setVmId(i);
			vm.setBelongCloud(Constant.PRIVATE_CLOUD);
			// 随机确定机器的执行速度、单位租赁时间和单位租赁价格
			int typeNum = RandomNumberUtils.getRandomNumber(1, 3);
			MyVMType type = null;
			switch (typeNum) {
			case 1: {
				type = new MyVMType(NodeType.PROCESS_RATE_1, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_LOW_LEVLEL);
				break;
			}
			case 2: {
				type = new MyVMType(NodeType.PROCESS_RATE_2, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_MID_LEVLEL);
				break;
			}
			case 3: {
				type = new MyVMType(NodeType.PROCESS_RATE_3, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_HIGH_LELVEL);
				break;
			}
			default: {
				// 默认是第二种类型机器
				type = new MyVMType(NodeType.PROCESS_RATE_2, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_MID_LEVLEL);
			}
			}
			// 根据VM类型初始化VM
			vm.initByVMType(type);
			list.add(vm);
		}

		return list;
	}

	/**
	 * 初始化公有云资源
	 * 
	 * @return 公有云中资源类型列表
	 */
	private static List<MyVMType> initPublicCloud() {
		List<MyVMType> list = new ArrayList<>();
		list.add(new MyVMType(NodeType.PROCESS_RATE_1, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_LOW_LEVLEL));
		list.add(new MyVMType(NodeType.PROCESS_RATE_2, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_MID_LEVLEL));
		list.add(new MyVMType(NodeType.PROCESS_RATE_3, NodeType.RENT_UNIT_HOUR, NodeType.PRICE_HIGH_LELVEL));
		return list;
	}

	/**
	 * 手工构造的SparkApplication，用于验证代码正确性
	 * 
	 * @return
	 */
	private static SparkApplication getSparkApplication() {
		SparkApplication app = new SparkApplication();
		Job job1 = new Job();
		Job job2 = new Job();
		job1.jobid = 1;
		job2.jobid = 2;
		job1.childJobs.add(job2);
		job2.parentJobs.add(job1);
		app.jobList.add(job1);
		app.jobList.add(job2);
		app.reverseJobList.add(job2);
		app.reverseJobList.add(job1);
		app.jobNum = 2;

		Stage stage11 = new Stage(job1);
		Stage stage12 = new Stage(job1);
		Stage stage13 = new Stage(job1);
		// Stage stage14 = new Stage(job1);

		stage11.stageid = 11;
		stage12.stageid = 12;
		stage13.stageid = 13;
		// stage14.stageid = 14;
		stage11.childStages.add(stage13);
		stage12.childStages.add(stage13);
		stage13.parentStages.add(stage11);
		stage13.parentStages.add(stage12);
		// stage13.childStages.add(stage14);
		// stage14.parentStages.add(stage13);

		Stage stage21 = new Stage(job2);
		stage21.stageid = 21;
		job1.stageList.add(stage11);
		job1.stageList.add(stage12);
		job1.stageList.add(stage13);
		// job1.stageList.add(stage14);
		// job1.reverseStageList.add(stage14);
		job1.reverseStageList.add(stage13);
		job1.reverseStageList.add(stage12);
		job1.reverseStageList.add(stage11);
		// job1.stageNum = 4;
		job1.stageNum = 3;

		job2.stageList.add(stage21);
		job2.reverseStageList.add(stage21);
		job2.stageNum = 1;

		double instruction = 100;
		Task task111 = new Task(stage11, instruction);
		Task task112 = new Task(stage11, instruction);
		task111.taskid = 111;
		task112.taskid = 112;

		Task task121 = new Task(stage12, instruction);
		Task task122 = new Task(stage12, instruction);
		Task task123 = new Task(stage12, instruction);
		Task task124 = new Task(stage12, instruction);
		task121.taskid = 121;
		task122.taskid = 122;
		task123.taskid = 123;
		task124.taskid = 124;

		Task task131 = new Task(stage13, instruction);
		Task task132 = new Task(stage13, instruction);
		task131.taskid = 131;
		task132.taskid = 132;

		// Task task141 = new Task(stage14, instruction);
		// Task task142 = new Task(stage14, instruction);
		// task141.taskid = 141;
		// task142.taskid = 142;

		Task task211 = new Task(stage21, instruction);
		Task task212 = new Task(stage21, instruction);
		task211.taskid = 211;
		task212.taskid = 212;

		task111.setSensitiveTask(true);
		task121.setSensitiveTask(true);
		task123.setSensitiveTask(true);
		task131.setSensitiveTask(true);
		task211.setSensitiveTask(true);
		// task141.setSensitiveTask(true);

		int data = 200;
		task111.successorTask.put(task131, data);
		task112.successorTask.put(task132, data);
		task121.successorTask.put(task131, data);
		task122.successorTask.put(task132, data);
		task123.successorTask.put(task131, data);
		task124.successorTask.put(task132, data);
		// task131.successorTask.put(task141, data);
		// task132.successorTask.put(task142, data);

		task131.getPrecursorTask().put(task111, data);
		task131.getPrecursorTask().put(task121, data);
		task131.getPrecursorTask().put(task123, data);

		task132.getPrecursorTask().put(task112, data);
		task132.getPrecursorTask().put(task122, data);
		task132.getPrecursorTask().put(task124, data);

		// task141.getPrecursorTask().put(task131, data);
		// task142.getPrecursorTask().put(task132, data);

		stage11.taskList.add(task111);
		stage11.taskList.add(task112);
		stage11.taskNum = 2;

		stage12.taskList.add(task121);
		stage12.taskList.add(task122);
		stage12.taskList.add(task123);
		stage12.taskList.add(task124);
		stage12.taskNum = 4;

		stage13.taskList.add(task131);
		stage13.taskList.add(task132);
		stage13.taskNum = 2;

		// stage14.taskList.add(task141);
		// stage14.taskList.add(task142);
		// stage14.taskNum = 2;

		stage21.taskList.add(task211);
		stage21.taskList.add(task212);
		stage21.taskNum = 2;

		return app;
	}

	/**
	 * 测试简单实例用
	 * 
	 * @throws Exception
	 */
	public static void launch() throws Exception {

		SparkApplication application;
		MyResourcePool resourcePool = new MyResourcePool();
		int jobNumber;
		int instance;
		int privateNumber = 3;
		initResources(resourcePool, privateNumber);

		int SD = 1;
		int SS = 1;
		int RSS = 1;
		int PSS = 1;

		int appId = 0; // 需要解析的sparkApp序号
		String pathName = Constant.SPARK_APP_DIR_CYBERSHAKE; // 解析文件路径
		// a question ：如何解析生成的多个文件？，可进行
		application = SparkAppUtils.getSparkApp(appId, pathName); //
		// application = getSparkApplication();
		if (application == null) {
			throw new Exception();
		}
		// Step2.1 设置截止期
		double theta = 2;
		double makespan = getEFT(application);
		// MyScheduler scheduler = new FastestScheduler();
		// MyScheduler scheduler = new RBSAS(); //
		MyScheduler scheduler = new IHEFT(); //
		// MyScheduler scheduler = new FIFO(); //
		// MyScheduler scheduler = new FAIR(); //
		// double makespan = scheduler.runSchedule(application, resourcePool);
		double D = theta * makespan;
		application.setDeadline(D);

		// Step3 初始化调度方法
		// MyScheduler scheduler = new MySchedulerImpl(); //
		// MyScheduler scheduler = new FastestScheduler();

		// Step4 启动调度
		MyEngine engine = new MyEngine(resourcePool, application, scheduler);
		double startTime = System.currentTimeMillis();
		engine.process();
		double endTime = System.currentTimeMillis();
		// Result result = new Result(jobNumber, theta, privateNumber, instance, SD, SS,
		// RSS, PSS, scheduler.getMakespan(), scheduler.getCost(), endTime - startTime);
		// tempResults.add(result);
		// results.addAll(getRPD(tempResults));

		// Print print = new Print(); // 打印结果到excel文件 TODO //
		// print.exportToExcel_TS(results, "参数测定PRER");
		// results.clear();
		// System.out.println("finish");

		printInfo(scheduler, D, application, resourcePool);

	}

	/**
	 * 打印信息，临时使用
	 * 
	 * @param scheduler
	 * @param d
	 */
	private static void printInfo(MyScheduler scheduler, double D, SparkApplication application,
			MyResourcePool resourcePool) {
		// 打印信息
		double cost = scheduler.getCost();
		double makespan = scheduler.getMakespan();
		for (Job job : application.jobList) {
			for (Stage stage : job.stageList) {
				for (Task task : stage.taskList) {
					System.out.println(job.jobid + "." + stage.stageid + "." + +task.taskid + ":" + task.getVm() + "， "
							+ task.getVm().getBelongCloud() + "," + task.getVm().getRentUnitPrice() + ",   " + task.AST
							+ " - " + task.AFT);
				}
			}
		}
		for (MyVM vm : resourcePool.getRentVm()) {
			System.out.println(vm.getStartTime() + " - " + vm.getEndTime());
		}
		System.out.println("私有云虚拟机数量：" + resourcePool.getPrivateCloud().size());
		System.out.println("租赁虚拟机数量：" + resourcePool.getRentVm().size());
		System.out.println("Deadline = " + D);
		System.out.println("Total cost = " + cost + ", Makespan = " + makespan);
	}
}
