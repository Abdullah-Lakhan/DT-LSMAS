package com.algorithm;

import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;

/**
 * 先来先服务的调度
 * 
 * @author ShirleyLee
 *
 */
public class FIFO extends MyScheduler {

	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		this.application = app;
		this.resourcePool = resourcePool;
		List<Job> jobList = app.jobList;
		// 先来先服务，即按拓扑顺序，依次调度每个Job
		double appEndTime = 0;
		for (Job job : jobList) {
			List<Stage> stageList = job.stageList;
			double jobEndTime = 0;
			for (Stage stage : stageList) {
				double stageEndTime = 0;
				List<Task> taskList = stage.taskList;
				for (Task task : taskList) {
					if (task.isSensitiveTask()) {
						stageEndTime = Math.max(stageEndTime, sensitiveTaskScheduler(task));
					} else {
						stageEndTime = Math.max(stageEndTime, nonSensitiveTaskScheduler(task));
					}
				}
				stage.scheduled = true;
				stage.setAFT(stageEndTime);
				jobEndTime = Math.max(jobEndTime, stage.getAFT());
				UpdateEST(stage);
			}
			job.setAFT(jobEndTime);
			appEndTime = Math.max(appEndTime, job.getAFT());
		}
		app.setAFT(appEndTime);
		this.setMakespan(appEndTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
		return app.getAFT();
	}

	/**
	 * 隐私任务调度：最早结束时间优先
	 * 
	 * @param task
	 * @return 任务完成时间
	 */
	private double sensitiveTaskScheduler(Task task) {
		List<MyVM> list = resourcePool.getPrivateCloud();
		double min = Double.POSITIVE_INFINITY;
		MyVM select = list.get(0);
		for (MyVM vm : list) {
			double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double endTime = startTime + transmissionTime + executionTime;
			if (endTime < min) {
				min = endTime;
				select = vm;
			}
		}
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 非隐私任务调度：私有云中当前可用，否则租赁新机器
	 * 
	 * @param task
	 * @return
	 */
	private double nonSensitiveTaskScheduler(Task task) {
		double startTime = task.stage.EST;
		MyVM select = null;
		// 1.利用已租赁机器
		List<MyVM> rentList = resourcePool.getRentVm();
		for (MyVM vm : rentList) {
			if (vm.getAvailTime() <= startTime) {
				select = vm;
				break;
			}
		}
		// 2. 利用私有云
		if (select == null) {
			List<MyVM> list = resourcePool.getPrivateCloud();
			for (MyVM vm : list) {
				if (vm.getAvailTime() <= startTime) {
					select = vm;
					break;
				}
			}
		}
		// 3.租赁新机器
		if (select == null) {
			// 租赁
			MyVM vm = new MyVM(Constant.lowVM);
			resourcePool.getRentVm().add(vm);
			select = vm;
		}
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 更新后继的EST
	 * 
	 * @param stage
	 */
	private void UpdateEST(Stage stage) {
		if (stage.childStages.size() == 0) {
			for (Job job : stage.job.childJobs) {
				HashSet<Stage> startStages = job.getStartStage();
				for (Stage tmpstage : startStages) {
					tmpstage.EST = 0;
					for (Job preJob : job.parentJobs) {
						HashSet<Stage> endstages = preJob.getEndStage();
						for (Stage prestage : endstages) {
							if (prestage.scheduled) {
								tmpstage.EST = Math.max(tmpstage.EST, prestage.getAFT());
							} else {
								tmpstage.EST = Math.max(tmpstage.EST, prestage.EFT);
							}
						}
					}
				}
			}
		} else {
			for (Stage tmpstage : stage.childStages) {
				tmpstage.EST = 0;
				for (Stage prestage : tmpstage.parentStages) {
					if (prestage.scheduled) {
						tmpstage.EST = Math.max(tmpstage.EST, prestage.getAFT());
					} else {
						tmpstage.EST = Math.max(tmpstage.EST, prestage.EFT);
					}
				}
			}
		}
	}

	/**
	 * 计算数据传输时间
	 * 
	 * @param task
	 * @param cloudTag 当前任务分配到云的标号
	 * @return
	 */
	private double calTransmissionTime(Task task, int cloudTag) {
		double transmissionTime = 0;
		if (task.getPrecursorTask().size() == 0)
			return 0;
		for (Entry<Task, Integer> entry : task.getPrecursorTask().entrySet()) {
			MyVM vm = entry.getKey().getVm();
			double tmp = entry.getValue()
					/ (vm.getBelongCloud() == cloudTag ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER);
			transmissionTime = Math.max(transmissionTime, tmp);
		}
		// d 计算从私有云传输到该Task的时间
		transmissionTime = Math.max(transmissionTime, task.getRemainData()
				/ (cloudTag == Constant.PRIVATE_CLOUD ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER));
		return transmissionTime;
	}

	/**
	 * 更新租赁的虚拟机信息、任务执行信息
	 * 
	 * @param task
	 * @param vm
	 */
	private double updateInfo(Task task, MyVM vm) {
		// 1. 建立映射关系
		task.setVm(vm);
		vm.getTasks().add(task);
		// 2.更新时间参数
		double startTime = 0;
		if (vm.getAvailTime() == 0) {
			startTime = task.stage.EST;
		} else {
			startTime = Math.max(vm.getAvailTime(), task.stage.EST);
		}
		double transmissionTime = calTransmissionTime(task, vm.getBelongCloud());
		double executionTime = task.instructions / vm.getProcessSpeed();
		double endTime = startTime + transmissionTime + executionTime;
		vm.setAvailTime(endTime);
		if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
			double rentEndTime = Math.ceil((endTime - startTime) / 3600.0) * 3600 + startTime;
			vm.setStartTime(startTime);
			vm.setEndTime(rentEndTime);
		}
		task.setAST(startTime);
		task.setAFT(endTime);
		return endTime;
	}
}
