package com.algorithm;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.Period;

/**
 * 最快调度方法：计算deadline
 * 隐私任务：放到私有云中可用时间+执行时间最小的
 * 非隐私任务：如果私有云中有可用的，则选择最快的；如果没有，则租赁最快的机器
 * @author ShirleyLee
 *
 */
public class FastestScheduler extends MyScheduler {

	// private SparkApplication application;
	// private MyResourcePool resourcePool;
	private double latestFinishTime; // 在该调度算法下，所有任务完成的最晚时间；在每个任务完成调度后更新

	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		this.application = app;
		this.resourcePool = resourcePool;
		double startTime = System.currentTimeMillis();
		// 执行调度过程
		HashSet<Stage> readyStages = addStartStages(application);
		// 计算时间参数
		calTimeParamters(application, readyStages);
		while (!readyStages.isEmpty()) {
			Stage stage = highestPriorityStage(readyStages);
			stageSchedule(stage);
			readyStages.remove(stage);
			stage.scheduled = true; // 标记该Stage已调度，用于添加后继Stage
			// 添加后继Stage
			addSuccessorStage(stage, readyStages);
		}
		// 记录调度结束时间
		double endTime = System.currentTimeMillis();
		this.setTimeCost(endTime - startTime);
		// 更新调度器的makespan = 最后一个任务的结束时间 - 第一个任务的开始时间（0）
		this.setMakespan(this.latestFinishTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
		return 0;
	}

	/**
	 * Stage调度
	 * @param stage
	 */
	private void stageSchedule(Stage stage) {
		List<Task> taskList = stage.taskList;
		// 任务排序：隐私性大于非隐私性；输入数据量大大于输入数据量小的
		Collections.sort(taskList, new Comparator<Task>() {
			@Override
			public int compare(Task task1, Task task2) {
				if(task1.isSensitiveTask() == task2.isSensitiveTask()) {
					return (int) (task2.totalInputData - task1.totalInputData);
				}else {
					return task1.isSensitiveTask() ? -1 : 1;
				}
			}
		});
		for (int i = 0; i < taskList.size(); i++) {
			Task cur = taskList.get(i);
			if (cur.isSensitiveTask()) {
				sensitiveTaskSchedule(cur);
			} else {
				nonSensitiveTaskSchedule(cur);
			}
			// 更新任务的最晚完成时间
			this.latestFinishTime = Math.max(latestFinishTime, cur.AFT);
		}
	}
	
	/**
	 * 非敏感任务调度
	 * 策略：检查私有云中有无可用VM，使用最快的；无：租最快的 
	 * @param cur
	 */
	private void nonSensitiveTaskSchedule(Task task) {
		List<MyVM> list = this.resourcePool.getPrivateCloud();
		MyVM selectVM = null;
		// TODO 任务开始时间存疑：是否将数据传输时间计算在内？
		double taskStartTime = task.stage.EST; // 任务开始时间取其所在Stage的开始时间
		// 遍历私有云中VM，找可用时间小于任务开始时间的VM
		for(int i = 0; i < list.size(); i++) {
			MyVM cur = list.get(i);
			if(cur.getAvailTime() < taskStartTime) {
				if(selectVM == null) {
					selectVM = cur;
				}else {
					if(cur.getAvailTime() + calProcessTime(task, cur) 
						< selectVM.getAvailTime() + calProcessTime(task, selectVM)) {
						selectVM = cur;  
					}
				}
			}
		}
		// 如果私有云无合适VM
		if(selectVM == null) {
			// 租公有云最快的VM
			MyVM vm = new MyVM(Constant.highVM);
			vm.setStartTime(taskStartTime);
			vm.setAvailTime(taskStartTime);
			double transferTime = calTransferTime(task, vm);
			double processTime = calProcessTime(task, vm);
			vm.setEndTime(taskStartTime + transferTime + processTime); // vm截止时间
			vm.setMap(new HashMap<Task, Period>()); // 任务和使用时间阶段映射结构初始化
			resourcePool.getRentVm().add(vm);// 添加该VM到已租赁资源中
			// 选中当前虚拟机
			selectVM = vm;
		}
		// 建立映射关系
		mapTaskAndVM(task, selectVM);
	}

	/**
	 * 敏感任务调度
	* 策略：选择最早可用时间+执行时间最早的VM
	 * @param task
	 */
	private void sensitiveTaskSchedule(Task task) {
		// 获得私有云中VM列表
		List<MyVM> list = this.resourcePool.getPrivateCloud();
		MyVM selectVM = list.get(0);
		double earlistTime = selectVM.getAvailTime() + calProcessTime(task, selectVM);
		for(int i = 1; i < list.size(); i++) {
			MyVM cur = list.get(i);
			double curTime = cur.getAvailTime() + calProcessTime(task, cur);
			if(curTime < earlistTime) {
				selectVM = cur;
				earlistTime = curTime;
			}
		}
		mapTaskAndVM(task, selectVM);
	}

	private Stage highestPriorityStage(HashSet<Stage> readyStages) {
		double max = Double.MIN_VALUE;
		Stage stage = null;
		for (Stage cur : readyStages) {
			double curAmount = 0;
			List<Task> taskList = cur.taskList;
			for (Task task : taskList) {
				curAmount += task.totalInputData;
			}
			if (curAmount > max) {
				stage = cur;
			}
		}
		return stage;
	}

}
