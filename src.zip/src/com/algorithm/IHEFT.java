package com.algorithm;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import com.algorithm.stageSequence.MaxRankFirstSequence;
import com.algorithm.stageSequence.StageSequence;
import com.algorithm.subDeadline.AbstractSubDeadline;
import com.algorithm.subDeadline.LevelBasedSubDeadline;
import com.algorithm.subDeadline.PathBasedSubDeadline;
import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;

/**
 * 著名的HEFT： 1）任务排序：按照UpRank递减排序 2）任务调度：选择最小化结束时间的虚拟机
 * 3）改进：多数据中心（私有云、混合云）；增加隐私任务的特殊处理
 * 疑问：如何将其改成最小化成本的算法？利用它提出的可以将任务放在虚拟机上两个已调度的任务之间，尽量减少租赁机器个数 先写。
 * 
 * @author ShirleyLee
 *
 */
public class IHEFT extends MyScheduler {

	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		// TODO Auto-generated method stub
		this.application = app;
		this.resourcePool = resourcePool;
		// Step1 获得调度序列，静态调度序列
		List<Stage> stageList = new LinkedList<>();
		// 竟然体会到了一把Java的值传递，其实我是懵的
		stageList = getNodePriority();
		
		// Step2 按序调度
		double appEndTime = 0;
		for (Stage stage : stageList) {
			List<Task> taskList = stage.taskList;
			Collections.sort(taskList, new Comparator<Task>() {
				@Override
				public int compare(Task task1, Task task2) {
					if (task1.isSensitiveTask() == task2.isSensitiveTask()) {
						if (task1.instructions >= task2.instructions) {
							return -1;
						} else {
							return 1;
						}
					} else {
						return task1.isSensitiveTask() ? -1 : 1;
					}
				}
			});
			double stageEndTime = 0;
			for (Task task : taskList) {
				if (task.isSensitiveTask()) {
					stageEndTime = Math.max(stageEndTime, sensitiveTaskScheduler(task));
				} else {
					stageEndTime = Math.max(stageEndTime, nonSensitiveTaskScheduler(task));
				}
			}
			stage.scheduled = true;
			stage.setAFT(stageEndTime);
			appEndTime = Math.max(appEndTime, stage.getAFT());
			UpdateEST(stage);
		}

		// Step3 计算makespan和cost
		app.setAFT(appEndTime);
		this.setMakespan(appEndTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
		return app.getAFT();
	}

	/**
	 * 获得调度序列
	 * @return 
	 */
	private List<Stage> getNodePriority() {
		List<Stage> stageList = new LinkedList<>();
		// Step1 计算Job和Stage的UpRank
		calOtherParameter(this.application);
		
		// Step2 划分Stage层次，获得Stage调度序列
		StageSequence seq = new MaxRankFirstSequence();
		stageList = seq.sequence(this.application);
		return stageList;
	}

	/**
	 * 其他参数计算：level，slackTime，UpRank
	 * 
	 * @param app
	 */
	private void calOtherParameter(SparkApplication app) {
		// 1. 确定各个Job和Stage的level
		AbstractSubDeadline abs = new LevelBasedSubDeadline();
		abs.calJobLevelForward(app);

		// 2. 计算app的SlackTime
		double eft = Double.MIN_VALUE;
		double slackTime = Double.MIN_VALUE;
		for (Job job : app.jobList) {
			eft = Math.max(eft, job.EFT);
		}
		slackTime = app.getDeadline() - eft;
		app.setSlackTime(slackTime);

		// 3. 计算Job和Stage的UpRank值
		abs = new PathBasedSubDeadline();
		abs.calJobUpRank(app);
	}
	
	/**
	 * 非隐私任务调度
	 * 
	 * @param task
	 * @return
	 */
	private double nonSensitiveTaskScheduler(Task task) {
		// TODO 选择三种中最早结束时间的虚拟机
		double startTime = task.stage.EST;
		MyVM select = null;
		double min = Double.MAX_VALUE; // 最早结束时间
		// 1.利用已租赁机器
		// 如何利用已租赁机器：结束时间在租赁结束时间内
		List<MyVM> rentList = resourcePool.getRentVm();
		for (MyVM vm : rentList) {
			double startTime1 = Math.max(vm.getAvailTime(), startTime);
			double transmissionTime = calTransferTime(task, vm);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime1 + transmissionTime + executionTime;
			if (finishTime < vm.getEndTime()) {
				min = Math.min(min, finishTime);
				select = vm;
			}
		}
		// 2. 利用私有云
		List<MyVM> list = resourcePool.getPrivateCloud();
		for (MyVM vm : list) {
			double startTime1 = Math.max(vm.getAvailTime(), startTime);
			double transmissionTime = calTransferTime(task, vm);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime1 + transmissionTime + executionTime;
			if (finishTime < min) {
				min = finishTime;
				select = vm;
			}
		}
		// 3.租赁新机器
		// TODO 租赁，如果按最早完成时间算，租的只可能是最快机器，何解？就租最快的八
		MyVM vm = new MyVM(Constant.highVM);
		double startTime1 = Math.max(vm.getAvailTime(), startTime);
		double transmissionTime = calTransferTime(task, vm);
		double executionTime = task.instructions / vm.getProcessSpeed();
		double finishTime = startTime1 + transmissionTime + executionTime;
		if (finishTime < min) {
			min = finishTime;
			select = vm;
			resourcePool.getRentVm().add(vm);
		}
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 隐私任务调度
	 * 
	 * @param task
	 * @return
	 */
	private double sensitiveTaskScheduler(Task task) {
		List<MyVM> list = resourcePool.getPrivateCloud();
		double min = Double.POSITIVE_INFINITY;
		MyVM select = list.get(0);
		for (MyVM vm : list) {
			double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double endTime = startTime + transmissionTime + executionTime;
			if (endTime < min) {
				min = endTime;
				select = vm;
			}
		}
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 计算数据传输时间
	 * 
	 * @param task
	 * @param cloudTag 当前任务分配到云的标号
	 * @return
	 */
	private double calTransmissionTime(Task task, int cloudTag) {
		double transmissionTime = 0;
		if (task.getPrecursorTask().size() == 0)
			return 0;
		for (Entry<Task, Integer> entry : task.getPrecursorTask().entrySet()) {
			MyVM vm = entry.getKey().getVm();
			double tmp = entry.getValue()
					/ (vm.getBelongCloud() == cloudTag ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER);
			transmissionTime = Math.max(transmissionTime, tmp);
		}
		// d 计算从私有云传输到该Task的时间
		transmissionTime = Math.max(transmissionTime, task.getRemainData()
				/ (cloudTag == Constant.PRIVATE_CLOUD ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER));
		return transmissionTime;
	}

	/**
	 * 更新后继的EST
	 * 
	 * @param stage
	 */
	private void UpdateEST(Stage stage) {
		if (stage.childStages.size() == 0) {
			for (Job job : stage.job.childJobs) {
				HashSet<Stage> startStages = job.getStartStage();
				for (Stage tmpstage : startStages) {
					tmpstage.EST = 0;
					for (Job preJob : job.parentJobs) {
						HashSet<Stage> endstages = preJob.getEndStage();
						for (Stage prestage : endstages) {
							if (prestage.scheduled) {
								tmpstage.EST = Math.max(tmpstage.EST, prestage.getAFT());
							} else {
								tmpstage.EST = Math.max(tmpstage.EST, prestage.EFT);
							}
						}
					}
				}
			}
		} else {
			for (Stage tmpstage : stage.childStages) {
				tmpstage.EST = 0;
				for (Stage prestage : tmpstage.parentStages) {
					if (prestage.scheduled) {
						tmpstage.EST = Math.max(tmpstage.EST, prestage.getAFT());
					} else {
						tmpstage.EST = Math.max(tmpstage.EST, prestage.EFT);
					}
				}
			}
		}
	}

	/**
	 * 更新租赁的虚拟机信息、任务执行信息
	 * 
	 * @param task
	 * @param vm
	 */
	private double updateInfo(Task task, MyVM vm) {
		// 1. 建立映射关系
		task.setVm(vm);
		vm.getTasks().add(task);
		// 2.更新时间参数
		double startTime = 0;
		if (vm.getAvailTime() == 0) {
			startTime = task.stage.EST;
		} else {
			startTime = Math.max(vm.getAvailTime(), task.stage.EST);
		}
		double transmissionTime = calTransmissionTime(task, vm.getBelongCloud());
		double executionTime = task.instructions / vm.getProcessSpeed();
		double endTime = startTime + transmissionTime + executionTime;
		vm.setAvailTime(endTime);
		if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
			double rentEndTime = Math.ceil((endTime - startTime) / 3600.0) * 3600 + startTime;
			vm.setStartTime(startTime);
			vm.setEndTime(rentEndTime);
		}
		task.setAST(startTime);
		task.setAFT(endTime);
		return endTime;
	}
}
