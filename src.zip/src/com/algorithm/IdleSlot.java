package com.algorithm;

import com.resource.MyVM;

/**
 * 空闲时间块
 * @author ShirleyLee
 *
 */
public class IdleSlot{
	private MyVM vm; // 空闲时间块所在虚拟机
	private double startTime; // 空闲时间块开始时间
	private double endTime; // 结束时间
	public IdleSlot() {
		
	}
	public IdleSlot(double startTime, double endTime) {
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public MyVM getVm() {
		return vm;
	}
	public void setVm(MyVM vm) {
		this.vm = vm;
	}
	public double getStartTime() {
		return startTime;
	}
	public void setStartTime(double startTime) {
		this.startTime = startTime;
	}
	public double getEndTime() {
		return endTime;
	}
	public void setEndTime(double endTime) {
		this.endTime = endTime;
	}
	
}

