package com.algorithm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;
import com.resource.Period;

/**
 * 抽象调度器类
 * @author ShirleyLee
 *
 */
public abstract class MyScheduler {

	public SparkApplication application;
	public MyResourcePool resourcePool;
	
	private double makespan; // 调度结果总耗时
	private double cost; // 总租赁成本
	private double timeCost; // 调度算法运行时间

	/**
	 * 启动调度
	 * @param app
	 * @param resourcePool
	 */
    public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
    	return 0.0;
    }

	public void runSchedule(SparkApplication application, MyResourcePool resourcePool,
			Map<String, Integer> map) {
		return ;
	}
	
    /**
     * 获得租赁成本
     * @return
     */
    // public abstract double getTotalCost();

    // getter, setter
	public double getMakespan() {
		return makespan;
	}

	public void setMakespan(double makespan) {
		this.makespan = makespan;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getTimeCost() {
		return timeCost;
	}

	public void setTimeCost(double timeCost) {
		this.timeCost = timeCost;
	}
	
	/**
	 * 获得无前驱Stage集合
	 * 
	 * @param application
	 * @return
	 */
	public static HashSet<Stage> addStartStages(SparkApplication application) {
		HashSet<Stage> allReadyStages = new HashSet<Stage>();
		HashSet<Job> startJobs = application.getStartJob();
		for (Job job : startJobs) {
			HashSet<Stage> readyStages = job.getStartStage();
			for (Stage stage : readyStages) {
				allReadyStages.add(stage);
			}
		}
		return allReadyStages;
	}
	
	/**
	 * 添加后继就绪的Stage（一字未改）
	 * 
	 * @param stage       当前已调度Stage
	 * @param readyStages 就绪Stage集合
	 */
	public void addSuccessorStage(Stage stage, HashSet<Stage> readyStages) {
		// 如果该Stage的出度=0
		if (stage.outDegree == 0) {
			// 获得该Stage所在Job的EndStages
			HashSet<Stage> endstages = stage.job.getEndStage();
			for (Stage endstage : endstages) {
				// 如果存在engStage未被调度，则返回，继续调度Stage
				// （即保证只有该Stage所在Job的所有Stage完成调度，才调度该Stage所在Job的后继Job
				if (!endstage.scheduled) {
					return;
				}
			}
			// 获得该Stage所在Job的后继Job
			for (Job job : stage.job.childJobs) {
				job.tmpindegree--;
				if (job.tmpindegree == 0) {
					HashSet<Stage> stages = job.getStartStage();
					for (Stage tmpstage : stages) {
						readyStages.add(tmpstage);
					}
				}
			}
		} else {
			for (Stage tmpstage : stage.childStages) {
				tmpstage.tmpindegree--;
				if (tmpstage.tmpindegree == 0) {
					readyStages.add(tmpstage);
				}
			}
		}
	}
	

	/**
	 * 计算该调度的租赁费用
	 * @return
	 */
	
	public double calScheduleCost() {
		double sum = 0;
		// 公有云虚拟机
		List<MyVM> list = this.resourcePool.getRentVm();
		for(int i = 0; list != null && i < list.size(); i++) {
			MyVM vm = list.get(i);
			double duration = vm.getEndTime() - vm.getStartTime();
			// int range = getRangeByUnitTime(vm.getRentUnitTime());
			// 租赁时间向上取整
			sum += duration / 3600
					* vm.getRentUnitPrice();
		}
		return sum;
	}
	

	/**
	 * 根据时间单位，获得单位时间长度。如HOUR，则返回60；MINUTE，则返回1
	 * 
	 * @param rentUnitTime 租赁单位时间
	 * @return
	 */
	public int getRangeByUnitTime(String rentUnitTime) {
		switch (rentUnitTime) {
		case "HOUR":{
			return 60;
		}
		case "MINUTE": {
			return 1;
		}
		default: {
			return 60;
		}
		}
	}
	
	/**
	 * 资源和任务之间建立映射
	 * 
	 * @param task
	 * @param selectVM
	 */
	public void mapTaskAndVM(Task task, MyVM selectVM) {
		// Step1 更新Task属性
		// 计算Task的执行时间等参数
		double earlistStartTime = task.stage.EST;
		if(selectVM == null) {
			System.out.println("出现空虚拟机！吱吱吱！");
		}

		double startTime = Math.max(selectVM.getAvailTime(), earlistStartTime);
		task.AST = startTime;
		double processTime = calProcessTime(task, selectVM);
		// 数据传输时间
		double transferTime = calTransferTime(task, selectVM);
		double endTime = startTime + transferTime + processTime;
		task.AFT = endTime;
		// 任务所在VM
		task.setVm(selectVM);

		// Step2 更新VM属性：最早可用时间，与任务的匹配关系
		Map<Task, Period> map = selectVM.getMap();
		map.put(task, new Period(startTime, endTime));
		selectVM.setAvailTime(endTime);
		// 及时更新VM的endTime，（如果该VM已经被分配到最后一个属于它的VM后，endTime也随之确定了）
		selectVM.setEndTime(task.AFT);
	}
	

	/**
	 * 根据虚拟机类型，计算任务执行时间
	 * 
	 * @param cur
	 * @param type
	 * @return
	 */
	public double calProcessTime(Task cur, MyVMType type) {
		return cur.totalInputData / type.getProcessSpeed();
	}

	/**
	 * 计算任务在VM上的执行时间
	 * 
	 * @param cur
	 * @param myVM
	 * @return
	 */
	public double calProcessTime(Task cur, MyVM myVM) {
		return cur.totalInputData / myVM.getProcessSpeed();
	}
	

	/**
	 * 重载：传输时间方法 此时该VM一定是在公有云中
	 * 
	 * @param task   待调度Task
	 * @param vmType VM类型
	 * @return
	 */
	public double calTransferTime(Task task, MyVMType vmType) {
		double max = 0;
		// List<Task> taskList = task.getPrecursorTask();
		List<Task> taskList = new ArrayList<Task>(task.getPrecursorTask().keySet());
		for (int i = 0; taskList != null && i < taskList.size(); i++) {
			Task precursor = taskList.get(i);
			double cur = 0;
			// 若前驱任务所在虚拟机不在公有云
			if (precursor.getVm().getBelongCloud() != Constant.PUBLIC_CLOUD) {
				cur = task.getPrecursorTask().get(precursor) / Constant.BANDWIDTH_INTER;
			} else {
				cur = task.getPrecursorTask().get(precursor) / Constant.BANDWIDTH_INTRA;
			}
			max = Math.max(max, cur);
		}
		return max;
	}

	/**
	 * 计算当前任务的前驱数据传输到该任务的传输时间 取传输时间的最大值
	 * 
	 * @param task     当前任务
	 * @param selectVM 当前任务被调度的VM
	 * @return
	 */
	public double calTransferTime(Task task, MyVM selectVM) {
		// 遍历Task的前驱任务集合，根据前驱任务所在云和数据量，计算传输时间
		double max = 0;
		// List<Task> taskList = task.getPrecursorTask();
		List<Task> taskList = new ArrayList<Task>(task.getPrecursorTask().keySet());
		for (int i = 0; taskList != null && i < taskList.size(); i++) {
			Task precursor = taskList.get(i); // 前驱任务
			double cur = 0;
			if (precursor.getVm().getBelongCloud() != selectVM.getBelongCloud()) {
				cur = task.getPrecursorTask().get(precursor) / Constant.BANDWIDTH_INTER;
			} else if (task.getVm() == precursor.getVm()) {
				// 若在同一云中的同一VM中
				cur = 0;
			} else {
				cur = task.getPrecursorTask().get(precursor) / Constant.BANDWIDTH_INTRA;
			}
			max = Math.max(max, cur);
		}
		return max;
	}
	


	/**
	 * 
	 * @param application
	 * @param readyStages
	 */
	public static void calTimeParamters(SparkApplication application, HashSet<Stage> readyStages) {
		double appEFT = 0;
		// 求Application的EST、EFT：最早开始时间，最早结束时间
		for (Job job : application.jobList) {
			for (Stage stage : job.stageList) {
				if (stage.scheduled) // 不再处理已调度的Stage
					continue;
				if (!readyStages.contains(stage)) {
					stage.EST = 0;
					// 如果stage.indegree = 0，表示这是当前Job的entry Stage，计算其EST要通过当前Job的前驱Job来计算
					if (stage.indegree == 0) {
						for (Job preJob : job.parentJobs) {
							HashSet<Stage> endStages = preJob.getEndStage();
							for (Stage endstage : endStages) {
								if (!endstage.scheduled) {
									// 如果没有被调度过，则用父Stage的EFT估算当前Stage的EST
									stage.EST = Math.max(stage.EST, endstage.EFT);
								} else {
									//
									stage.EST = Math.max(stage.EST, endstage.endTime);
								}
							}
						}
					} else {
						// 否则，当前Stage在当前Job中有前驱Stage
						stage.EST = 0;
						for (Stage parent : stage.parentStages) {
							if (!parent.scheduled) {
								stage.EST = Math.max(stage.EST, parent.EFT);
							} else {
								stage.EST = Math.max(stage.EST, parent.endTime);
							}
						}
					}
				}
				stage.EFT = stage.EST + stage.estimateDuration;
				appEFT = Math.max(appEFT, stage.EFT);
			}
		}

		// 求LFT、LST：最晚开始时间，最晚结束时间
		for (Job job : application.reverseJobList) {
			for (Stage stage : job.reverseStageList) {
				if (stage.scheduled)
					continue;
				if (job.outDegree == 0 && stage.outDegree == 0) { // endjobs中的endstages
					stage.LFT = appEFT;
				} else {
					stage.LFT = Double.POSITIVE_INFINITY;
					if (stage.outDegree == 0) {
						for (Job sucJob : job.childJobs) {
							HashSet<Stage> startStages = sucJob.getStartStage();
							for (Stage startStage : startStages) { // stage未完成调度时，其后继一定未完成调度，所以不用像前面一样处理
								stage.LFT = Math.min(stage.LFT, startStage.LST);
							}
						}
					} else {
						for (Stage childStage : stage.childStages) {
							stage.LFT = Math.min(stage.LFT, childStage.LST);
						}
					}
				}
				stage.LST = stage.LFT - stage.estimateDuration;
			}
		}
	}

}
