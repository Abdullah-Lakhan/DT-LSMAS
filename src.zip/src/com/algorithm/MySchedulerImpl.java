package com.algorithm;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;
import com.resource.Period;

public class MySchedulerImpl extends MyScheduler {

	private double latestFinishTime; // 在该调度算法下，所有任务完成的最晚时间；在每个任务完成调度后更新

	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		this.application = app;
		this.resourcePool = resourcePool;
		// 记录调度开始时间
		double startTime = System.currentTimeMillis();
		// 执行调度过程
		HashSet<Stage> readyStages = addStartStages(application);
		while (!readyStages.isEmpty()) {
			Stage stage = highestPriorityStage(readyStages);
			stageSchedule(stage);
			readyStages.remove(stage);
			stage.scheduled = true; // 标记该Stage已调度，用于添加后继Stage
			// 添加后继Stage
			addSuccessorStage(stage, readyStages);
		}
		// 调度结果调整
		
		
		// 记录调度结束时间
		double endTime = System.currentTimeMillis();
		this.setTimeCost(endTime - startTime);
		// 更新调度器的makespan = 最后一个任务的结束时间 - 第一个任务的开始时间（0）
		this.setMakespan(this.latestFinishTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
		return 0;
	}

	/**
	 * 子截止期划分
	 */
	public void subDeadlineDivide() {
		
	}
	
	/**
	 * 任务调度
	 * 
	 * @param stage 调度该Stage中的任务
	 */
	private void stageSchedule(Stage stage) {
		List<Task> taskList = stage.taskList;
		// 任务排序：隐私性大于非隐私性；输入数据量大大于输入数据量小的
		Collections.sort(taskList, new Comparator<Task>() {
			@Override
			public int compare(Task task1, Task task2) {
				if(task1.isSensitiveTask() == task2.isSensitiveTask()) {
					return (int) (task2.totalInputData - task1.totalInputData);
				}else {
					return task1.isSensitiveTask() ? -1 : 1;
				}
			}
		});
		for (int i = 0; i < taskList.size(); i++) {
			Task cur = taskList.get(i);
			if (cur.isSensitiveTask()) {
				sensitiveTaskSchedule(cur);
			} else {
				nonSensitiveTaskSchedule(cur);
			}
			// 更新任务的最晚完成时间
			this.latestFinishTime = Math.max(latestFinishTime, cur.AFT);
		}
	}
	
	/**
	 * 非敏感任务调度
	 * 
	 * @param cur
	 */
	private void nonSensitiveTaskSchedule(Task cur) {
		// TODO Auto-generated method stub
		double taskStartTime = cur.stage.EST; // 任务开始时间取其所在Stage的开始时间

		// Step1 考虑公有云中已租赁VM是否未使用的空余时间
		List<MyVM> list = resourcePool.getRentVm(); // 获得已租赁的虚拟机资源
		MyVM selectVM = null;
		if (list.size() != 0) {
			// 比较：Task在该VM上执行用时+传输时间与虚拟机租赁结束时间的大小
			for (int i = 0; i < list.size(); i++) {
				MyVM vm = list.get(i);
				double transferTime = calTransferTime(cur, vm);
				double processTime = calProcessTime(cur, vm);
				// 暂时取首次适应法，选择公有云中可用虚拟机
				int range = getRangeByUnitTime(vm.getRentUnitTime());
				int times = 1;
				// TODO 可降低时间复杂度
				while (true) {
					if (times * range > vm.getEndTime()) {
						break;
					}
					times++;
				}
				// 若空余时间满足任务时间传输+执行时间
				if (range * times - vm.getEndTime() > (transferTime + processTime)) {
					selectVM = vm;
					break;
				}
			}
		}

		// Step2 考虑私有云中是否有恰好可用的VM，即availTime < 任务开始时间
		if (selectVM == null) {
			List<MyVM> vmList = resourcePool.getPrivateCloud();
			for (int i = 0; i < vmList.size(); i++) {
				// 同样是找第一个满足条件的VM
				MyVM vm = vmList.get(i);
				if (taskStartTime >= vm.getAvailTime()) {
					selectVM = vm;
					break;
				}
			}
		}

		// Step3 去公有云中租赁新的VM
		if (selectVM == null) {
			// 采用最大剩余空余时间优先，租赁虚拟机
			List<MyVMType> typeList = resourcePool.getPublicVMType();
			double maxRemainTime = 0;
			MyVMType selectType = null;
			for (int i = 0; i < typeList.size(); i++) {
				MyVMType type = typeList.get(i);
				double transferTime = calTransferTime(cur, type);
				double processTime = calProcessTime(cur, type);
				// 考虑单位时间内任务不能执行完成的情况
				int range = getRangeByUnitTime(type.getRentUnitTime());
				int times = 1; // 记录当前任务需要多少个任务周期执行
				while (true) {
					if (range * times < (transferTime + processTime) ) {
						times++;
					} else {
						break;
					}
				}
				double remainTime = range * times - (transferTime + processTime);
				if (remainTime >= maxRemainTime) {
					maxRemainTime = remainTime;
					selectType = type;
				}
			}
			// 初始化选中虚拟机类型的实例
			MyVM vm = new MyVM(selectType);
			vm.setStartTime(taskStartTime);
			vm.setAvailTime(taskStartTime);
			double transferTime = calTransferTime(cur, vm);
			double processTime = calProcessTime(cur, vm);
			vm.setEndTime(taskStartTime + transferTime + processTime);
			vm.setMap(new HashMap<Task, Period>()); // 任务和使用时间阶段映射
			resourcePool.getRentVm().add(vm);// 添加该VM到已租赁资源中

			// 选中当前虚拟机
			selectVM = vm;
		}

		// Step4 任务和资源匹配
		mapTaskAndVM(cur, selectVM);
	}

	/**
	 * 敏感任务调度
	 * 
	 * @param cur
	 */
	private void sensitiveTaskSchedule(Task task) {
		// 敏感任务只能在私有云中执行
		List<MyVM> list = resourcePool.getPrivateCloud();
		// 虚拟机选择标准：最早可用时间
		double earlistAvailTime = list.get(0).getAvailTime();
		MyVM selectVM = list.get(0);
		// 循环比较，获得具有最早开始时间的VM
		for (int i = 1; i < list.size(); i++) {
			MyVM cur = list.get(i);
			if (cur.getAvailTime() < earlistAvailTime) {
				earlistAvailTime = cur.getAvailTime();
				selectVM = cur;
			}
		}
		// 将该任务安排到该资源中
		mapTaskAndVM(task, selectVM);
	}
	
	/**
	 * 获得就绪Stage中具有最高优先级的Stage 这里以Stage的全部接受数据量大小作为排序标准
	 * 
	 * @param readyStages
	 * @return
	 */
	private Stage highestPriorityStage(HashSet<Stage> readyStages) {
		double max = Double.MIN_VALUE;
		Stage stage = null;
		for (Stage cur : readyStages) {
			double curAmount = 0;
			List<Task> taskList = cur.taskList;
			for (Task task : taskList) {
				curAmount += task.totalInputData;
			}
			if (curAmount > max) {
				stage = cur;
			}
		}
		return stage;
	}


}
