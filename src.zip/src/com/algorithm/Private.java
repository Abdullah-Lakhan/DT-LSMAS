package com.algorithm;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.algorithm.stageSequence.MaxRankFirstSequence;
import com.algorithm.stageSequence.MinSlackTimeFirstSequence;
import com.algorithm.stageSequence.StageSequence;
import com.algorithm.stageSequence.TaskBasedRuleSequence;
import com.algorithm.subDeadline.AbstractSubDeadline;
import com.algorithm.subDeadline.ExecutionBasedSubDeadline;
import com.algorithm.subDeadline.LevelBasedSubDeadline;
import com.algorithm.subDeadline.PathBasedSubDeadline;
import com.algorithm.subDeadline.SubDeadline;
import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.utils.CalculateUtils;

/**
 * 仅在私有云中调度，计算需要多少个私有云虚拟机
 * （以按需的方式获取资源）
 * 根据deadline划分子截止期，选择满足子截止期的虚拟机；没有则添加新的虚拟机
 * @author ShirleyLee
 *
 */
public class Private extends MyScheduler {

	/**
	 * 任务比较器
	 * 
	 * @author ShirleyLee
	 *
	 */
	class TaskComparator implements Comparator<Task> {
		@Override
		public int compare(Task task1, Task task2) {
			// 首先按隐私性排序，其次按指令数递减排序
			if (task1.isSensitiveTask() == task2.isSensitiveTask()) {
				// 防止自矛盾，重新定义排序规则
				if (task1.instructions >= task2.instructions) {
					return -1;
				} else {
					return 1;
				}
				// return (int) (task2.instructions - task1.instructions);
			}
			if (task1.isSensitiveTask()) {
				return -1;
			}
			return 1;
		}
	}

	
	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		this.application = app;
		this.resourcePool = resourcePool;
		// 1. 时间参数估计
		timeParameterEstimate(app, resourcePool);

		// 1.5 准备工作：计算slackTime，UpRank等
		calOtherParameter(app);

		// 2. Stage子截止期划分
		divideSubDeadline(1, app);
		

		// 3. 调度序列生成
		List<Stage> stageList = getStageSeq(1, app);

		// 4. 任务调度
		double latestFinishTime = 0;
		for (int i = 0; i < stageList.size(); i++) {
			Stage stage = stageList.get(i);
			List<Task> taskList = stage.taskList;
			// Step4.1 将Stage中任务排序
			Collections.sort(taskList, new TaskComparator());
			double max_EFT = stage.EFT; // Stage的实际结束时间

			// Step4.2 依次调度每个任务
			for (int j = 0; j < taskList.size(); j++) {
				Task task = taskList.get(j);
				System.out.println("任务调度：" + task.stage.job.jobid + "." + task.stage.stageid + "." + task.taskid);

				// TODO 无论任务类型，都在私有云中调度
				max_EFT = Math.max(max_EFT, scheduleInPrivate(task));
				
				// 初始时，实际开始时间=-1；Stage的实际开始时间等于其中Task实际开始时间的最小值
				if (!stage.scheduled || CalculateUtils.compareDouble(task.getAST(), stage.getAST()) < 0) {
					stage.setAST(task.getAST());
				}
				// 更新Stage截止期：Stage中的其他Task只要满足完成时间不超过其中最晚结束时间即可。
				if (CalculateUtils.compareDouble(stage.getSubDeadline(), max_EFT) < 0) {
					stage.setSubDeadline(max_EFT);
				}
			}
			latestFinishTime = Math.max(latestFinishTime, max_EFT);
			stage.scheduled = true;
			stage.setAFT(max_EFT);
			boolean flag = true;
			// 4.4 更新时间参数
			// 若超出原定截止期，或提前完成、与截止期相差大于等于1时
			if (CalculateUtils.compareDouble(stage.EFT, stage.getAFT()) < 0 || (stage.EFT - max_EFT >= 1)) { // 当与原定的截止期出入在(-1,1)范围之外
				flag = updateTimeParameter(stage, 1);
			}
		}
		// 6. 计算makespan和cost
		this.setMakespan(latestFinishTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
//		return latestFinishTime;
		System.out.println("需要的私有云虚拟机个数："+this.resourcePool.getPrivateCloud().size());
		return this.getMakespan();
	}
	
	/**
	 * 在私有云中调度
	 * @param task
	 * @return 
	 */
	private double scheduleInPrivate(Task task) {
		// TODO Auto-generated method stub
		MyVM selectVM = null;
		// Step1 选择私有云中能满足子截止期的虚拟机
		List<MyVM> list = this.resourcePool.getPrivateCloud();
		for(int i = 0; i < list.size(); i++) {
			MyVM vm = list.get(i);
			double startTime = task.stage.EST;
			double transmissionTime = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			// double cost = 0;
			double executionTime = task.instructions / vm.getProcessSpeed();
			double endTime = startTime + executionTime + transmissionTime;
			if(endTime < task.stage.getSubDeadline()) {
				selectVM = vm;
				break;
			}
		}
		// Step2 若没有，则租赁中等速率的虚拟机，更新资源池
		if(selectVM == null) {
			MyVM vm = new MyVM(Constant.middleVM);
			list.add(vm);
			selectVM = vm;
		}
		double endTime = updateInfo(task, selectVM);
		return endTime;
	}
 
	/**
	 * 更新租赁的虚拟机信息、任务执行信息
	 * 
	 * @param task
	 * @param vm
	 */
	private double updateInfo(Task task, MyVM vm) {
		// 1.建立映射关系
		task.setVm(vm);
		vm.getTasks().add(task);
		// 2.更新时间参数
		double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
		double transmissionTime = calTransmissionTime(task, vm.getBelongCloud());
		double executionTime = task.instructions / vm.getProcessSpeed();
		double endTime = startTime + transmissionTime + executionTime; // 任务结束时间
		vm.setAvailTime(endTime);
		if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
			if (vm.getTasks().size() == 1) { // 即刚租赁的虚拟机
				double rentEndTime = Math.ceil((endTime - startTime) / 3600.0) * 3600 + startTime;
				vm.setStartTime(startTime);
				vm.setEndTime(rentEndTime);
			} else {
				// TODO 对于之前租赁的虚拟机，是否还要更新租赁结束时间？按理说选择的已租赁机器是不会超出截止期的
				double rentEndTime = Math.ceil((endTime - vm.getStartTime()) / 3600.0) * 3600 + vm.getStartTime();
				vm.setEndTime(rentEndTime);
			}
		}
		task.setAST(startTime);
		task.setAFT(endTime);
		return endTime;
	}
	
	/**
	 * 计算数据传输时间
	 * 
	 * @param task
	 * @param cloudTag 当前任务分配到云的标号
	 * @return
	 */
	private double calTransmissionTime(Task task, int cloudTag) {
		double transmissionTime = 0;
		if (task.getPrecursorTask().size() == 0)
			return 0;
		for (Entry<Task, Integer> entry : task.getPrecursorTask().entrySet()) {
			MyVM vm = entry.getKey().getVm();
			double tmp = entry.getValue()
					/ (vm.getBelongCloud() == cloudTag ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER);
			transmissionTime = Math.max(transmissionTime, tmp);
		}
		// 计算从私有云传输到该Task的时间
		transmissionTime = Math.max(transmissionTime, task.getRemainData()
				/ (cloudTag == Constant.PRIVATE_CLOUD ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER));
		return transmissionTime;
	}
	
	/**
	 * 更新时间参数及子截止期
	 * 
	 * @param stage
	 * @param SD    子截止期划分方法
	 */
	private boolean updateTimeParameter(Stage stage, int SD) {
		Job curJob = stage.job;
		// TODO Job的ast和aft是何时更新的？
		if (curJob.getAST() == -1 || curJob.getAST() > stage.getAST())
			curJob.setAST(stage.getAST());

		double max_eft = stage.getAFT();
		boolean flag = true;// 判断该Job内是否所有Stage都调度完成：flag=true，全调度完成
		// 1.更新本Job内中所有Stage的时间参数
		if (stage.childStages.size() > 0) {
			List<Stage> list = curJob.stageList;
			for (Stage curStage : list) {
				if (!curStage.scheduled) { // 如果没发生调度，则更新参数
					flag = false;
					if (curStage.parentStages.size() == 0) {
						curStage.EST = curStage.job.EST;
					} else {
						List<Stage> parentStages = curStage.parentStages;
						double max = 0;
						for (Stage parent : parentStages) {
							max = Math.max(max, parent.scheduled ? parent.getAFT() : parent.EFT);
						}
						curStage.EST = max;
					}
					curStage.EFT = curStage.EST + curStage.estimateDuration;
					max_eft = Math.max(max_eft, curStage.EFT);
				}
			}
		} else {
			for (Stage cur : curJob.stageList) {
				if (cur.childStages.size() == 0) {
					max_eft = Math.max(max_eft, cur.scheduled ? cur.getAFT() : cur.EFT);
				}
			}
			List<Stage> list = curJob.stageList;

			for (Stage curStage : list) {
				if (!curStage.scheduled) { // 如果没发生调度，则更新参数
					flag = false;
					break;
				}
			}
		}

		// 2. 更新当前Stage所在Job的参数
		if (flag) {
			curJob.setScheduled(true);
			curJob.setAFT(max_eft);
		}
		if ((curJob.isScheduled() && curJob.getAFT() > curJob.EFT)
				|| (curJob.isScheduled() && curJob.EFT - curJob.getAFT() >= 1)
				|| (!curJob.isScheduled() && max_eft > curJob.EFT)
				|| (!curJob.isScheduled() && curJob.EFT - max_eft >= 1)) {
			if (!curJob.isScheduled()) {
				curJob.EFT = max_eft;
			}
			for (int i = 0; i < application.jobList.size(); i++) {
				Job job = application.jobList.get(i);
				double maxJobEFT = 0;
				if (!job.isScheduled()) {
					if (job.parentJobs.size() == 0) {
						job.EST = 0;
					} else {
						List<Job> parentJobs = job.parentJobs;
						double max = 0;
						for (Job parent : parentJobs) {
							max = Math.max(max, parent.isScheduled() ? parent.getAFT() : parent.EFT);
						}
						job.EST = max;
					}
					double maxStageEFT = 0;
					// 更新其中的Stage
					List<Stage> stageList = job.stageList;
					for (Stage curStage : stageList) {
						if (!curStage.scheduled) {
							if (curStage.parentStages.size() == 0) {
								curStage.EST = job.EST;
							} else {
								List<Stage> parentStages = curStage.parentStages;
								double max = 0;
								for (Stage parent : parentStages) {
									max = Math.max(max, parent.scheduled ? parent.getAFT() : parent.EFT);
								}
								curStage.EST = max;
							}
							curStage.EFT = curStage.EST + curStage.estimateDuration;
							maxStageEFT = Math.max(maxStageEFT, curStage.EFT);
						} else {
							maxStageEFT = Math.max(maxStageEFT, curStage.getAFT());
						}
					}
					job.EFT = Math.max(job.EFT, maxStageEFT);
					maxJobEFT = Math.max(maxJobEFT, job.EFT);
				} else {
					maxJobEFT = Math.max(maxJobEFT, job.getAFT());
				}
				// TODO 如果eft大于截止期，或者大于lft，则返回失败
				application.setEFT(Math.max(application.getEFT(), maxJobEFT));
				if (application.getEFT() > application.getDeadline()) {
					return false;
				}
			}
		}
		// 4.更新子截止期
		divideSubDeadline(SD, application);
		return true;
	}

	
	/**
	 * 获得调度序列
	 * 
	 * @param SS
	 * @param app
	 * @return
	 */
	private List<Stage> getStageSeq(int SS, SparkApplication app) {
		// 1. 选择不同的Stage排序方法
		List<Stage> stageList = null;
		switch (SS) {
		case 1: {
			StageSequence seq = new MaxRankFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		case 2: {
			StageSequence seq = new MinSlackTimeFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		case 3: {
			StageSequence seq = new TaskBasedRuleSequence();
			stageList = seq.sequence(app);
			break;
		}
		default: {
			StageSequence seq = new MaxRankFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		}
		return stageList;
	}
	
	/**
	 * 其他参数计算：level，slackTime，UpRank
	 * 
	 * @param app
	 */
	private void calOtherParameter(SparkApplication app) {
		// 1. 确定各个Job和Stage的level
		AbstractSubDeadline abs = new LevelBasedSubDeadline();
		abs.calJobLevelForward(app);

		// 2. 计算app的SlackTime
		double eft = Double.MIN_VALUE;
		double slackTime = Double.MIN_VALUE;
		for (Job job : app.jobList) {
			eft = Math.max(eft, job.EFT);
		}
		slackTime = app.getDeadline() - eft;
		app.setSlackTime(slackTime);

		// 3. 计算Job和Stage的UpRank值
		abs = new PathBasedSubDeadline();
		abs.calJobUpRank(app);
	}
	
	/**
	 * 时间参数估计
	 * 
	 * @param app
	 * @param resourcePool
	 */
	private void timeParameterEstimate(SparkApplication app, MyResourcePool resourcePool) {
		// 0. 最快执行速度和最快带宽
		double v = Constant.highVM.getProcessSpeed();
		double bw = Math.max(Constant.BANDWIDTH_INTER, Constant.BANDWIDTH_INTRA);

		// 1. 估计任务执行时间，Stage执行时间
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				double max = Double.MIN_VALUE;
				for (int k = 0; k < stage.taskNum; k++) {
					Task task = stage.taskList.get(k);
					task.setEstimateProcessTime(task.instructions / v);
					Map<Task, Integer> map = task.getPrecursorTask();
					double transmissionTime = 0;
					for (Entry<Task, Integer> entry : map.entrySet()) {
						double tmp = entry.getValue() / bw;
						transmissionTime = Math.max(transmissionTime, tmp);
					}
					task.setEstimateTotalTime(task.getEstimateProcessTime() + transmissionTime);
					max = Math.max(max, task.getEstimateTotalTime());
				}
				stage.estimateDuration = max;
			}
		}

		// 2. 估计Job、Stage最早时间参数
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			if (job.parentJobs.size() == 0) {
				job.EST = 0;
			} else {
				List<Job> parentJobs = job.parentJobs;
				double max = Double.MIN_VALUE;
				for (Job parent : parentJobs) {
					max = Math.max(max, parent.EFT);
				}
				job.EST = max;
			}
			double maxEFT = job.EST;
			// 更新其中Stage的时间参数
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				if (stage.parentStages.size() == 0) {
					stage.EST = stage.job.EST;
				} else {
					List<Stage> parentStages = stage.parentStages;
					double max = Double.MIN_VALUE;
					for (Stage parent : parentStages) {
						max = Math.max(max, parent.EFT);
					}
					stage.EST = max;
				}
				stage.EFT = stage.EST + stage.estimateDuration;
				maxEFT = Math.max(maxEFT, stage.EFT);
			}
			job.EFT = maxEFT;
		}

		// 4. 估计Job、Stage最晚时间参数
		List<Job> reverseJobList = app.reverseJobList;
		double D = app.getDeadline();
		for (int i = 0; i < reverseJobList.size(); i++) {
			Job job = reverseJobList.get(i);
			if (job.childJobs.size() == 0) {
				job.LFT = D;
			} else {
				double min = Double.MAX_VALUE;
				for (Job child : job.childJobs) {
					min = Math.min(min, child.LST);
				}
				job.LFT = min;
			}
			double minLST = Double.MAX_VALUE;
			List<Stage> reverseStageList = job.reverseStageList;
			for (int j = 0; j < reverseStageList.size(); j++) {
				Stage stage = reverseStageList.get(j);
				if (stage.childStages.size() == 0) {
					stage.LFT = job.LFT;
				} else {
					double min = Double.MAX_VALUE;
					for (Stage child : stage.childStages) {
						min = Math.min(min, child.LST);
					}
					stage.LFT = min;
				}
				stage.LST = stage.LFT - stage.estimateDuration;
				minLST = Math.min(minLST, stage.LST);
			}
			job.LST = minLST;
		}
	}

	/**
	 * 获得Stage子截止期
	 * 
	 * @param SD
	 * @param app
	 */
	private void divideSubDeadline(int SD, SparkApplication app) {
		// 4. 选择不同策略
		switch (SD) {
		case 1: {
			SubDeadline sub = new ExecutionBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		case 2: {
			SubDeadline sub = new LevelBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		case 3: {
			SubDeadline sub = new PathBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		default: {
			// 默认用第二种
			SubDeadline sub = new LevelBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		}

	}
}
