package com.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.algorithm.stageSequence.MaxRankFirstSequence;
import com.algorithm.stageSequence.MinSlackTimeFirstSequence;
import com.algorithm.stageSequence.StageSequence;
import com.algorithm.stageSequence.TaskBasedRuleSequence;
import com.algorithm.subDeadline.AbstractSubDeadline;
import com.algorithm.subDeadline.ExecutionBasedSubDeadline;
import com.algorithm.subDeadline.LevelBasedSubDeadline;
import com.algorithm.subDeadline.PathBasedSubDeadline;
import com.algorithm.subDeadline.SubDeadline;
import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;
import com.utils.CalculateUtils;

public class SSPPH extends MyScheduler {

	/**
	 * 任务比较器
	 * 
	 * @author ShirleyLee
	 *
	 */
	class TaskComparator implements Comparator<Task> {
		@Override
		public int compare(Task task1, Task task2) {
			// 首先按隐私性排序，其次按指令数递减排序
			if (task1.isSensitiveTask() == task2.isSensitiveTask()) {
				// 防止自矛盾，重新定义排序规则
				if (task1.instructions >= task2.instructions) {
					return -1;
				} else {
					return 1;
				}
				// return (int) (task2.instructions - task1.instructions);
			}
			if (task1.isSensitiveTask()) {
				return -1;
			}
			return 1;
		}
	}

//	public RBSAS(int SD, int SS, int PSS, int RSS) {
//		
//	}

	/**
	 * 该调度算法中，比较四类组件的性能
	 */
	// 基于规则的Spark应用调度方法（Rule Based Spark Application Scheduling）
	@Override
	public void runSchedule(SparkApplication app, MyResourcePool resourcePool, Map<String, Integer> map) {
		this.application = app;
		this.resourcePool = resourcePool;
		// 共有四组参数
		/*
		 * 分别是：子截止期（Subdeadline，SD），调度序列（Schedule Sequence，SS）， 已租赁资源选择方法（Rented Source
		 * Select，RSS）和私有云资源选择方法（Private Source Select，PSS）。
		 */
		// 调度流程
		// 四个参数，赋值：
		int SD = map.get("SD");
		int SS = map.get("SS");
		int RSS = map.get("RSS");
		int PSS = map.get("PSS");
		// 1. 时间参数估计
		timeParameterEstimate(app, resourcePool);

		// 1.5 准备工作：计算slackTime，UpRank等
		calOtherParameter(app);

		// 2. Stage子截止期划分
		divideSubDeadline(SD, app);

		// 3. 调度序列生成
		List<Stage> stageList = getStageSeq(SS, app);

		// 4. 任务调度
		double latestFinishTime = 0;
		for (int i = 0; i < stageList.size(); i++) {
			Stage stage = stageList.get(i);
			List<Task> taskList = stage.taskList;
			// Step4.1 将Stage中任务排序
			Collections.sort(taskList, new TaskComparator());
			double max_EFT = stage.EFT; // Stage的实际结束时间

			// Step4.2 依次调度每个任务
			for (int j = 0; j < taskList.size(); j++) {
				Task task = taskList.get(j);
				System.out.println("任务调度：" + task.stage.job.jobid + "." + task.stage.stageid + "." + task.taskid);
				if (task.isSensitiveTask()) {
					max_EFT = Math.max(max_EFT, sensitiveTaskScheduler(task, resourcePool));
				} else {
					max_EFT = Math.max(max_EFT, nonSensitiveTaskScheduler(task, resourcePool, RSS, PSS));
				}
				// 初始时，实际开始时间=-1；Stage的实际开始时间等于其中Task实际开始时间的最小值
				if (!stage.scheduled || CalculateUtils.compareDouble(task.getAST(), stage.getAST()) < 0) {
					stage.setAST(task.getAST());
				}
				// 更新Stage截止期：Stage中的其他Task只要满足完成时间不超过其中最晚结束时间即可。
				if (CalculateUtils.compareDouble(stage.getSubDeadline(), max_EFT) < 0) {
					stage.setSubDeadline(max_EFT);
				}
			}
			latestFinishTime = Math.max(latestFinishTime, max_EFT);
			stage.scheduled = true;
			stage.setAFT(max_EFT);
			boolean flag = true;
			// 4.4 更新时间参数
			// 若超出原定截止期，或提前完成、与截止期相差大于等于1时
			if (CalculateUtils.compareDouble(stage.EFT, stage.getAFT()) < 0 || (stage.EFT - max_EFT >= 1)) { // 当与原定的截止期出入在(-1,1)范围之外
				flag = updateTimeParameter(stage, SD);
			}
			if (!flag) {
				// TODO 提示无法满足截止期约束
				// System.out.println("无法满足截止期");
				// return -1;
			}

		}
		// 5. 调度结果调整
		scheduleResultAdjust();

		// 6. 计算makespan和cost
		this.setMakespan(latestFinishTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
//		return latestFinishTime;
		return;
	}

	/**
	 * 更新时间参数及子截止期
	 * 
	 * @param stage
	 * @param SD    子截止期划分方法
	 */
	private boolean updateTimeParameter(Stage stage, int SD) {
		Job curJob = stage.job;
		// TODO Job的ast和aft是何时更新的？
		if (curJob.getAST() == -1 || curJob.getAST() > stage.getAST())
			curJob.setAST(stage.getAST());

		double max_eft = stage.getAFT();
		boolean flag = true;// 判断该Job内是否所有Stage都调度完成：flag=true，全调度完成
		// 1.更新本Job内中所有Stage的时间参数
		if (stage.childStages.size() > 0) {
			List<Stage> list = curJob.stageList;
			for (Stage curStage : list) {
				if (!curStage.scheduled) { // 如果没发生调度，则更新参数
					flag = false;
					if (curStage.parentStages.size() == 0) {
						curStage.EST = curStage.job.EST;
					} else {
						List<Stage> parentStages = curStage.parentStages;
						double max = 0;
						for (Stage parent : parentStages) {
							max = Math.max(max, parent.scheduled ? parent.getAFT() : parent.EFT);
						}
						curStage.EST = max;
					}
					curStage.EFT = curStage.EST + curStage.estimateDuration;
					max_eft = Math.max(max_eft, curStage.EFT);
				}
			}
		} else {
			for (Stage cur : curJob.stageList) {
				if (cur.childStages.size() == 0) {
					max_eft = Math.max(max_eft, cur.scheduled ? cur.getAFT() : cur.EFT);
				}
			}
			List<Stage> list = curJob.stageList;

			for (Stage curStage : list) {
				if (!curStage.scheduled) { // 如果没发生调度，则更新参数
					flag = false;
					break;
				}
			}
		}

		// 2. 更新当前Stage所在Job的参数
		if (flag) {
			curJob.setScheduled(true);
			curJob.setAFT(max_eft);
		}
		if ((curJob.isScheduled() && curJob.getAFT() > curJob.EFT)
				|| (curJob.isScheduled() && curJob.EFT - curJob.getAFT() >= 1)
				|| (!curJob.isScheduled() && max_eft > curJob.EFT)
				|| (!curJob.isScheduled() && curJob.EFT - max_eft >= 1)) {
			if (!curJob.isScheduled()) {
				curJob.EFT = max_eft;
			}
			for (int i = 0; i < application.jobList.size(); i++) {
				Job job = application.jobList.get(i);
				double maxJobEFT = 0;
				if (!job.isScheduled()) {
					if (job.parentJobs.size() == 0) {
						job.EST = 0;
					} else {
						List<Job> parentJobs = job.parentJobs;
						double max = 0;
						for (Job parent : parentJobs) {
							max = Math.max(max, parent.isScheduled() ? parent.getAFT() : parent.EFT);
						}
						job.EST = max;
					}
					double maxStageEFT = 0;
					// 更新其中的Stage
					List<Stage> stageList = job.stageList;
					for (Stage curStage : stageList) {
						if (!curStage.scheduled) {
							if (curStage.parentStages.size() == 0) {
								curStage.EST = job.EST;
							} else {
								List<Stage> parentStages = curStage.parentStages;
								double max = 0;
								for (Stage parent : parentStages) {
									max = Math.max(max, parent.scheduled ? parent.getAFT() : parent.EFT);
								}
								curStage.EST = max;
							}
							curStage.EFT = curStage.EST + curStage.estimateDuration;
							maxStageEFT = Math.max(maxStageEFT, curStage.EFT);
						} else {
							maxStageEFT = Math.max(maxStageEFT, curStage.getAFT());
						}
					}
					job.EFT = Math.max(job.EFT, maxStageEFT);
					maxJobEFT = Math.max(maxJobEFT, job.EFT);
				} else {
					maxJobEFT = Math.max(maxJobEFT, job.getAFT());
				}
				// TODO 如果eft大于截止期，或者大于lft，则返回失败
				application.setEFT(Math.max(application.getEFT(), maxJobEFT));
				if (application.getEFT() > application.getDeadline()) {
					return false;
				}
			}
		}
		// 4.更新子截止期
		divideSubDeadline(SD, application);
		return true;
	}

	/**
	 * 其他参数计算：level，slackTime，UpRank
	 * 
	 * @param app
	 */
	private void calOtherParameter(SparkApplication app) {
		// 1. 确定各个Job和Stage的level
		AbstractSubDeadline abs = new LevelBasedSubDeadline();
		abs.calJobLevelForward(app);

		// 2. 计算app的SlackTime
		double eft = Double.MIN_VALUE;
		double slackTime = Double.MIN_VALUE;
		for (Job job : app.jobList) {
			eft = Math.max(eft, job.EFT);
		}
		slackTime = app.getDeadline() - eft;
		app.setSlackTime(slackTime);

		// 3. 计算Job和Stage的UpRank值
		abs = new PathBasedSubDeadline();
		abs.calJobUpRank(app);
	}

	/**
	 * 时间参数估计
	 * 
	 * @param app
	 * @param resourcePool
	 */
	private void timeParameterEstimate(SparkApplication app, MyResourcePool resourcePool) {
		// 0. 最快执行速度和最快带宽
		double v = Constant.highVM.getProcessSpeed();
		double bw = Math.max(Constant.BANDWIDTH_INTER, Constant.BANDWIDTH_INTRA);

		// 1. 估计任务执行时间，Stage执行时间
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				double max = Double.MIN_VALUE;
				for (int k = 0; k < stage.taskNum; k++) {
					Task task = stage.taskList.get(k);
					task.setEstimateProcessTime(task.instructions / v);
					Map<Task, Integer> map = task.getPrecursorTask();
					double transmissionTime = 0;
					for (Entry<Task, Integer> entry : map.entrySet()) {
						double tmp = entry.getValue() / bw;
						transmissionTime = Math.max(transmissionTime, tmp);
					}
					task.setEstimateTotalTime(task.getEstimateProcessTime() + transmissionTime);
					max = Math.max(max, task.getEstimateTotalTime());
				}
				stage.estimateDuration = max;
			}
		}

		// 2. 估计Job、Stage最早时间参数
		for (int i = 0; i < app.jobNum; i++) {
			Job job = app.jobList.get(i);
			if (job.parentJobs.size() == 0) {
				job.EST = 0;
			} else {
				List<Job> parentJobs = job.parentJobs;
				double max = Double.MIN_VALUE;
				for (Job parent : parentJobs) {
					max = Math.max(max, parent.EFT);
				}
				job.EST = max;
			}
			double maxEFT = job.EST;
			// 更新其中Stage的时间参数
			for (int j = 0; j < job.stageNum; j++) {
				Stage stage = job.stageList.get(j);
				if (stage.parentStages.size() == 0) {
					stage.EST = stage.job.EST;
				} else {
					List<Stage> parentStages = stage.parentStages;
					double max = Double.MIN_VALUE;
					for (Stage parent : parentStages) {
						max = Math.max(max, parent.EFT);
					}
					stage.EST = max;
				}
				stage.EFT = stage.EST + stage.estimateDuration;
				maxEFT = Math.max(maxEFT, stage.EFT);
			}
			job.EFT = maxEFT;
		}

		// 4. 估计Job、Stage最晚时间参数
		List<Job> reverseJobList = app.reverseJobList;
		double D = app.getDeadline();
		for (int i = 0; i < reverseJobList.size(); i++) {
			Job job = reverseJobList.get(i);
			if (job.childJobs.size() == 0) {
				job.LFT = D;
			} else {
				double min = Double.MAX_VALUE;
				for (Job child : job.childJobs) {
					min = Math.min(min, child.LST);
				}
				job.LFT = min;
			}
			double minLST = Double.MAX_VALUE;
			List<Stage> reverseStageList = job.reverseStageList;
			for (int j = 0; j < reverseStageList.size(); j++) {
				Stage stage = reverseStageList.get(j);
				if (stage.childStages.size() == 0) {
					stage.LFT = job.LFT;
				} else {
					double min = Double.MAX_VALUE;
					for (Stage child : stage.childStages) {
						min = Math.min(min, child.LST);
					}
					stage.LFT = min;
				}
				stage.LST = stage.LFT - stage.estimateDuration;
				minLST = Math.min(minLST, stage.LST);
			}
			job.LST = minLST;
		}
	}

	/**
	 * 获得Stage子截止期
	 * 
	 * @param SD
	 * @param app
	 */
	private void divideSubDeadline(int SD, SparkApplication app) {
		// 4. 选择不同策略
		switch (SD) {
		case 1: {
			SubDeadline sub = new ExecutionBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		case 2: {
			SubDeadline sub = new LevelBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		case 3: {
			SubDeadline sub = new PathBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		default: {
			// 默认用第二种
			SubDeadline sub = new LevelBasedSubDeadline();
			sub.divideSubDeadline(app);
			break;
		}
		}

	}

	/**
	 * 获得调度序列
	 * 
	 * @param SS
	 * @param app
	 * @return
	 */
	private List<Stage> getStageSeq(int SS, SparkApplication app) {
		// 1. 选择不同的Stage排序方法
		List<Stage> stageList = null;
		switch (SS) {
		case 1: {
			StageSequence seq = new MaxRankFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		case 2: {
			StageSequence seq = new MinSlackTimeFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		case 3: {
			StageSequence seq = new TaskBasedRuleSequence();
			stageList = seq.sequence(app);
			break;
		}
		default: {
			StageSequence seq = new MaxRankFirstSequence();
			stageList = seq.sequence(app);
			break;
		}
		}
		return stageList;
	}

	/**
	 * 隐私任务调度：选择私有云中最早完成的虚拟机
	 * 
	 * @param task
	 * @param resourcePool return 返回当前任务执行完成时间
	 */
	private double sensitiveTaskScheduler(Task task, MyResourcePool resourcePool) {
		List<MyVM> list = resourcePool.getPrivateCloud();
		double min = Double.MAX_VALUE;
		MyVM select = null;
		for (MyVM vm : list) {
			double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
			double transmission = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double execution = task.instructions / vm.getProcessSpeed();
			double endTime = startTime + transmission + execution;
			if (select == null || endTime < min) {
				min = endTime;
				select = vm;
			}
			// task.setAST(vm.getAvailTime());
		}
		// 建立任务和虚拟机的匹配
		// mapTaskandVM(task, select);
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 非隐私任务调度
	 * 
	 * @param max_EFT
	 * @param task
	 * @param resourcePool
	 * @param PSS          私有云资源选择策略
	 * @param RSS          空闲时间块选择策略
	 * @return
	 */
	private double nonSensitiveTaskScheduler(Task task, MyResourcePool resourcePool, int RSS, int PSS) {
		// Step1 已租赁机器选择
		MyVM select = null;
		MyVM fastest = null;

		// Step1.1 私有云机器
		if (select == null) {
			List<MyVM> pri = resourcePool.getPrivateCloud();
			MyVM selectVM = null;
			switch (PSS) {
			case 1: {
				selectVM = privateResourceFirstAvailable(task, pri);
				break;
			}
			case 2: {
				selectVM = privateResourceFirstFinish(task, pri);
				break;
			}
			case 3: {
				selectVM = privateResourceMaxUnexceed(task, pri);
				break;
			}
			default: {
				selectVM = privateResourceFirstAvailable(task, pri);
				break;
			}
			}
			select = selectVM;
			// 若没有满足截止期的虚拟机
			if (select == null) {
				// 获得在私有云中（不能满足子截止期）但，最早使任务结束的虚拟机
				MyVM cur = selectEarliestEndTimeVM(task, pri);
				if (fastest != null)
					fastest = compareFastestVM(task, fastest, cur);
				else
					fastest = cur;
			}
		}

		// Step1.2 寻找空闲时间块
		// TODO：如果三种都不能满足截止期，则选择所有可选资源中具有最早完工时间的
		List<IdleSlot> idleSlotList = getIdleSlot(task, resourcePool.getRentVm()); // 得到可满足截止期的空闲时间块
		if (idleSlotList.size() > 0) {
			switch (RSS) {
			case 1: {
				select = slotSelectBestFit(task, idleSlotList);
				break;
			}
			case 2: {
				select = slotSelectFirstFit(task, idleSlotList);
				break;
			}
			case 3: {
				select = slotSelectWorstFit(task, idleSlotList);
				break;
			}
//			case 4: {
//				select = slotSelectMinGapTime(task, idleSlotList);
//				break;
//			}
//			case 4: {
//				select = slotSelectMinTransTimeFirst(task, idleSlotList);
//				break;
//			}
			default: {
				select = slotSelectBestFit(task, idleSlotList);
				break;
			}
			}
		} else { // 若没有满足截止期要求的时间块
			// TODO 从已租赁资源中选择具有最早完工时间的
			if (resourcePool.getRentVm().size() > 0) { // 若有已租赁资源
				MyVM cur = selectEarliestEndTimeVM(task, resourcePool.getRentVm()); // cur有可能为空，因为对于已租赁资源，需要满足不超过租赁结束时间的限制
				if (cur != null) {
					if (fastest != null)
						fastest = compareFastestVM(task, fastest, cur);
					else
						fastest = cur;
				}
			}
		}

		// Step3 租赁新机器
		if (select == null) {
			List<MyVMType> list = resourcePool.getPublicVMType();
			double min = Double.MAX_VALUE;
			MyVMType selectType = null;
			// 选择能满足截止期的，成本最少的 ，如果没有，则选择结束时间最早的，需要更新后继截止期
			double minCur = Double.MAX_VALUE;
			MyVMType curType = null;
			for (MyVMType type : list) {
				double startTime = task.stage.EST;
				double transmissionTime = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
				double cost = 0;
				double executionTime = task.instructions / type.getProcessSpeed();
				double endTime = startTime + executionTime + transmissionTime;
				cost = Math.ceil(task.instructions / type.getProcessSpeed() / 3600) * type.getRentUnitPrice();
				if ((selectType == null || cost < min) && endTime <= task.stage.getSubDeadline()) {
					selectType = type;
					min = cost;
				}
				// 记录所有虚拟机类型中具有最早结束时间的机器
				if (endTime < minCur) {
					minCur = endTime;
					curType = type;
					// max_EFT = endTime;
				}
			}
			MyVM rent = null;
			if (selectType != null) { // 即存在满足截止期的可租赁机器
				rent = new MyVM(selectType);
				rent.setBelongCloud(Constant.PUBLIC_CLOUD);
				resourcePool.getRentVm().add(rent);
				select = rent;
			} else {
				// 比较得到最快完工的虚拟机
				MyVM cur = new MyVM(curType);
				if (fastest != null)
					fastest = compareFastestVM(task, fastest, cur);
				else
					fastest = cur;
			}
		}
		// 如果没有满足截止期的虚拟机，则选择最快的机器
		if (select == null) {
			if (fastest.getBelongCloud() == Constant.PUBLIC_CLOUD) {
				if (fastest.getTasks().size() == 0) {
					resourcePool.getRentVm().add(fastest);
				}
			}
			select = fastest;
		}
		// 更新虚拟机信息、任务执行信息
		double endTime = updateInfo(task, select);
		return endTime;
	}

	/**
	 * 比较得到最快完工的虚拟机
	 * 
	 * @param task
	 * @param fastest 当前待比较的虚拟机
	 * @param cur     之前已确定的最快的虚拟机
	 * @return
	 */
	private MyVM compareFastestVM(Task task, MyVM fastest, MyVM cur) {
		MyVM selected = null;
		// cur的结束时间
		double startTime1 = Math.max(cur.getAvailTime(), task.stage.EST);
		double transmissionTime1 = calTransmissionTime(task, cur.getBelongCloud());
		double executionTime1 = task.instructions / cur.getProcessSpeed();
		double finishTime1 = startTime1 + transmissionTime1 + executionTime1;

		// fastest的结束时间
		double startTime2 = Math.max(fastest.getAvailTime(), task.stage.EST);
		double transmissionTime2 = calTransmissionTime(task, fastest.getBelongCloud());
		double executionTime2 = task.instructions / fastest.getProcessSpeed();
		double finishTime2 = startTime2 + transmissionTime2 + executionTime2;

		if (CalculateUtils.compareDouble(finishTime1, finishTime2) < 0) {
			selected = cur;
		} else {
			selected = fastest;
		}
		return selected;
	}

	/**
	 * 对于已租赁机器，由于没有满足截止期的虚拟机，则选择具有最早完工时间的虚拟机
	 * 
	 * @param task
	 * @param rentVm
	 * @return
	 */
	private MyVM selectEarliestEndTimeVM(Task task, List<MyVM> list) {
		// TODO Auto-generated method stub
		MyVM fastest = null;
		double min = Double.MAX_VALUE;
		for (MyVM vm : list) {
			double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
			double transmissionTime = calTransmissionTime(task, vm.getBelongCloud());
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime;
			// 若是公有云中机器，需要满足：任务执行过程在租赁范围内
			if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
				if ((fastest == null || CalculateUtils.compareDouble(finishTime, min) < 0)
						&& CalculateUtils.compareDouble(finishTime, vm.getEndTime()) <= 0) {
					fastest = vm;
					min = finishTime;
				}
			} else {
				if (fastest == null || CalculateUtils.compareDouble(finishTime, min) < 0) {
					fastest = vm;
					min = finishTime;
				}
			}
		}
		return fastest;
	}

	/**
	 * 更新max_EFT
	 * 
	 * @param task
	 * @param select
	 * @return
	 */
	private double calTaskEndTime(Task task, MyVM select) {
		if (select != null) {
			double startTime = Math.max(select.getAvailTime(), task.stage.EST);
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / select.getProcessSpeed();
			double endTime = startTime + transmissionTime + executionTime;
			return endTime;
		}
		return 0;
	}

	/**
	 * 更新租赁的虚拟机信息、任务执行信息
	 * 
	 * @param task
	 * @param vm
	 */
	private double updateInfo(Task task, MyVM vm) {
		// 1.建立映射关系
		task.setVm(vm);
		vm.getTasks().add(task);
		// 2.更新时间参数
		double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
		double transmissionTime = calTransmissionTime(task, vm.getBelongCloud());
		double executionTime = task.instructions / vm.getProcessSpeed();
		double endTime = startTime + transmissionTime + executionTime; // 任务结束时间
		vm.setAvailTime(endTime);
		if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
			if (vm.getTasks().size() == 1) { // 即刚租赁的虚拟机
				double rentEndTime = Math.ceil((endTime - startTime) / 3600.0) * 3600 + startTime;
				vm.setStartTime(startTime);
				vm.setEndTime(rentEndTime);
			} else {
				// TODO 对于之前租赁的虚拟机，是否还要更新租赁结束时间？按理说选择的已租赁机器是不会超出截止期的
				double rentEndTime = Math.ceil((endTime - vm.getStartTime()) / 3600.0) * 3600 + vm.getStartTime();
				vm.setEndTime(rentEndTime);
			}
		}
		task.setAST(startTime);
		task.setAFT(endTime);
		return endTime;
	}

	/**
	 * 私有云虚拟机选择：最少浪费策略
	 * 
	 * @param task 任务
	 * @param list 私有云
	 * @return
	 */
	private MyVM privateResourceMaxUnexceed(Task task, List<MyVM> list) {
		MyVM select = null;
		double min = Double.MAX_VALUE; // 浪费量
		for (MyVM vm : list) {
			double availTime = vm.getAvailTime();
			double startTime = Math.max(availTime, task.stage.EST); // 受前驱Stage完工时间限制
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime;
			double tmp = (startTime - availTime) * vm.getProcessSpeed();
			if ((select == null || CalculateUtils.compareDouble(tmp, min) < 0)
					&& CalculateUtils.compareDouble(finishTime, task.stage.getSubDeadline()) <= 0) {
				select = vm;
				min = tmp;
			}
		}
		return select;
	}

	/**
	 * 私有云虚拟机选择：最早完工
	 * 
	 * @param task
	 * @param pri
	 * @return
	 */
	private MyVM privateResourceFirstFinish(Task task, List<MyVM> list) {
		MyVM select = null;
		double min = Double.MAX_VALUE;
		for (MyVM vm : list) {
			double availTime = vm.getAvailTime();
			double startTime = Math.max(availTime, task.stage.EST); // 受前驱Stage完工时间限制
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime;
			if ((select == null || CalculateUtils.compareDouble(finishTime, min) < 0)
					&& CalculateUtils.compareDouble(finishTime, task.stage.getSubDeadline()) <= 0) {
				select = vm;
				min = finishTime;
			}
		}
		return select;
	}

	/**
	 * 私有云虚拟机选择：最早可用且满足截止期
	 * 
	 * @param task
	 * @param pri
	 * @return
	 */
	private MyVM privateResourceFirstAvailable(Task task, List<MyVM> list) {
		MyVM select = null;
		// double finishTime = 0;
		for (MyVM vm : list) {
			double startTime = Math.max(vm.getAvailTime(), task.stage.EST);
			double transmissionTime = calTransmissionTime(task, Constant.PRIVATE_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime;
			// 最早可用；double类型的比较
			if ((select == null || CalculateUtils.compareDouble(vm.getAvailTime(), select.getAvailTime()) < 0)
					&& CalculateUtils.compareDouble(finishTime, task.stage.getSubDeadline()) <= 0) {
				select = vm;
			}
		}
		return select;
	}

	/**
	 * 空闲时间块选择：最少传输时间优先
	 * 
	 * @param task
	 * @param idleSlotList
	 * @return
	 */
	private MyVM slotSelectMinTransTimeFirst(Task task, List<IdleSlot> idleSlotList) {
		// TODO Auto-generated method stub

		return null;
	}

	/**
	 * 空闲时间块选择：最坏适应优先
	 * 
	 * @param task
	 * @param idleSlotList
	 * @return
	 */
	private MyVM slotSelectWorstFit(Task task, List<IdleSlot> idleSlotList) {
		IdleSlot select = null;
		double gap = Double.MAX_VALUE;
		for (int i = 0; i < idleSlotList.size(); i++) {
			IdleSlot slot2 = idleSlotList.get(i);
			MyVM vm2 = slot2.getVm();
			double endTime2 = vm2.getEndTime();
			double availTime2 = vm2.getAvailTime();
			double startTime2 = Math.max(availTime2, task.stage.EST); // 受前驱Stage完工时间限制
			double transmissionTime2 = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			double executionTime2 = task.instructions / vm2.getProcessSpeed();
			double gap2 = endTime2 - (startTime2 + transmissionTime2 + executionTime2);
			double finishTime2 = startTime2 + transmissionTime2 + executionTime2;
			if ((select == null || CalculateUtils.compareDouble(gap, gap2) < 0)
					&& CalculateUtils.compareDouble(finishTime2, task.stage.getSubDeadline()) <= 0) {
				select = slot2;
				gap = gap2;
			}
		}

		if (select != null) {
			MyVM vm = select.getVm();
			return vm;
		} else {
			return null;
		}
	}

	/**
	 * 空闲时间块选择：首次适应
	 * 
	 * @param task
	 * @param idleSlotList
	 * @return
	 */
	private MyVM slotSelectFirstFit(Task task, List<IdleSlot> idleSlotList) {
		IdleSlot select = null;
		for (IdleSlot slot : idleSlotList) {
			MyVM vm = slot.getVm();
			double availTime = vm.getAvailTime();
			double startTime = Math.max(availTime, task.stage.EST);
			double transmissionTime = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime;
			if (CalculateUtils.compareDouble(finishTime, task.stage.getSubDeadline()) < 0) {
				select = slot;
				break;
			}
		}
		if (select != null) {
			MyVM vm = select.getVm();
			return vm;
		} else {
			return null;
		}
	}

	/**
	 * 空闲时间块选择：最小Gap优先
	 * 
	 * @param task
	 * @param idleSlotList
	 * @return
	 */
	private MyVM slotSelectMinGapTime(Task task, List<IdleSlot> idleSlotList) {
		IdleSlot select = null;
		double gap = Double.MAX_VALUE;
		for (IdleSlot slot : idleSlotList) {
			MyVM vm = slot.getVm();
			double availTime = vm.getAvailTime();
			double startTime = Math.max(availTime, task.stage.EST);
			double tmp = startTime - availTime; // gap时间
			double transmissionTime = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			double executionTime = task.instructions / vm.getProcessSpeed();
			double finishTime = startTime + transmissionTime + executionTime; // 任务结束时间
			if ((select == null || tmp < gap) && finishTime < task.stage.getSubDeadline()) {
				select = slot;
				gap = tmp;
			}
		}
		if (select != null) {
			MyVM vm = select.getVm();
			return vm;
		} else {
			return null;
		}
	}

	/**
	 * 空闲时间块选择：最小剩余时间优先（需要满足截止期约束）
	 * 
	 * @param task
	 * @param idleSlotList
	 * @return
	 */
	private MyVM slotSelectBestFit(Task task, List<IdleSlot> idleSlotList) {
		IdleSlot select = null;
		double gap = Double.MAX_VALUE;
		for (int i = 0; i < idleSlotList.size(); i++) {
			IdleSlot slot2 = idleSlotList.get(i);
			MyVM vm2 = slot2.getVm();
			double endTime2 = vm2.getEndTime();
			double availTime2 = vm2.getAvailTime();
			double startTime2 = Math.max(availTime2, task.stage.EST); // 受前驱Stage完工时间限制
			double transmissionTime2 = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			double executionTime2 = task.instructions / vm2.getProcessSpeed();
			double gap2 = endTime2 - (startTime2 + transmissionTime2 + executionTime2);
			double finishTime2 = startTime2 + transmissionTime2 + executionTime2;
			if ((select == null || CalculateUtils.compareDouble(gap2, gap) < 0)
					&& CalculateUtils.compareDouble(finishTime2, task.stage.getSubDeadline()) <= 0) {
				select = slot2;
				gap = gap2;
			}
		}

		if (select != null) {
			MyVM vm = select.getVm();
			return vm;
			/*
			 * double availTime = vm.getAvailTime(); double startTime = Math.max(availTime,
			 * task.stage.EST); double transmissionTime = calTransmissionTime(task,
			 * Constant.PRIVATE_CLOUD); double executionTime = task.instructions /
			 * vm.getProcessSpeed(); double finishTime = startTime + transmissionTime +
			 * executionTime; vm.setAvailTime(finishTime);
			 */
		} else {
			return null;
		}
	}

	/**
	 * 计算数据传输时间
	 * 
	 * @param task
	 * @param cloudTag 当前任务分配到云的标号
	 * @return
	 */
	private double calTransmissionTime(Task task, int cloudTag) {
		double transmissionTime = 0;
		if (task.getPrecursorTask().size() == 0)
			return 0;
		for (Entry<Task, Integer> entry : task.getPrecursorTask().entrySet()) {
			MyVM vm = entry.getKey().getVm();
			double tmp = entry.getValue()
					/ (vm.getBelongCloud() == cloudTag ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER);
			transmissionTime = Math.max(transmissionTime, tmp);
		}
		// 计算从私有云传输到该Task的时间
		transmissionTime = Math.max(transmissionTime, task.getRemainData()
				/ (cloudTag == Constant.PRIVATE_CLOUD ? Constant.BANDWIDTH_INTRA : Constant.BANDWIDTH_INTER));
		return transmissionTime;
	}

	/**
	 * 获得空闲时间块：availTime和单位租赁时间间的差值
	 * 
	 * @param task
	 * 
	 * @param rentVm
	 * @return
	 */
	private List<IdleSlot> getIdleSlot(Task task, List<MyVM> rentVm) {
		List<IdleSlot> list = new LinkedList<>();
		for (MyVM vm : rentVm) {
			// Step1 获得gap
			double endTime = vm.getEndTime(); // 在租赁时，算好虚拟机的租赁结束时间endTime
			double availTime = vm.getAvailTime();
			IdleSlot slot = new IdleSlot(availTime, endTime);
			// Step2 判断slot是否满足Task需要
			// 假如任务要在该虚拟机上执行，endTime - availTime > 数据传输时间+执行时间，且满足任务子截止期
			double startTime = Math.max(availTime, task.stage.EST); // 受前驱Stage完工时间限制
			double executionTime = task.instructions / vm.getProcessSpeed();
			double transmissionTime = calTransmissionTime(task, Constant.PUBLIC_CLOUD);
			double finishTime = startTime + transmissionTime + executionTime;
			boolean flag = (CalculateUtils.compareDouble(finishTime, endTime) <= 0)
					&& (CalculateUtils.compareDouble(finishTime, task.stage.getSubDeadline()) <= 0);
			if (flag) {
				slot.setVm(vm);
				list.add(slot);
			}
		}
		return list;
	}

	/**
	 * 调度结果调整 哇呀呀呀呀呀呀！
	 */
	private void scheduleResultAdjust() {
		// TODO
		// Step0 更新Stage信息：最早开始时间（取决于前驱的结束时间），最晚结束时间（取决于后继的开始时间）
		// 按拓扑顺序遍历Stage，更新EST，LFT
		updateStageTimeParameter();

		// Step1 查询私有云和已租赁虚拟机的空闲时间块
		List<IdleSlot> idleList = new LinkedList<>();
		List<MyVM> privateVM = resourcePool.getPrivateCloud();
		List<MyVM> rentedVM = resourcePool.getRentVm();
		// 私有云上空闲时间块统计
		getIdleSlot(idleList, privateVM);
		// 已租赁虚拟机上空闲块统计
		getIdleSlot(idleList, rentedVM);

		// Step2 将已租赁虚拟机按排序因子排序
		Collections.sort(rentedVM, new Comparator<MyVM>() {
			@Override
			public int compare(MyVM vm1, MyVM vm2) {
				// TODO Auto-generated method stub
				int taskNum1 = vm1.getTasks().size();
				int sum1 = 0;
				int taskNum2 = vm2.getTasks().size();
				int sum2 = 0;
				for (int i = 0; i < vm1.getTasks().size(); i++) {
					sum1 += vm1.getTasks().get(i).instructions;
				}
				for (int i = 0; i < vm2.getTasks().size(); i++) {
					sum2 += vm2.getTasks().get(i).instructions;
				}
				double factor1 = 0;
				double factor2 = 0;
				try {
					factor1 = taskNum1 / sum1;
					factor2 = taskNum2 / sum2;
				}catch(ArithmeticException e) {
					e.printStackTrace();
				}
				if (factor1 <= factor2) {
					return -1;
				} else {
					return 1;
				}
			}
		});
		// Step3 移动任务：搜索合适安排任务的位置
		boolean flag = true; // 是否完成了减少一个已租赁虚拟机
		for (MyVM vm : rentedVM) {
			if (vm.isUsed()) {
				List<Task> taskList = vm.getTasks();
				for (Task task : taskList) {
					IdleSlot toIdleSlot = moveTaskToWhere(task, idleList);
					if (toIdleSlot != null) {
						// flag = true;
						// 移动任务，更新参数
						List<IdleSlot> slot = moveTaskToVM(task, toIdleSlot);
						// 更新空闲列表：删除旧的空闲时间块，新增新的空闲时间块
						idleList.remove(toIdleSlot);
						idleList.addAll(slot);
					} else {
						// 该任务无法移动，无法减少租赁虚拟机数量
						flag = false;
						break;
					}
				}
				if (flag) {
					// 将当前虚拟机移除list，如何完成？
					vm.setUsed(false);
					// TODO 需要对虚拟机重新排序，我觉得我做不到
				} else {
					break;
				}
			}
		}
		// End
	}

	/**
	 * 更新Spark应用中Stage的时间参数：EST，LFT
	 */
	private void updateStageTimeParameter() {
		// TODO 是否要根据Task更新Stage的AST和AFT？似乎不需要
		List<Job> jobList = this.application.jobList;
		for (Job job : jobList) {
			List<Stage> stageList = job.stageList;
			// 更新EST
			for (Stage stage : stageList) {
				if (stage.parentStages == null || stage.parentStages.size() == 0) {
					stage.EST = 0;
				}
				List<Stage> childStages = stage.childStages;
				for (Stage child : childStages) {
					child.EST = Math.max(stage.getAFT(), child.EST);
				}
			}
			// 更新LFT
			for (Stage stage : job.reverseStageList) {
				if (stage.childStages == null || stage.childStages.size() == 0) {
					stage.LFT = application.getDeadline();
				}
				List<Stage> parentStages = stage.parentStages;
				for (Stage parent : parentStages) {
					parent.LFT = Math.min(stage.getAST(), parent.LFT);
				}
			}
		}
	}

	/**
	 * 将任务task移动到toIdleSlot上
	 * 
	 * @param task
	 * @param toIdleSlot
	 * @return 返回新产生的空闲时间块
	 */
	private List<IdleSlot> moveTaskToVM(Task task, IdleSlot toIdleSlot) {
		// TODO Auto-generated method stub
		MyVM vm = toIdleSlot.getVm();
		vm.getTasks().add(task);
		// 修改空闲时间，并返回新的空闲时间块
		List<IdleSlot> list = new ArrayList<IdleSlot>();
		// TODO:对于很小的碎片，没必要返回，减少遍历时的复杂度
		if (toIdleSlot.getStartTime() > task.stage.EST) {
			IdleSlot leftSlot = new IdleSlot(toIdleSlot.getStartTime(), task.stage.EST);
			list.add(leftSlot);
		}
		double executionTime = task.instructions / toIdleSlot.getVm().getProcessSpeed();
		double finishTime = Math.max(toIdleSlot.getStartTime(), task.stage.EST) + executionTime;
		IdleSlot rightSlot = new IdleSlot(finishTime, toIdleSlot.getEndTime());
		list.add(rightSlot);
		return list;
	}

	/**
	 * 寻找能满足当前任务的空闲时间块 约束：任务开始时间大于等于最早开始时时间（其前驱的最晚结束时间） 空闲结束时间大于任务结束时间
	 * 任务结束时间小于最晚结束时间（其后继的实际开始时间）
	 * 
	 * @param task
	 * @param idleList
	 * @return
	 */
	private IdleSlot moveTaskToWhere(Task task, List<IdleSlot> idleList) {
		boolean flag = false;
		for (IdleSlot idle : idleList) {
			double startTime = idle.getStartTime();
			double endTime = idle.getEndTime();
			double executionTime = task.instructions / idle.getVm().getProcessSpeed();
			// TODO 判断开始时间是否满足任务最早开始时间
			flag = flag & (startTime + executionTime < endTime);
			flag = flag & (startTime + executionTime < task.stage.LFT);
			if (flag) {
				return idle;
			}
		}
		return null;
	}

	/**
	 * 获得空闲时间块
	 * 
	 * @param idleList 空闲时间块列表
	 * @param vmList   虚拟机列表
	 */
	private void getIdleSlot(List<IdleSlot> idleList, List<MyVM> vmList) {
		for (MyVM vm : vmList) {
			// Step1.1 排列Task
			List<Task> taskList = vm.getTasks();
			// TODO 再次涉及到double类型的比较问题，真可谓是，实践出真知，实干才能兴邦啊（胡言乱语）。
			Collections.sort(taskList, new Comparator<Task>() {
				@Override
				public int compare(Task task1, Task task2) {
					return CalculateUtils.compareDouble(task1.AST, task2.AST);
//					if(task1.AST <= task2.AST) {
//						return -1;
//					}else {
//						return 1;
//					} 
					// return (int) (task1.AST - task2.AST);
				}
			});
			double beginTime = 0;
			// Step1.2 搜索空闲块
			for (Task task : taskList) {
				double startTime = task.AST;
				double endTime = task.AFT;
				if (startTime > beginTime) {
					IdleSlot tmp = new IdleSlot(beginTime, startTime);
					idleList.add(tmp);
				}
				beginTime = endTime;
			}
			// 如果是公有云中虚拟机，添加结尾空闲时间块
			if (vm.getBelongCloud() == Constant.PUBLIC_CLOUD) {
				Task task = taskList.get(taskList.size() - 1);
				double finishTime = task.AFT;
				IdleSlot slot = new IdleSlot(finishTime, vm.getEndTime());
				idleList.add(slot);
			}
		}
	}

}
