package com.algorithm;

import java.util.List;

import org.cloudbus.cloudsim.Vm;

import com.application.SparkApplication;
import com.resource.ResourcePool;
import com.resource.VmType;

/**
 * @Author Ivan 15:49 2019/12/4
 * @Description TODO 调度器的抽象类
 */
public abstract class Scheduler {

    private SparkApplication application;

    private List<VmType> types;

    private List<Vm> vmList;

    private ResourcePool resourcePool;

    public void setApplication(SparkApplication application) {
        this.application = application;
    }

    public void setTypes(List<VmType> types) {
        this.types = types;
    }

    public void setVmList(List<Vm> vmList) {
        this.vmList = vmList;
    }

    public void setResourcePool(ResourcePool resourcePool) {
        this.resourcePool = resourcePool;
    }

    public SparkApplication getApplication() {
        return application;
    }

    public List<VmType> getTypes() {
        return types;
    }

    public List<Vm> getVmList() {
        return vmList;
    }

    public ResourcePool getResourcePool() {
        return resourcePool;
    }

    public Scheduler(SparkApplication application, List<VmType> types, ResourcePool resourcePool) {
        this.application = application;
        this.types = types;
        this.resourcePool = resourcePool;
    }

    public Scheduler() {
    }

    /**
     * 启动调度
     */
    // ps：将app，types和资源池从Scheduler中抽象出来，即调度的输入参数是：app和资源情况
    public abstract void runSchedule();

    //获取租赁成本
    public abstract double getTotalCost();
}
