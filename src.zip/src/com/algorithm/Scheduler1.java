package com.algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.algorithm.stagePriority.MinSlackTimeStagePriority;
import com.algorithm.stagePriority.StagePriority;
import com.algorithm.subDeadline.LevelBasedSubDeadline2;
import com.algorithm.subDeadline.SubDeadline;
import com.algorithm.taskPriority.TaskPriority;
import com.algorithm.taskPriority.UpRankTaskPriority;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;
import com.resource.Period;

/**
 * 启发式任务调度
 * @author ShirleyLee
 *
 */
public class Scheduler1 extends MyScheduler {

	private double latestFinishTime; 
	
	@Override
	public double runSchedule(SparkApplication app, MyResourcePool resourcePool) {
		// TODO Auto-generated method stub
		this.application = app;
		this.resourcePool = resourcePool;
		// 记录调度开始时间
		double startTime = System.currentTimeMillis();
		// Step1 计算子截止期
		SubDeadline deadline = new LevelBasedSubDeadline2();
		deadline.divideSubDeadline(app);
		
		// Step2 执行调度过程
		HashSet<Stage> readyStages = addStartStages(application);
		List<Stage> stageList = new ArrayList<>(readyStages);
		while (!readyStages.isEmpty()) {
			// Step2.1 获得最高优先级的Stage
			StagePriority stagePriority = new MinSlackTimeStagePriority();
			Stage stage = stagePriority.highPriorityStage(stageList);
			// Step2.2 Stage调度
			stageSchedule(stage);
			readyStages.remove(stage);
			stage.scheduled = true; // 标记该Stage已调度，用于添加后继Stage
			// Step2.3 更新时间参数
			updateStageTimeParam(stage);
			// Step2.4 添加后继Stage
			addSuccessorStage(stage, readyStages);
		}
		
		// Step3 调度结果调整
		adjustScheduleResult();
		
		// Step4 记录调度结束时间
		double endTime = System.currentTimeMillis();
		this.setTimeCost(endTime - startTime);
		// 更新调度器的makespan = 最后一个任务的结束时间 - 第一个任务的开始时间（0）
		this.setMakespan(this.latestFinishTime);
		this.setCost(calScheduleCost()); // 更新租赁费用
		return 0;
	}

	/**
	 * 更新Stage的时间参数
	 * @param stage
	 */
	private void updateStageTimeParam(Stage stage) {
		// Step1 更新当前Stage的参数
		List<Task> taskList = stage.taskList;
		stage.endTime = taskList.get(0).AFT;
		for(int i = 0; i < taskList.size(); i++) {
			stage.endTime = Math.max(stage.endTime, taskList.get(i).AFT);
		}
		// Step2 更新后继Stage的参数：EST,EFT
		List<Stage> succ = stage.childStages; 
		for(int i = 0; i < succ.size(); i++) {
			Stage cur = succ.get(i);
			if(cur.EST < stage.endTime) {
				cur.EST = stage.endTime;
			}else {
				// 否则，遍历cur的所有前驱Stage
				List<Stage> pre = cur.parentStages;
				double tmp = stage.endTime;
				for(int j = 0; j < pre.size(); j++) {
					if(pre.get(j) == stage) {
						continue;
					}else {
						tmp = Math.max(tmp, pre.get(j).EFT);
					}
				}
				cur.EST = tmp;
			}
		}
	}

	/**
	 * 调整调度结果
	 * @param app
	 * @param resourcePool
	 */
	private void adjustScheduleResult() {
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * Stage调度
	 * @param stage
	 */
	private void stageSchedule(Stage stage) {
		// TODO Auto-generated method stub
		// Step1 任务排序
		TaskPriority priority = new UpRankTaskPriority();
		List<Task> taskList = priority.taskSequence(stage);
		// Step2 任务调度
		for (int i = 0; i < taskList.size(); i++) {
			Task cur = taskList.get(i);
			if (cur.isSensitiveTask()) {
				privateTaskSchedule(cur);
			} else {
				nonPrivateTaskSchedule(cur);
			}
			// 更新任务的最晚完成时间
			this.latestFinishTime = Math.max(latestFinishTime, cur.AFT);
		}
		
		
	}

	/**
	 * 写这注释有什么用 没点核心
	 * @param cur
	 */
	private void nonPrivateTaskSchedule(Task task) {
		// TODO Auto-generated method stub
		MyVM selectVM = null;
		// Step1 已租赁机器中：找首个满足执行时间要求的VM
		List<MyVM> list = resourcePool.getRentVm();
		if (list.size() != 0) {
			// 比较：Task在该VM上执行用时+传输时间与虚拟机租赁结束时间的大小
			for (int i = 0; i < list.size(); i++) {
				MyVM vm = list.get(i);
				double transferTime = calTransferTime(task, vm);
				double processTime = calProcessTime(task, vm);
				// 暂时取首次适应法，选择公有云中可用虚拟机
				int range = getRangeByUnitTime(vm.getRentUnitTime());
				int times = 1;
				// TODO 可降低时间复杂度
				while (true) {
					if (times * range > vm.getEndTime()) {
						break;
					}
					times++;
				}
				// 若空余时间满足任务时间传输+执行时间
				if (range * times - vm.getEndTime() > (transferTime + processTime)) {
					selectVM = vm;
					break;
				}
			}
		}
		
		// Step2 私有云中
		double taskStartTime = task.stage.EST; // 最早开始时间
		if (selectVM == null) {
			List<MyVM> vmList = resourcePool.getPrivateCloud();
			for (int i = 0; i < vmList.size(); i++) {
				// 同样是找第一个满足条件的VM
				MyVM vm = vmList.get(i);
				if (taskStartTime >= vm.getAvailTime()) {
					selectVM = vm;
					break;
				}
			}
		}
		
		// Step3 租赁新机器
		if (selectVM == null) {
			// 采用最大剩余空余时间优先，租赁虚拟机
			List<MyVMType> typeList = resourcePool.getPublicVMType();
			double maxRemainTime = 0;
			MyVMType selectType = null;
			for (int i = 0; i < typeList.size(); i++) {
				MyVMType type = typeList.get(i);
				double transferTime = calTransferTime(task, type);
				double processTime = calProcessTime(task, type);
				// 考虑单位时间内任务不能执行完成的情况
				int range = getRangeByUnitTime(type.getRentUnitTime());
				int times = 1; // 记录当前任务需要多少个任务周期执行
				while (true) {
					if (range * times < (transferTime + processTime) ) {
						times++;
					} else {
						break;
					}
				}
				double remainTime = range * times - (transferTime + processTime);
				if (remainTime >= maxRemainTime) {
					maxRemainTime = remainTime;
					selectType = type;
				}
			}
			// 初始化选中虚拟机类型的实例
			MyVM vm = new MyVM(selectType);
			vm.setStartTime(taskStartTime);
			vm.setAvailTime(taskStartTime);
			double transferTime = calTransferTime(task, vm);
			double processTime = calProcessTime(task, vm);
			vm.setEndTime(taskStartTime + transferTime + processTime);
			vm.setMap(new HashMap<Task, Period>()); // 任务和使用时间阶段映射
			resourcePool.getRentVm().add(vm);// 添加该VM到已租赁资源中
			// 选中当前虚拟机
			selectVM = vm;
		}
		
		// Step4 任务资源匹配
		mapTaskAndVM(task, selectVM);
		
	}

	/**
	 * 隐私任务调度，机器选择标准：最早完工时间优先
	 * @param curs
	 */
	private void privateTaskSchedule(Task task) {
		List<MyVM> list = resourcePool.getPrivateCloud();
		// 虚拟机选择标准：最早可用时间
		double earlistFinishTime = Double.MAX_VALUE;
		MyVM selectVM = null;
		for (int i = 1; i < list.size(); i++) {
			MyVM cur = list.get(i);
			double sum = 0;
			for(Task pre : task.getPrecursorTask().keySet()) {
				sum = Math.max(sum, calTransferTime(task, cur));
			}
			sum += calProcessTime(task, cur);
			if(sum < earlistFinishTime) {
				selectVM = cur;
				earlistFinishTime = sum;
			}
		}
		// 将该任务安排到该资源中；时隔多日，我已经不知道自己写了写啥了
		mapTaskAndVM(task, selectVM);
	}

}














