package com.algorithm.fifo;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.algorithm.Scheduler;
import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.resource.ResourcePool;
import com.resource.VM;
import com.resource.VmType;

public class FIFOScheduler extends Scheduler {

	public FIFOScheduler(SparkApplication application, List<VmType> types, ResourcePool resourcePool) {
		super(application, types, resourcePool);
	}

	/**
	 * 
	 */
	@Override
	public void runSchedule() {
		SparkApplication application = getApplication();
		ResourcePool resourcePool = getResourcePool();

		List<Job> startJobs = application.jobList;
		Queue<Job> jobQueue = new LinkedList<>(startJobs);
		while (!jobQueue.isEmpty()) {
			Job job = jobQueue.poll();
			Queue<Stage> stageQueue = new LinkedList<>(job.stageList);
			while (!stageQueue.isEmpty()) {
				Stage stage = stageQueue.poll();
				Queue<Task> taskQueue = new LinkedList<>(stage.taskList);
				dynamicResourceSchedule(resourcePool, taskQueue, 0);
			}
		}
	}

	/**
	 * 资源调度：为任务队列分配资源
	 * 
	 * @param resourcePool
	 * @param tasks
	 * @param BTU 时间单位
	 */
	private void dynamicResourceSchedule(ResourcePool resourcePool, Queue<Task> tasks, int BTU) {
		List<VM> vmLeasingList = resourcePool.getVmLeasingList();
		List<VM> vmReleasedList = resourcePool.getVmReleasedList();
		for (Task task : tasks) {
			VM vm;
			vm = resourcePool.leaseNewVm(new VmType(1), BTU);
			/*
			if (vmLeasingList.size() == 0) {
				vm = resourcePool.leaseNewVm(new VmType(1), BTU);
			} else {
				// 选择可用资源列表中第一个VM作为分配当前task的VM
				vm = resourcePool.getEligibleVms(task, 0.00).remove(0);
			}
			*/
			resourcePool.placeTaskOnVm(task, vm);
		}
	}

	@Override
	public double getTotalCost() {
		return getResourcePool().getTotalCost();
	}
}
