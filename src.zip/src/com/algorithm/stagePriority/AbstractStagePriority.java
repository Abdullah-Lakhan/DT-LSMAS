package com.algorithm.stagePriority;

import java.util.List;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

public abstract class AbstractStagePriority implements StagePriority {

	public abstract Stage highPriorityStage(List<Stage> list);
	
	/**
	 * 计算Spark应用中Job的优先级（作为Stage的排序因子）
	 * @param app
	 */
	public void calJobPriority(SparkApplication app) {
		List<Job> jobList = app.jobList;
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			double priority = (app.getDeadline() - job.getSubDeadline()) / app.getDeadline();
			job.setPriority(priority);
		}
	}

}
