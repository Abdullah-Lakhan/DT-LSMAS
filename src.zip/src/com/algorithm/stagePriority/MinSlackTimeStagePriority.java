package com.algorithm.stagePriority;

import java.util.List;

import com.application.Stage;

/**
 * 最小松弛时间优先原则
 * @author ShirleyLee
 *
 */
public class MinSlackTimeStagePriority extends AbstractStagePriority {

	@Override
	public Stage highPriorityStage(List<Stage> list) {
		// TODO Auto-generated method stub
		double min = Double.MAX_VALUE;
		Stage res = null;
		for(int i = 0; i < list.size(); i++) {
			Stage stage = list.get(i);
			double slackTime = stage.getSubDeadline() - stage.EFT;
			if(slackTime < min) {
				min = slackTime;
				res = stage;
			}
		}
		return res;
	}
	
}
