package com.algorithm.stagePriority;

import java.util.List;

import com.application.Stage;

/** 
 * Stage优先级
 * @author ShirleyLee
 *
 */
public interface StagePriority {
	Stage highPriorityStage(List<Stage> list);
}
