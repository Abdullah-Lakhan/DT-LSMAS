package com.algorithm.stagePriority;

import java.util.List;

import com.application.Stage;
import com.application.Task;

/**
 * 基于任务的Stage优先级确定
 * @author ShirleyLee
 *
 */
public class TaskBasedStagePriority extends AbstractStagePriority {

	// double priority = slackTime * stage.job.getPriority();
	@Override
	public Stage highPriorityStage(List<Stage> list) {
		// TODO Auto-generated method stub
		double total = Double.MAX_VALUE;
		Stage res = null;
		for(int i = 0; i < list.size(); i++) {
			Stage stage = list.get(i);
			List<Task> taskList = stage.taskList;
			double tmp = 0d;
			for(int j = 0; j < taskList.size(); j++) {
				tmp += taskList.get(j).instructions;
			}
			if(tmp > total) {
				total = tmp;
				res = stage;
			}
		}
		return res;
	}

}
