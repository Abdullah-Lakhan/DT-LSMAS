package com.algorithm.stageSequence;

public abstract class AbstractStageSequence implements StageSequence{
	
}
