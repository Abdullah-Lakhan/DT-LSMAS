package com.algorithm.stageSequence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.utils.CalculateUtils;

/**
 * 最大Rank值优先
 * 
 * @author ShirleyLee
 *
 */
public class MaxRankFirstSequence extends AbstractStageSequence {

	@Override
	public List<Stage> sequence(SparkApplication app) {
		List<Stage> seq = new LinkedList<>();
		// Step1 获得各层的Job
		int maxLevel = 1;
		Map<Integer, List<Job>> map = new HashMap<>();
		for (Job job : app.jobList) {
			List<Job> list = map.getOrDefault(job.getLevel(), new ArrayList<Job>());
			list.add(job);
			map.put(job.getLevel(), list);
			maxLevel = Math.max(maxLevel, job.getLevel());
		}

		// Step2 对于每一层Job，根据Stage的rank值，排序
		for (int i = 1; i <= maxLevel; i++) {
			List<Job> jobs = map.get(i);
			List<Stage> list = new LinkedList<>();
			for (Job job : jobs) {
				list.addAll(job.stageList);
			}
			Collections.sort(list, new Comparator<Stage>() {
				@Override
				public int compare(Stage stage1, Stage stage2) {
					return CalculateUtils.compareDouble(stage2.getUprank(), stage1.getUprank());
//					if(stage1.getUprank() >= stage2.getUprank()) {
//						return -1;
//					}else {
//						return 1;
//					}
				}
			});
			seq.addAll(list);
		}
		return seq;
	}

}
