package com.algorithm.stageSequence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.utils.CalculateUtils;

public class MinSlackTimeFirstSequence extends AbstractStageSequence {

	@Override
	public List<Stage> sequence(SparkApplication app) {
		// TODO Auto-generated method stub
		List<Stage> seq = new LinkedList<>();
		// Step1 获得各层的Job
		int maxLevel = 1;
		Map<Integer, List<Job>> map = new HashMap<>();
		for (Job job : app.jobList) {
			List<Job> list = map.getOrDefault(job.getLevel(), new ArrayList<Job>());
			list.add(job);
			map.put(job.getLevel(), list);
			maxLevel = Math.max(maxLevel, job.getLevel());
		}

		// Step2 按松弛时间，从小到大排序
		for (int i = 1; i <= maxLevel; i++) {
			List<Job> jobs = map.get(i);
			List<Stage> list = new LinkedList<>();
			for (Job job : jobs) {
				list.addAll(job.stageList);
			}

			// 1.将这些Stage按层划分之后，再按slack进行排序（保证偏序关系）
			Map<Integer, List<Stage>> stageMap = new HashMap<>();
			int tmpMax = 1;
			for (Stage stage : list) {
				List<Stage> tmp = stageMap.getOrDefault(stage.getLevel(), new ArrayList<Stage>());
				tmp.add(stage);
				stageMap.put(stage.getLevel(), tmp);
				tmpMax = Math.max(tmpMax, stage.getLevel());
			}

			// 2.获得stage列表
			list.clear();
			for (int j = 1; j <= tmpMax; j++) {
				// list.addAll(stageMap.get(j));
				// 开始时间的浮动时间。（其他可用定义：最早结束时间与截止期之间的差值9）
				List<Stage> tmpList = stageMap.get(j);
				Collections.sort(tmpList, new Comparator<Stage>() {
					@Override
					public int compare(Stage stage1, Stage stage2) {
//					double slack1 = stage1.getSubDeadline() - stage1.EFT;
//					double slack2 = stage2.getSubDeadline() - stage2.EFT;
						double slack1 = stage1.LFT - stage1.EFT;
						double slack2 = stage2.LFT - stage2.EFT;
						return CalculateUtils.compareDouble(slack1, slack2);
//					if(slack1 <= slack2) {
//						return -1;
//					}else {
//						return 1;
//					}
					}
				});
				list.addAll(tmpList);
			}
			seq.addAll(list);
		}
		return seq;
	}

}
