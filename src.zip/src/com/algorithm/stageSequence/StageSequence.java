package com.algorithm.stageSequence;

import java.util.List;

import com.application.SparkApplication;
import com.application.Stage;

public interface StageSequence {
	List<Stage> sequence(SparkApplication app);
}
