package com.algorithm.stageSequence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;

public class TaskBasedRuleSequence extends AbstractStageSequence {

	@Override
	public List<Stage> sequence(SparkApplication app) {
		// TODO Auto-generated method stub
		List<Stage> seq = new LinkedList<>();
		// Step1 获得各层的Job
		int maxLevel = 1;
		Map<Integer, List<Job>> map = new HashMap<>();
		for (Job job : app.jobList) {
			List<Job> list = map.getOrDefault(job.getLevel(), new ArrayList<Job>());
			list.add(job);
			map.put(job.getLevel(), list);
			maxLevel = Math.max(maxLevel, job.getLevel());
		}

		// Step2 按task特点排序
		for (int i = 1; i <= maxLevel; i++) {
			List<Job> jobs = map.get(i);
			List<Stage> list = new LinkedList<>();
			for (Job job : jobs) {
				list.addAll(job.stageList);
			}

			// 1.将这些Stage按层划分之后，再按slack进行排序（保证偏序关系）
			Map<Integer, List<Stage>> stageMap = new HashMap<>();
			int tmpMax = 1;
			for (Stage stage : list) {
				List<Stage> tmp = stageMap.getOrDefault(stage.getLevel(), new ArrayList<Stage>());
				tmp.add(stage);
				stageMap.put(stage.getLevel(), tmp);
				tmpMax = Math.max(tmpMax, stage.getLevel());
			}

			// 2.获得stage列表
			list.clear();
			for (int j = 1; j <= tmpMax; j++) {
				List<Stage> tmpList = stageMap.get(j);
				// 基于Task特点的Stage排序：首先比较隐私任务个数；其次比较Stage中包含的任务指令数之和
				Collections.sort(tmpList, new Comparator<Stage>() {
					@Override
					public int compare(Stage stage1, Stage stage2) {
						// TODO Auto-generated method stub
						// 统计Stage1和Stage2中的隐私任务数量和所有任务的指令数之和
						int privacyNum1 = 0, privacyNum2 = 0;
						int instructionSum1 = 0, instructionSum2 = 0;
						for (Task task : stage1.taskList) {
							if (task.isSensitiveTask()) {
								privacyNum1++;
							}
							instructionSum1 += task.instructions;
						}
						for (Task task : stage2.taskList) {
							if (task.isSensitiveTask()) {
								privacyNum2++;
							}
							instructionSum2 += task.instructions;
						}
						if (privacyNum1 != privacyNum2) {
							if (privacyNum1 > privacyNum2) {
								return -1;
							} else {
								return 1;
							}
						} else {
							if (instructionSum1 >= instructionSum2) {
								return -1;
							} else {
								return 1;
							}
						}
					}
				});
				list.addAll(tmpList);
			}
			/*			Collections.sort(list, new Comparator<Stage>() {
							@Override
							public int compare(Stage stage1, Stage stage2) {
								double priority1 = calPriorityBaseTask(stage1);
								double priority2 = calPriorityBaseTask(stage2);
								if(priority1 != priority2) {
									return (int) (priority2 - priority1);
								}else if(stage2.taskNum >= stage1.taskNum){
									return -1;
								}else {
									return 1;
								}
							}
						});*/

			seq.addAll(list);
		}
		return seq;
	}

	protected double calPriorityBaseTask(Stage stage) {
		// TODO Auto-generated method stub
		double priority = 0;
		double data = 0;
		double senCount = 0;
		for (Task task : stage.taskList) {
			data += task.instructions;
			if (task.isSensitiveTask())
				senCount++;
		}
		priority = 0.5 * data + 0.5 * senCount / stage.taskNum;
		return priority;
	}

}
