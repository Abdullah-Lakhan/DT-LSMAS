package com.algorithm.subDeadline;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

public abstract class AbstractSubDeadline implements SubDeadline {

	public abstract void divideSubDeadline(SparkApplication app);

	public abstract void divideSubDeadline(Job job);

	public Map<Integer, List<Job>> calJobLevelForward(SparkApplication app) {
		Map<Integer, List<Job>> levelMap = new HashMap<>();// 映射关系为：层次 - 该层的Job列表；便于后续更新每层Job的子截止期
		List<Job> jobList = app.jobList;
		for (int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			int level;
			if (job.parentJobs == null || job.parentJobs.size() == 0) {
				level = 1;
			} else {
				int max = 0;
				for (int j = 0; j < job.parentJobs.size(); j++) {
					max = Math.max(max, job.parentJobs.get(j).getLevel());
				}
				level = max + 1;
			}
			job.setLevel(level);
			List<Job> list = levelMap.getOrDefault(level, new ArrayList<Job>());
			list.add(job);
			levelMap.put(level, list);
			// 划分该Job中Stage的层次
			calStageLevelForward(job);
		}
		return levelMap;
	}

	public Map<Integer, List<Job>> calJobLevelBackward(SparkApplication app) {
		Map<Integer, List<Job>> levelMap = new HashMap<>();// 映射关系为：层次 - 该层的Job列表；便于后续更新每层Job的子截止期
		List<Job> jobList = app.reverseJobList; // 获得拓扑逆序的Job列表
		for (int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			int level;
			if (job.childJobs == null || job.childJobs.size() == 0) {
				level = 1;
			} else {
				// Job的层次等于其子Job中层次最大的+1
				int max = 0;
				for (int j = 0; j < job.childJobs.size(); j++) {
					max = Math.max(max, job.childJobs.get(j).getLevel());
				}
				level = max + 1;
			}
			job.setLevel(level);
			List<Job> list = levelMap.getOrDefault(level, new ArrayList<Job>());
			list.add(job);
			levelMap.put(level, list);
		}
		return levelMap;
	}

	public Map<Integer, List<Stage>> calStageLevelForward(Job job) {
		// TODO
		Map<Integer, List<Stage>> levelMap = new HashMap<>();
		List<Stage> stageList = job.stageList;
		for (int i = 0; i < stageList.size(); i++) {
			Stage stage = stageList.get(i);
			int level;
			if (stage.parentStages == null || stage.parentStages.size() == 0) {
				level = 1;
			} else {
				int max = 0;
				for (int j = 0; j < stage.parentStages.size(); j++) {
					max = Math.max(max, stage.parentStages.get(j).getLevel());
				}
				level = max + 1;
			}
			stage.setLevel(level);
			List<Stage> list = levelMap.getOrDefault(level, new ArrayList<Stage>());
			list.add(stage);
			levelMap.put(level, list);
		}
		return levelMap;
	}

	public Map<Integer, List<Stage>> calStageLevelBackward(Job job) {
		// TODO
		Map<Integer, List<Stage>> levelMap = new HashMap<>();// 映射关系为：层次 - 该层的Stage列表
		List<Stage> stageList = job.reverseStageList; // 获得拓扑逆序的Job列表
		for (int i = 0; i < stageList.size(); i++) {
			Stage stage = stageList.get(i);
			int level;
			if (stage.childStages == null || stage.childStages.size() == 0) {
				level = 1;
			} else {
				// Job的层次等于其子Job中层次最大的+1
				int max = 0;
				for (int j = 0; j < stage.childStages.size(); j++) {
					max = Math.max(max, stage.childStages.get(j).getLevel());
				}
				level = max + 1;
			}
			stage.setLevel(level);
			List<Stage> list = levelMap.getOrDefault(level, new ArrayList<Stage>());
			list.add(stage);
			levelMap.put(level, list);
		}
		return levelMap;
	}

	/**
	 * 计算Job的UpRank：最后一个节点的uprank=0；
	 * 排序时：按upRank从大到小排序
	 * 
	 * @param app
	 * @return
	 */
	public double calJobUpRank(SparkApplication app) {
		double maxUpRank = 0; // 所有Job中最大的UpRank值
		// 1. 计算Job的执行时间=其中Stage的最早完工时间-Stage的最早开始时间
		for (Job job : app.jobList) {
			double processTime = Double.MIN_VALUE;
			double minEST = Double.MAX_VALUE;
			double maxEFT = Double.MIN_VALUE;
			for (Stage stage : job.stageList) {
				if (stage.EST < minEST) {
					minEST = stage.EST;
				}
				if (stage.EFT > maxEFT) {
					maxEFT = stage.EFT;
				}
			}
			processTime = maxEFT - minEST;
			job.setProcessTime(processTime);
		}
		// 2. 计算Job的UpRank
		for (Job job : app.reverseJobList) {
			if (job.childJobs.size() == 0) {
				job.setUprank(0);
			} else {
				double tmp = Double.MIN_VALUE;
				for (Job child : job.childJobs) {
					tmp = Math.max(tmp, child.getUprank() + child.getProcessTime());
				}
				// 保留两位小数
				tmp = (double) Math.round(tmp * 100) / 100;
				job.setUprank(tmp);
			}
			if (job.getUprank() > maxUpRank) {
				maxUpRank = job.getUprank();
			}
			calStageUpRank(job);
		}
		return maxUpRank;
	}

	/**
	 * 计算Stage的UpRank
	 * 
	 * @param job
	 * @return
	 */
	public double calStageUpRank(Job job) {
		double maxRank = 0;
		for (Stage stage : job.reverseStageList) {
			if (stage.childStages.size() == 0) {
				stage.setUprank(0);
			} else {
				double tmp = Double.MIN_VALUE;
				for (Stage child : stage.childStages) {
					tmp = Math.max(tmp, child.getUprank() + child.estimateDuration);
				}
				// 保留两位小数
				tmp = (double) Math.round(tmp * 100) / 100;
				stage.setUprank(tmp);
				maxRank = Math.max(maxRank, stage.getUprank());
			}
		}
		return maxRank;
	}

}
