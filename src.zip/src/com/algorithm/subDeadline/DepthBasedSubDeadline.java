package com.algorithm.subDeadline;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

/**
 * 基于深度的子截止期划分
 * @author ShirleyLee
 *
 */
public class DepthBasedSubDeadline extends AbstractSubDeadline {

	/**
	 * 步骤：
	 * 1）计算浮动时间 = 截止期 - 最后一个Job的EFT
	 * 2）计算每个Job的深度
	 * 3）将浮动时间按层次比例，分配给各个Job
	 */
	@Override
	public void divideSubDeadline(SparkApplication app) {
		Map<Integer, List<Job>> levelMap = new HashMap<>();
		// Step1 计算读懂时间
		double floatTime = 0;
		floatTime = app.getDeadline() - app.getEFT();
		// Step2 计算Job的深度，自前向后
		levelMap = calJobLevelForward(app);
		// Step3 划分浮动时间
		// 获得最大深度
		int depth = 0;
		for(Integer cur : levelMap.keySet()) {
			depth = Math.max(depth, cur);
		}
		// 计算每个Job的子截止期
		List<Job> jobList = app.jobList;
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			int level = job.getLevel();
			double subDeadline = job.EFT + level / depth * floatTime;
			job.setSubDeadline(subDeadline);
		}
		// Step4 计算每个Job中Stage的截止期
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			divideSubDeadline(job);
		}
	}

	@Override
	public void divideSubDeadline(Job job) {
		// TODO Auto-generated method stub
		Map<Integer, List<Stage>> levelMap = new HashMap<>();
		// Step1 计算读懂时间
		double floatTime = 0;
		floatTime = job.getSubDeadline() - job.EFT;
		// Step2 计算Job的深度，自前向后
		levelMap = calStageLevelForward(job);
		// Step3 划分浮动时间
		// 获得最大深度
		int depth = 0;
		for(Integer cur : levelMap.keySet()) {
			depth = Math.max(depth, cur);
		}
		// 计算每个Job的子截止期
		List<Stage> stageList = job.stageList;
		for(int i = 0; i < stageList.size(); i++) {
			Stage stage = stageList.get(i);
			int level = stage.getLevel();
			double subDeadline = stage.EFT + level / depth * floatTime;
			stage.setSubDeadline(subDeadline);
		}
	}

}





