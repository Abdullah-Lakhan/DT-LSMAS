package com.algorithm.subDeadline;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

/**
 * 基于执行时间的松弛时间划分
 * @author ShirleyLee
 *
 */
public class ExecutionBasedSubDeadline extends AbstractSubDeadline {

	@Override
	public void divideSubDeadline(SparkApplication app) {
		// Step1 获得app的松弛时间
		double eft = Double.MIN_VALUE;
		for(Job job : app.jobList) {
			eft = Math.max(eft, job.EFT);
		}
		double slackTime = app.getDeadline() - eft;
		
		// Step2 计算各Job的子截止期
		for(Job job : app.jobList) {
			double tmp = job.EFT + job.EFT / eft * slackTime;
			job.setSubDeadline(tmp);
			// Step3 设置Stage的子截止期
			divideSubDeadline(job);
		}

	}

	@Override
	public void divideSubDeadline(Job job) {
		// Step1 获得Job的松弛时间
		double slackTime = job.getSubDeadline() - job.EFT;
		// Step2 计算各Stage的子截止期
		for(Stage stage : job.stageList) {
			double tmp = stage.EFT + stage.EFT / job.EFT * slackTime;
			stage.setSubDeadline(tmp);
		}
	}

}
