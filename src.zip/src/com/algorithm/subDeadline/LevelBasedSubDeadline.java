package com.algorithm.subDeadline;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

/**
 * 基于层的松弛时间划分
 * @author ShirleyLee
 *
 */
public class LevelBasedSubDeadline extends AbstractSubDeadline {

	@Override
	public void divideSubDeadline(SparkApplication app) {
		// Step1 确定各Job的层次，已在之前完成
		// calJobLevelForward(app);
		
		// Step2 获得app松弛时间、最大层次
		int l_max = 1;
		double maxeft = 0; // 最晚结束时间of Spark Application，为计算slackTime
		for(Job job : app.jobList) {
			l_max = Math.max(l_max, job.getLevel());
			maxeft = Math.max(maxeft, job.EFT);
		}
		
		double slackTime = app.getDeadline() - maxeft;
		
		// Step3 按层划分子截止期
		for(Job job : app.jobList) {
			double tmp = job.EFT + job.getLevel() / l_max * slackTime;
			job.setSubDeadline(tmp);
			// Step4 设置Stage的子截止期
			divideSubDeadline(job);
		}

	}

	@Override
	public void divideSubDeadline(Job job) {
		// Step1 获得Job的松弛时间
		double slackTime = job.getSubDeadline() - job.EFT;
		// Step2 计算各Stage层次
		// calStageLevelForward(job);
		
		// Step2.5 Stage中最大层次
		int l_max = 1;
		for(Stage stage : job.stageList) {
			l_max = Math.max(l_max, stage.getLevel());
		}
		
		// Step3 计算各Stage的子截止期
		for(Stage stage : job.stageList) {
			double tmp = stage.getLevel() + stage.getLevel() / l_max * slackTime;
			stage.setSubDeadline(tmp);
		}

	}

}
