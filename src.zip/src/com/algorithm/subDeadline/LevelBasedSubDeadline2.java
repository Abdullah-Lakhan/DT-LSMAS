package com.algorithm.subDeadline;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

/**
 * 基于层的子截止期划分方法
 * @author ShirleyLee
 *
 */
public class LevelBasedSubDeadline2  extends AbstractSubDeadline {

	/**
	 * 步骤：
	 * 1）确定Job的层次，从汇入节点开始算（汇入节点即没有孩子节点的节点）
	 * 2）统计每一层中具有最大EFT的Job，作为该层的初始子截止期
	 * 3）根据初始子截止期，计算每一层的子截止期
	 */
	@Override
	public void divideSubDeadline(SparkApplication app) {
		Map<Integer, List<Job>> levelMap = new HashMap<>();// 映射关系为：层次 - 该层的Job列表；便于后续更新每层Job的子截止期
		Map<Integer, Double> maxEFTMap = new HashMap<>();
		// Step1 确定Job层次
		// Step2 统计每层Job中具有最大EFT的Job
		List<Job> jobList = app.reverseJobList; // 获得拓扑逆序的Job列表
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			int level;
			if(job.childJobs == null || job.childJobs.size() == 0) {
				level = 1;
			}else {
				// Job的层次等于其子Job中层次最大的+1
				int max = 0;
				for(int j = 0; j < job.childJobs.size(); j++) {
					max = Math.max(max, job.childJobs.get(j).getLevel());
				}
				level = max + 1;
			}
			job.setLevel(level);
			List<Job> list = levelMap.getOrDefault(level, new ArrayList<Job>());
			list.add(job);
			levelMap.put(level, list);
			// 更新最大EFTMap
			double tmp = maxEFTMap.getOrDefault(level, 0d);
			tmp = Math.max(tmp, job.EFT);
			maxEFTMap.put(level, tmp);
		}
		// Step3 计算每一层的截止期
		double deadline = app.getDeadline();
		double pi = (deadline - maxEFTMap.get(1)) / maxEFTMap.get(1);
		for(Integer cur : maxEFTMap.keySet()) {
			// 计算截止期
			double sub = maxEFTMap.get(cur) + pi * maxEFTMap.get(cur);
			// 更新Job的截止期
			for(Job job : levelMap.get(cur)) {
				job.setSubDeadline(sub);
			}
		}
		// Step4 计算每个Job中Stage的截止期
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			divideSubDeadline(job);
		}
	}
	
	/**
	 * 获得Job中每个Stage的Sub-Deadline
	 * 异曲同工
	 */
	public void divideSubDeadline(Job job) {
		// TODO Auto-generated method stub
		Map<Integer, List<Stage>> levelMap = new HashMap<>();
		Map<Integer, Double> maxEFTMap = new HashMap<>();
		// Step1 获取Stage层次
		levelMap = calStageLevelBackward(job);
		// Step2 初始化每层的子截止期
		for(Integer cur : levelMap.keySet()) {
			List<Stage> stageList = levelMap.get(cur);
			double max = 0;
			for(Stage stage : stageList) {
				max = Math.max(max, stage.EFT);
			}
			maxEFTMap.put(cur, max);
		}
		// Step3 计算每一层的截止期
		double deadline = job.getSubDeadline();
		double pi = (deadline - maxEFTMap.get(1)) / maxEFTMap.get(1);
		for(Integer cur : maxEFTMap.keySet()) {
			// 计算截止期
			double sub = maxEFTMap.get(cur) + pi * maxEFTMap.get(cur);
			// 更新Job的截止期
			for(Stage stage : levelMap.get(cur)) {
				stage.setSubDeadline(sub);
			}
		}
	}

}











