package com.algorithm.subDeadline;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

/**
 * 基于关键路径的子截止期划分
 * @author ShirleyLee
 *
 */
public class PathBasedSubDeadline extends AbstractSubDeadline {

	@Override
	public void divideSubDeadline(SparkApplication app) {
		// Step1 计算Job的rank
		// double maxUpRank = calJobUpRank(app);
		double maxUpRank = 0;
		for(Job job : app.jobList) {
			maxUpRank = Math.max(maxUpRank, job.getUprank());
		}
		// Step2 计算Job的子截止期
		for(Job job : app.jobList) {
			// 已改
			double tmp = app.getDeadline() * ((maxUpRank - job.getUprank() + job.getProcessTime()) / maxUpRank);
			job.setSubDeadline(tmp);
			divideSubDeadline(job);
		}
		
	}

	@Override
	public void divideSubDeadline(Job job) {
		// TODO Auto-generated method stub
		// Step1 计算Stage的UpRank
		// double maxRank = calStageUpRank(job);
		double maxRank = 0;
		for(Stage stage : job.stageList) {
			maxRank = Math.max(maxRank, stage.getUprank());
		}
		
		// Step2 计算Stage的子截止期
		for(Stage stage : job.stageList) {
			double tmp = job.getSubDeadline() * ((maxRank - stage.getUprank() + stage.estimateDuration) / maxRank);
			stage.setSubDeadline(tmp);
		}
	}



}
