package com.algorithm.subDeadline;

import java.util.List;
import java.util.Map;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;

public interface SubDeadline {
	void divideSubDeadline(SparkApplication app);
	void divideSubDeadline(Job job);
	
	/**
	 * 计算Job的所在层次，自前向后
	 * @param app
	 * @return
	 */
	Map<Integer, List<Job>> calJobLevelForward(SparkApplication app);
	
	/**
	 * 计算Job所在层次，自后向前
	 * @param app
	 * @return
	 */
	Map<Integer, List<Job>> calJobLevelBackward(SparkApplication app);
	
	Map<Integer, List<Stage>> calStageLevelForward(Job job);
	Map<Integer, List<Stage>> calStageLevelBackward(Job job);
}
