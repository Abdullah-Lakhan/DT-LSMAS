package com.algorithm.taskPriority;

import java.util.List;

import com.application.Stage;
import com.application.Task;
import com.constant.Constant;

/**
 * 任务调度序列产生
 * @author ShirleyLee
 *
 */
public abstract class AbstractTaskPriority implements TaskPriority{
	
	/**
	 * 计算Task的UpRank
	 * 从后向前迭代
	 * @param taskList
	 */
	public void calUpRank(List<Task> taskList) {
		double bandwith = (Constant.BANDWIDTH_INTER + Constant.BANDWIDTH_INTRA) / 2;
		for(int i = 0; i < taskList.size(); i++) {
			Task task = taskList.get(i);
			if(task.successorTask == null || task.successorTask.size() == 0) {
				task.setUpRank(0);
			}else {
				// 遍历后继任务
				double max = 0;
				for(Task cur : task.successorTask.keySet()) {
					max = Math.max(max, task.successorTask.get(cur) / bandwith);
				}
				task.setUpRank(max + task.getEstimateProcessTime());
			}
		}
	}
	
	/**
	 * 计算Task的DownRank
	 * @param taskList
	 */
	public void calDownRank(List<Task> taskList) {
		double bandwith = (Constant.BANDWIDTH_INTER + Constant.BANDWIDTH_INTRA) / 2;
		for(int i = 0; i < taskList.size(); i++) {
			Task task = taskList.get(i);
			if(task.getPrecursorTask() == null || task.getPrecursorTask().size() == 0) {
				task.setDownRank(0);
			}else {
				double max = 0;
				for(Task cur : task.getPrecursorTask().keySet()) {
					max = Math.max(max, task.getPrecursorTask().get(cur) / bandwith);
				}
				task.setDownRank(max + task.getEstimateProcessTime());
			}
		}
	}
}







