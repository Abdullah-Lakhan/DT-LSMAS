package com.algorithm.taskPriority;

import java.util.Comparator;
import java.util.List;

import com.application.Stage;
import com.application.Task;

public class DownRankTaskPriority extends AbstractTaskPriority {

	@Override
	public List<Task> taskSequence(Stage stage) {
		List<Task> list = stage.taskList;
		// 从后向前迭代计算每个Task的rank
		calDownRank(list);
		list.sort(new Comparator<Task>() {
			@Override
			public int compare(Task task1, Task task2) {
				// TODO Auto-generated method stub
				// 计算两个任务的Rank
				// 异或：相同为0，相异为1
				if(task1.isSensitiveTask() ^ task2.isSensitiveTask()) {
					// 若二者隐私性不同
					if(task1.isSensitiveTask()) return -1;
					return 1;
				}else {
					// 若二者隐私性相同
					return (int) (task1.getDownRank() - task2.getDownRank());
				}
			}
		});
		return list;
	}

}
