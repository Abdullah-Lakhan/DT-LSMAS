package com.algorithm.taskPriority;

import java.util.List;

import com.application.Stage;
import com.application.Task;

public interface TaskPriority {
	List<Task> taskSequence(Stage stage);
}
