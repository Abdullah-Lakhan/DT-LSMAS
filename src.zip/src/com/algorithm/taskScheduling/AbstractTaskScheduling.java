package com.algorithm.taskScheduling;

import com.application.Task;

public abstract class AbstractTaskScheduling {
	
	/**
	 * 按理说应该有个返回值？没记录调度结果怎么行
	 * @param task
	 */
	public abstract void taskScheduling(Task task);
}
