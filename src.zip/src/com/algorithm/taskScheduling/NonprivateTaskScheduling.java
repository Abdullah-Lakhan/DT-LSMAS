package com.algorithm.taskScheduling;

import com.application.Task;

/**
 * 非隐私任务调度
 * 我并不知道这样分类是不是有问题。但重点也不是这个
 * @author ShirleyLee
 *
 */
public class NonprivateTaskScheduling extends AbstractTaskScheduling {

	@Override
	public void taskScheduling(Task task) {
		// TODO Auto-generated method stub
		
	}

}
