package com.algorithm.taskScheduling;

import com.application.Task;

/**
 * 隐私任务调度
 * @author ShirleyLee
 *
 */
public class PrivateTaskScheduling extends AbstractTaskScheduling {

	@Override
	public void taskScheduling(Task task) {
		// TODO Auto-generated method stub
		
		
	}
	
}
