package com.application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.workflowsim.utils.Parameters;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.CyberShake;
import com.simulation.app.Genome;
import com.simulation.app.Montage;
import com.simulation.app.SIPHT;
import com.utils.RandomNumberUtils;

/**
 * @author Job
 *
 */
public class Job {
	public SparkApplication app;
	public int jobid;
	public List<Job> childJobs;
	public List<Job> parentJobs;

	public int stageNum;
	public List<Stage> stageList; // job包含的stage集合，拓扑正序
	public List<Stage> reverseStageList; // 拓扑逆序
	public int indegree = 0; // 入度
	public int outDegree = 0; // 出度
	public int tmpindegree = 0; // 入度,调度算法执行过程中的实时状�??
	public int tmpoutDegree = 0; // 出度

	public double EST; // 最早开始时间
	public double EFT; // �?早结束时�?
	public double LST; // �?晚开始时�?
	public double LFT; // �?晚结束时�?

	private double subDeadline; // 自解释
	private int level; // Job所在的层，与划分截止期有关
	private double uprank;// Job的uprank值，与划分截止期有关
	private double processTime; // Job的执行时间=max{Stage的EFT}-min{Stage的EST}，计算rank使用
	private double priority; // Job的优先级，用于计算Stage优先级

	private double AST;// 实际开始时间 结束时间
	private double AFT;

	private boolean scheduled; // 是否完成调度
	private String dir;

	public boolean isScheduled() {
		return scheduled;
	}

	public void setScheduled(boolean scheduled) {
		this.scheduled = scheduled;
	}

	public double getAST() {
		return AST;
	}

	public void setAST(double aST) {
		AST = aST;
	}

	public double getAFT() {
		return AFT;
	}

	public void setAFT(double aFT) {
		AFT = aFT;
	}

	public double getProcessTime() {
		return processTime;
	}

	public void setProcessTime(double processTime) {
		this.processTime = processTime;
	}

	public double getUprank() {
		return uprank;
	}

	public void setUprank(double uprank) {
		this.uprank = uprank;
	}

	public double getPriority() {
		return priority;
	}

	public void setPriority(double priority) {
		this.priority = priority;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public double getSubDeadline() {
		return subDeadline;
	}

	public void setSubDeadline(double subDeadline) {
		this.subDeadline = subDeadline;
	}

	public Job() {
		childJobs = new ArrayList<>();
		parentJobs = new ArrayList<>();
		stageList = new ArrayList<>();
		reverseStageList = new ArrayList<>();
		this.EST = 0.00;
		this.EFT = 0.00;
		this.LST = Double.MAX_VALUE;
		this.LFT = Double.MAX_VALUE;
		this.AST = -1;
		this.AFT = -1;
		this.scheduled = false;
	}

	/**
	 * 构造方法
	 * 
	 * @param jobid
	 * @param instance Job所在Application的编号
	 * @throws Exception
	 */
	public Job(int jobid, int instance) throws Exception {

		this.jobid = jobid;

		childJobs = new ArrayList<>();
		parentJobs = new ArrayList<>();
		stageList = new ArrayList<>();
		reverseStageList = new ArrayList<>();

		// 随机生成Stage数量
		stageNum = RandomNumberUtils.getRandomNumber(Constant.STAGE_NUM_MIN, Constant.STAGE_NUM_MAX);

		this.EST = 0.00;
		this.EFT = 0.00;
		this.LST = Double.MAX_VALUE;
		this.LFT = Double.MAX_VALUE;

		this.AST = -1;
		this.AFT = -1;

		/* 构建关于 Stage �? DAG */
		// FileUtils.parseJobFiles(this, instance);
		// Job解析交给Utils类完成

		// topoSort();
	}

	/**
	 * Job构造方法（新）
	 * 
	 * @param jobId
	 * @param dir
	 * @throws Exception
	 * @throws FileNotFoundException
	 */
	public Job(int jobId, String dir, SparkApplication app) throws FileNotFoundException, Exception {
		this.app = app;
		this.dir = dir;
		this.jobid = jobId;
		childJobs = new ArrayList<Job>();
		parentJobs = new ArrayList<Job>();
		stageList = new ArrayList<Stage>();
		reverseStageList = new ArrayList<Stage>();

		this.EST = 0.00;
		this.EFT = 0.00;
		this.LST = Double.MAX_VALUE;
		this.LFT = Double.MAX_VALUE;

		int stageNumber = RandomNumberUtils.getRandomNumber(Constant.STAGE_NUM_MIN, Constant.STAGE_NUM_MAX);

		// 对于每个Job随机生成一个关于DAG的stage实例，xml;
		String filename = generateStageDAG(stageNumber);
		parseXmlFile(filename);
		topoSort();
	}

	/**
	 * 解析Stage的DAG文件
	 * 
	 * @param filename
	 * @throws FileNotFoundException
	 * @throws Exception
	 */
	public void parseXmlFile(String filename) throws FileNotFoundException, Exception {
		Map<String, Stage> mName2Stage = new HashMap<String, Stage>();
		SAXBuilder builder = new SAXBuilder();
		Document dom = builder.build(new File(filename));
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		int stageId = 0;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job": // 参照application解析方法，说明:这里“job”当成stage，不是application中Job
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Stage stage;
				// In case of multiple workflow submission. Make sure the
				// stageIdStartsFrom is consistent.
				synchronized (this) {
					// 生成stage对象
					stage = new Stage(stageId, this);
					stageId++;
				}

				mName2Stage.put(nodeName, stage);

				stageList.add(stage);

				/**
				 * Add dependencies info.
				 */
				break;
			case "child":
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Stage.containsKey(childName)) {

					Stage childStage = (Stage) mName2Stage.get(childName);

					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Stage.containsKey(parentName)) {
							Stage parentStage = (Stage) mName2Stage.get(parentName);
							parentStage.addEdge(childStage);
						}
					}
				}
				break;
			}
		}
//
//		// 设定一部分stage依赖不可移动数据
//		int dc_num = dcList.size();
//		HashSet<Stage> start_stages = getStartStage();
//		for (Stage stage : start_stages) {
//			if (getRandomNumber(0, 1) == 0) {
//				stage.dc = dcList.get(getRandomNumber(0, dc_num - 1));
//			}
//		}

		// 生成输入数据
		for (int i = 0; i < stageList.size(); i++) {
			stageList.get(i).generateInputData();
		}
		mName2Stage.clear();
	}

	/**
	 * 生成Stage间的DAG
	 * 
	 * @param stageNumber
	 * @return
	 * @throws Exception
	 * @throws FileNotFoundException
	 */
	private String generateStageDAG(int stageNumber) throws Exception, FileNotFoundException {
		String[] args = { "-a", "Montage", "-n", String.valueOf(stageNumber) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);
		Application app;
		// 生成何种类型的工作流
//		if (getRandomNumber(1, 2) == 1) {
//			app = new CyberShake();
//		} else {
//			app = new Montage();
//		}
		int type = this.app.type;
		if (type == 1) {
			app = new CyberShake();
		} else if (type == 2) {
			app = new Montage();
		} else if (type == 3) {
			app = new Genome();
		} else {
			app = new SIPHT();
		}

		// 生成工作流
		app.generateWorkflow(newArgs);

		// 保存到文件
		File file = new File(this.dir);
		if (!file.exists()) {
			file.mkdirs();
		}
		String fileName = dir + "/job_" + jobid + ".xml";
		file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		// 打印到文件
		app.printWorkflow(new FileOutputStream(file));
		return fileName;
	}

	public static int getRandomNumber(int min, int max) {
		Random random = new Random();
		return (random.nextInt(max - min + 1) + min);
	}

	/**
	 * 将Stage按偏序关系排序
	 */
	public void topoSort() {
		HashMap<Stage, Integer> visited = new HashMap<>();
		for (Stage stage : stageList) {
			visited.put(stage, 0);
		}

		for (Stage stage : stageList) {
			if (visited.get(stage) == 0) {
				topoSortVisit(stage, visited);
			}
		}

		stageList.clear();
		for (Stage stage : reverseStageList) {
			stageList.add(stage);
		}
		Collections.reverse(stageList);
	}

	public void topoSortVisit(Stage stage, HashMap<Stage, Integer> visited) {
		visited.put(stage, 1);
		for (Stage child : stage.childStages) {
			if (visited.get(child) == 0) {
				topoSortVisit(child, visited);
			}
		}
		visited.put(stage, 2);
		reverseStageList.add(stage);
	}

	public void addEdge(Job childJob) {
		// TODO Auto-generated method stub
		this.outDegree++;
		childJob.indegree++;
		this.tmpoutDegree++;
		childJob.tmpindegree++;
		this.childJobs.add(childJob);
		childJob.parentJobs.add(this);
	}

	public HashSet<Stage> getStartStage() {
		HashSet<Stage> startStages = new HashSet<Stage>();
		for (Stage stage : this.stageList) {
			if (stage.parentStages.size() == 0) {
				startStages.add(stage);
			}
		}
		return startStages;
	}

	public HashSet<Stage> getEndStage() {
		HashSet<Stage> endStages = new HashSet<Stage>();
		for (Stage stage : this.stageList) {
			if (stage.childStages.size() == 0) {
				endStages.add(stage);
			}
		}
		return endStages;
	}

	public void initTemporalParameters() {
		this.EST = 0.00;
		this.EFT = 0.00;
		this.LST = Double.MAX_VALUE;
		this.LFT = Double.MAX_VALUE;
	}

	public void reset() {
		initTemporalParameters();
		this.tmpindegree = this.indegree;
		this.tmpoutDegree = this.outDegree;
		for (Stage stage : stageList) {
			stage.reset();
		}
	}
//	public void estimateStageDur(int PRER){
//		for(Stage stage:stageList){
//			stage.estimateDur(PRER);
//		}
//	}

}
