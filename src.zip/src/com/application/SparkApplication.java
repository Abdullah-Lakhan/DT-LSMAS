package com.application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.workflowsim.utils.Parameters;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.CyberShake;
import com.simulation.app.Genome;
import com.simulation.app.Montage;
import com.simulation.app.SIPHT;

public class SparkApplication {
	public int instance; // 标记application的序号，便于之后跑多个实验时生成多个文件，文件标号使用
	public int jobNum;
	public List<Job> jobList;
	public List<Job> reverseJobList; //
	public List<Job> startJobs; // 就绪Job列表
	public static double makespan; // 存放应用调度（计算）所用时长makespan
	private double deadline; // 截止期
	private double EFT; // 最早完成时间
	private double slackTime; // 松弛时间=截止期-最后一个节点的最早结束时间
	private double AFT; // 实际完成时间
	public String dir; // 实例所在路径
	public int type; // SparkApplication的类型（是何种科学工作流）

	public double getAFT() {
		return AFT;
	}

	public void setAFT(double aFT) {
		AFT = aFT;
	}

	public double getSlackTime() {
		return slackTime;
	}

	public void setSlackTime(double slackTime) {
		this.slackTime = slackTime;
	}

	public double getEFT() {
		return EFT;
	}

	public void setEFT(double eFT) {
		EFT = eFT;
	}

	public double getDeadline() {
		return deadline;
	}

	public void setDeadline(double deadline) {
		this.deadline = deadline;
	}

	public SparkApplication() /* throws Exception */ {
		// 随机生成Job个数
		// 只有Job层面的工作流
		// jobNum = RandomNumberUtils.getRandomNumber(Constant.JOB_NUM_MIN,
		// Constant.JOB_NUM_MAX);
		jobList = new ArrayList<>();
		reverseJobList = new ArrayList<>();
		makespan = 0;

		// 解析xml文件生成工作
		// FileUtils.parseAppFile(this);
		// 进行拓扑排序
		// topoSort();
	}

	/**
	 * 生成SparkApplication
	 * 
	 * @param jobNumber
	 * @param instance
	 * @param type
	 * @throws Exception 
	 * @throws FileNotFoundException 
	 */
	public SparkApplication(int jobNumber, int instance, int type) throws FileNotFoundException, Exception {
		// TODO Auto-generated constructor stub
		this.instance = instance;
		jobList = new ArrayList<Job>();
		reverseJobList = new ArrayList<Job>();

		// 生成工作流
		String filename = generatWorkflow(jobNumber, type);
		parseXmlFile(filename);
		topoSort();
	}

	private String generatWorkflow(int jobNumber, int type) throws Exception, FileNotFoundException {
		String[] args = { "-a", "Montage", "-n", String.valueOf(jobNumber) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);
		Application app;
		String pathName;

		this.type = type;
		// 确定工作流类型
		// CyberShake，Genome，LIGO和Montage
		if (type == 1) {
			app = new CyberShake();
			pathName = Constant.SPARK_APP_DIR_CYBERSHAKE;
		} else if (type == 2) {
			app = new Montage();
			pathName = Constant.SPARK_APP_DIR_MONTAGE;
		} else if (type == 3) {
			app = new Genome();
			pathName = Constant.SPARK_APP_DIR_GENOME;
		} else {
			app = new SIPHT();
			pathName = Constant.SPARK_APP_DIR_SIPHT;
		}
		
		// 生成工作流
		app.generateWorkflow(newArgs);

		// 保存到文件
		// 生成分类目录
		File file = new File(pathName + "/jobNumber_" + jobNum);
		// 记录app所在路径
		this.dir = pathName + "/jobNumber_" + jobNum;
		if (!file.exists()) {
			file.mkdirs();
		}
		// 生成 app_* 目录
		File appDir = new File(pathName + "/jobNumber_" + jobNum + "/app_" + instance);
		if (!appDir.exists()) {
			appDir.mkdirs();
		}
		// 文件名
		String fileName = file + "/app_" + instance + ".xml";
		file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		
		// 打印到文件
		app.printWorkflow(new FileOutputStream(file));
		return fileName;
	}

	/**
	 * 解析xml文件，并生成Stage层面的DAG关系
	 * 
	 * @param filename
	 * @throws FileNotFoundException
	 * @throws Exception
	 */
	public void parseXmlFile(String filename) throws FileNotFoundException, Exception {
		Map<String, Job> mName2Job = new HashMap<String, Job>();
		SAXBuilder builder = new SAXBuilder();
		// 解析xml文件
		Document dom = builder.build(new File(filename));
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		int jobId = 0;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job":
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Job job;
				synchronized (this) {
					// 每个Job是关于DAG偏序关系Stage组成
					// 创建单个Job
					job = new Job(jobId, this.dir + "/app_" + this.instance, this);
					jobId++;
				}
				mName2Job.put(nodeName, job);
				jobList.add(job);
				break;
			case "child":
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Job.containsKey(childName)) {
					Job childJob = (Job) mName2Job.get(childName);
					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Job.containsKey(parentName)) {
							Job parentJob = (Job) mName2Job.get(parentName);
							parentJob.addEdge(childJob);
						}
					}
				}
				break;
			}
		}
		mName2Job.clear();
	}

	/**
	 * 将Job按偏序关系排序
	 */
	public void topoSort() {
		HashMap<Job, Integer> visited = new HashMap<>();
		for (Job job : jobList) {
			visited.put(job, 0);
		}
		for (Job job : jobList) {
			if (visited.get(job) == 0) {
				topoSortVisit(job, visited);
			}
		}

		jobList.clear();
		for (Job job : reverseJobList) {
			jobList.add(job);
		}
		Collections.reverse(jobList);
	}

	private void topoSortVisit(Job job, HashMap<Job, Integer> visited) {
		visited.put(job, 1);
		for (Job child : job.childJobs) {
			if (visited.get(child) == 0) {
				topoSortVisit(child, visited);
			}
		}
		visited.put(job, 2);
		reverseJobList.add(job);
	}

	public HashSet<Job> getStartJob() {
		HashSet<Job> startJobs = new HashSet<>();
		for (Job job : jobList) {
			if (job.parentJobs.size() == 0) {
				startJobs.add(job);
			}
		}
		return startJobs;
	}

	public HashSet<Job> getEndJob() {
		HashSet<Job> endJobs = new HashSet<>();
		for (Job job : jobList) {
			if (job.childJobs.size() == 0) {
				endJobs.add(job);
			}
		}
		return endJobs;
	}

	public void reset() {
		for (Job job : jobList) {
			job.reset();
		}
	}

}
