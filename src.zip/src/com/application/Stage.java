package com.application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.constant.Constant;
import com.utils.RandomNumberUtils;

public class Stage {
	public int stageid;
	public Job job;

	public List<Stage> childStages;
	public List<Stage> parentStages;
	public int taskNum;
	public List<Task> taskList;
	public int indegree = 0; // 入度
	public int outDegree = 0; // 出度
	public int tmpindegree = 0; // 入度
	public int tmpoutDegree = 0; // 出度
	public double EST; // 最早开始时间
	public double EFT; // 最早结束时间
	public double LST; // �?晚开始时�?
	public double LFT; // �?晚结束时�?
	public double startTime; // 实际开始时间
	public double endTime;
	public double estimateDuration;

	private double AST;// 实际开始时间
	private double AFT;// 实际结束时间

	public boolean scheduled; // 表示该Stage是否完成调度

	private double subDeadline; // 子截止期
	private int level; // Stage所在层
	private double uprank;

	public double getAST() {
		return AST;
	}

	public void setAST(double aST) {
		AST = aST;
	}

	public double getAFT() {
		return AFT;
	}

	public void setAFT(double aFT) {
		AFT = aFT;
	}

	public double getUprank() {
		return uprank;
	}

	public void setUprank(double uprank) {
		this.uprank = uprank;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public double getSubDeadline() {
		return subDeadline;
	}

	public void setSubDeadline(double subDeadline) {
		this.subDeadline = subDeadline;
	}

	/**
	 * 比较器：按照任务输入数据量，将Stage中Task递减排序
	 */
	/*static Comparator<Task> comp = new Comparator<Task>() {
		@Override
		public int compare(Task o1, Task o2) {
			return (int) (o2.totalInputData - o1.totalInputData);
		}
	};
	*/

	public Stage(Job job) {
		this.job = job;
		this.childStages = new ArrayList<>();
		this.parentStages = new ArrayList<>();
		this.taskList = new ArrayList<>();
		initTemporalParameters();
	}

	public Stage(int stageid, Job job) {
		this.stageid = stageid;
		this.job = job;

		this.childStages = new ArrayList<>();
		this.parentStages = new ArrayList<>();
		this.taskList = new ArrayList<>();
		// 随机生成Task数量
		// this.taskNum = RandomNumberUtils.getRandomNumber(Constant.TASK_NUM_MIN,
		// Constant.TASK_NUM_MAX);

		// 初始化参数
		initTemporalParameters();
		this.tmpindegree = indegree;
		this.tmpoutDegree = outDegree;

		this.taskNum = RandomNumberUtils.getRandomNumber(Constant.TASK_NUM_MIN, Constant.TASK_NUM_MAX);
		for (int i = 0; i < taskNum; i++) {
			Task task = new Task(i, this);
			this.taskList.add(task);
		}
		/* for (int i = 0; i < taskNum; i++) {
			Task task = new Task(i, this);
			this.taskList.add(task);
		} */

		// 初始化输入数据
//		 generateInputData();
	}

	public void generateInputData() {
		for (int i = 0; i < taskNum; i++) {
			taskList.get(i).generateInputData();
		}
		// 先不对任务排序
		// Collections.sort(taskList, comp);
	}

	/**
	 * 添加Stage间依赖边操作 向childStage添加父Stage，向fatherStage添加childStage
	 * 
	 * @param childStage
	 */
	public void addEdge(Stage childStage) {
		this.outDegree++;
		childStage.indegree++;
		this.tmpoutDegree++;
		childStage.tmpindegree++;
		this.childStages.add(childStage);
		childStage.parentStages.add(this);
	}

	public void initTemporalParameters() {
		this.EST = 0.00;
		this.EFT = 0.00;
		this.LST = Double.MAX_VALUE;
		this.LFT = Double.MAX_VALUE;
		// this.LST = Format.formatDouble(Constant.NUM_QUANTILES,Double.MAX_VALUE);
		// this.LFT = Format.formatDouble(Constant.NUM_QUANTILES,Double.MAX_VALUE);

		startTime = 0;
		endTime = 0;
		scheduled = false;

		this.AST = -1;
		this.AFT = -1;
	}

	public void reset() {
		initTemporalParameters();
		this.tmpindegree = indegree;
		this.tmpoutDegree = outDegree;
		for (Task task : taskList) {
			task.reset();
		}
	}

	/**
	 * 该Stage中所有任务的处理数据量的大小
	 *
	 * @return
	 */
	public double sizeOfAllTaskInputData() {
		double sum = 0;
		for (Task t : taskList) {
			sum += t.totalInputData;
		}
		return sum;
	}

	@Override
	public String toString() {
		return "Stage{" + "stageid=" + stageid + ", taskNum=" + taskNum + '}';
	}

//	public void estimateDur(int PRER){
//		estimateDuration = 0;
//		for(Task task : taskList){
//			double taskEstimatedDur = task.estimatedDur(PRER);
//			estimateDuration = Math.max(estimateDuration, taskEstimatedDur);
//		}
//	}
}
