package com.application;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.junit.Test;

import com.constant.Constant;
import com.constant.NodeType;
import com.resource.MyVM;
import com.resource.VM;
import com.utils.CalculateUtils;
import com.utils.RandomNumberUtils;

public class Task {
	public int taskid;
	public double totalInputData; // task的总输入数据量，以MB为单位
	public Stage stage; // Task所在Stage
	private boolean sensitiveTask; // 是否是敏感任务

	// public Map<Task, Integer> previousInputData; // 前驱的输入数据量
	// private List<Task> precursorTask; // 该Task的前驱任务集合
	private Map<Task, Integer> precursorTask;
	private double remainData; // 来自于私有云的输入数据，也是需要进行传输的一部分
	
	// 后继任务
	public Map<Task, Integer> successorTask;// 后继任务，即当前任务的数据要输出给该集合中的任务

	// public Map<Task, Integer> blockNumberOnEachTask; //前驱的输入数据量，用previousInputData代替

	public double instructions;/* 该任务处理的指令数 */

	// 任务执行开始时间，结束时间
	public double AST;
	public double AFT;

	private MyVM vm; // 任务被分配到的虚拟机

	private double estimateProcessTime; // Task的估计执行时间
	private double estimateTotalTime; // Task的估计处理时间= 执行时间 + 传输时间
	
	private double upRank;
	private double downRank;
	
	public double getAST() {
		return AST;
	}

	public void setAST(double aST) {
		AST = aST;
	}

	public double getAFT() {
		return AFT;
	}

	public void setAFT(double aFT) {
		AFT = aFT;
	}

	public double getUpRank() {
		return upRank;
	}

	public void setUpRank(double upRank) {
		this.upRank = upRank;
	}

	public double getDownRank() {
		return downRank;
	}

	public void setDownRank(double downRank) {
		this.downRank = downRank;
	}

	public double getEstimateTotalTime() {
		return estimateTotalTime;
	}

	public void setEstimateTotalTime(double estimateTotalTime) {
		this.estimateTotalTime = estimateTotalTime;
	}

	public double getEstimateProcessTime() {
		return estimateProcessTime;
	}

	public void setEstimateProcessTime(double estimateProcessTime) {
		this.estimateProcessTime = estimateProcessTime;
	}

	public double getRemainData() {
		return remainData;
	}

	public void setRemainData(double remainData) {
		this.remainData = remainData;
	}

	// getter, setter
	public Map<Task, Integer> getPrecursorTask() {
		return precursorTask;
	}

	public void setPrecursorTask(Map<Task, Integer> precursorTask) {
		this.precursorTask = precursorTask;
	}
	
	public MyVM getVm() {
		return vm;
	}

	public void setVm(MyVM vm) {
		this.vm = vm;
	}

	public boolean isSensitiveTask() {
		return sensitiveTask;
	}

	public void setSensitiveTask(boolean sensitiveTask) {
		this.sensitiveTask = sensitiveTask;
	}

	public Task(Stage stage, double instrcutions) {
		this.stage = stage;
		AST = 0;
		AFT = 0;
		this.instructions = instrcutions;
		// previousInputData = new HashMap<>();
		precursorTask = new HashMap<>();
		successorTask = new HashMap<>();
	}
	
	// 构造方法
	public Task(int taskid, Stage stage) {
		this.taskid = taskid;
		this.stage = stage;
		AST = 0;
		AFT = 0;
		// previousInputData = new HashMap<>();
		precursorTask = new HashMap<>();
		successorTask = new HashMap<>();
	}

	public Task(int taskId, double instrcutions, Stage stage) {
		this.taskid = taskId;
		this.stage = stage;
		this.instructions = instrcutions;
		AST = -1;
		AFT = -1;
		// previousInputData = new HashMap<>();
		successorTask = new HashMap<>();
		precursorTask = new HashMap<>();
		// generateInputData(); // 生成该task的总数据量
	}

	public void reset() {
		AST = 0;
		AFT = 0;
	}

	/**
	 * 生成任务数据：主要是偏序关系和传输数据量
	 */
	public void generateInputData() {
		// 1. 随机生成输入数据量
		int remain = RandomNumberUtils.getRandomNumber(Constant.TASK_INPUT_SIZE_MIN, Constant.TASK_INPUT_SIZE_MAX);
		totalInputData = remain;

		// 2. 建立任务间的偏序关系
		Stage stage = this.stage;
		List<Stage> parentStage = stage.parentStages;
		// 当所在Stage拥有父Stage时：
		if (parentStage != null && parentStage.size() != 0) {
			for (int i = 0; i < parentStage.size(); i++) {
				Stage parent = parentStage.get(i);
				List<Task> tasks = parent.taskList;
				for (int j = 0; j < tasks.size(); j++) {
					if (remain == 0) {
						break;
					}
					int dataSize = getDataSize(remain);
					// this.precursorTask.add(tasks.get(j));
					// this.previousInputData.put(tasks.get(j), dataSize); //弃用previousInputData变量
					this.precursorTask.put(tasks.get(j), dataSize);
					// 添加后继关系
					tasks.get(j).successorTask.put(this, dataSize);
					remain -= dataSize;
				}
			}
			if(remain > 0) {
				remainData = remain;
			}
		} else {
			// 如果当前Stage是所在Job的第一个Stage，则认为其输入数据全部来自私有云
			remainData = remain;
		}

		// 3. 随机确定任务隐私性
		// 自定规则是：如果前驱Task中没有隐私任务，则该任务一定不是隐私任务；
		// 如果前驱Task中有隐私任务，则该任务有50%概率是隐私任务，50%概率不是隐私任务
		// 若Task没有前驱Task，则50%是隐私任务，50%不是隐私任务
		// TODO
//		int num = RandomNumberUtils.getRandomNumber(0, 1);
//		if (num == 0) {
//			this.sensitiveTask = false;
//		} else {
//			this.sensitiveTask = true;
//		}
		double num = Math.random();
		if(CalculateUtils.compareDouble(num, 0.2) < 0) {
			this.sensitiveTask = true; // 百分之二十的几率是隐私任务
		}else {
			this.sensitiveTask = false;
		}
	}
	
	/**
	 * 随机生成一个数据量大小
	 * 
	 * @param remain
	 * @return
	 */
	private int getDataSize(int remain) {
		Random random = new Random();
		// 根据对remain=200的假设，这里的x为[0,4]范围内的整数，假设为2
		int x = random.nextInt((remain / 50) + 1);
		return x;
	}

	/**
	 * 估算任务的执行时�?
	 *
	 * @return
	 */
	public double estimatedDur() {
		double transmissionTime = totalInputData / NodeType.BANDWIDTH;
		double estimationProcessSpeed = 0;

		double sumSpeed = 0;
		double sumNum = 0;

		estimationProcessSpeed = sumSpeed / sumNum;

		double processTime = this.totalInputData / estimationProcessSpeed;
		double estimateDuration = processTime + transmissionTime;
		return estimateDuration;
	}

	/**
	 * 该任务在具体某个虚拟机上的执行时�?
	 *
	 * @param vm
	 * @return
	 */
	public double durationOnVM(VM vm) {
		double transmissionTime = totalInputData / NodeType.BANDWIDTH;
		double processTime = totalInputData / vm.getType().getProcess_rate();
		double runningTime = transmissionTime + processTime;
		return runningTime;
	}
	

}