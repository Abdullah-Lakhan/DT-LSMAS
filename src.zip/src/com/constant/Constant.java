package com.constant;

import com.resource.MyVMType;

/**
 * @Author Ivan 15:33 2019/12/4
 * @Description TODO
 */
public class Constant {

	// 指定输出的xml的目�?
	// public static final String xmlDir = "E:/实验数据_xw/";

	public static String SPARK_CYBERSHAKE = "cybershake";
	public static String SPARK_MONTAGE = "montage";
	public static String SPARK_GENOME = "genome";
	public static String SPARK_LIGO = "ligo";
	public static String SPARK_SIPHT = "sipht";
	
	/* Spark App 文件目录 */
	public static String SPARK_APP_DIR_CYBERSHAKE = "E:\\paper\\data\\Spark应用\\cybershake";

	/* Spark App 文件目录 */
	public static String SPARK_APP_DIR_MONTAGE = "E:\\paper\\data\\Spark应用\\montage";

	/* Genome 科学工作流*/
	public static String SPARK_APP_DIR_GENOME = "E:\\paper\\data\\Spark应用\\genome";

	/* Ligo 科学工作流*/
	public static String SPARK_APP_DIR_LIGO = "E:\\paper\\data\\Spark应用\\ligo";

	/* Sipht 科学工作流*/
	public static String SPARK_APP_DIR_SIPHT = "E:\\paper\\data\\Spark应用\\sipht";

	/* 保存执行结果的文件目录 */
	public static String PARAMS_CALIBRATION_DIR = "E:\\paper\\result\\参数测定";

	/* 保存算法比较的文件目录 */
	public static String ALGORITHM_COMPARATION_DIR = "E:\\paper\\result\\算法比较";

	// 云
	public final static int PRIVATE_CLOUD = 0;
	public final static int PUBLIC_CLOUD = 1;

	// VM类型
	public final static MyVMType highVM = new MyVMType(NodeType.PROCESS_RATE_3, NodeType.RENT_UNIT_HOUR,
			NodeType.PRICE_HIGH_LELVEL);
	public final static MyVMType middleVM = new MyVMType(NodeType.PROCESS_RATE_2, NodeType.RENT_UNIT_HOUR,
			NodeType.PRICE_MID_LEVLEL);
	public final static MyVMType lowVM = new MyVMType(NodeType.PROCESS_RATE_1, NodeType.RENT_UNIT_HOUR,
			NodeType.PRICE_LOW_LEVLEL);

	// 私有云中VM个数
//	public static final int PRIVATE_VM_MIN = 100;
//	public static final int PRIVATE_VM_MAX = 100;

	// 算法分类
	public static final String Algorithm1 = "RBSAS";

//	public static final String Algorithm2 = "HEFT";
//
//	public static final String Algorithm3 = "FAIR";

	public static final String Algorithm2 = "IHEFT";

	public static final String Algorithm3 = "HCOC";

	// Job 的数量范�?
	public static final int JOB_NUM_MAX = 20;

	public static final int JOB_NUM_MIN = 15;

	/* 代表不同类型的科学工作流*/
	public static final int[] TYPE_NUM = { 0, 1 };

	/* 该 SparkApp 可能的 job 数量 */
//	public static final int[] NUM_OF_JOBS = { 15, 24, 32, 44 }; // Genome
//	public static final int[] NUM_OF_JOBS = { 30, 35, 40, 45 };
//	public static final int[] NUM_OF_JOBS = { 15, 25, 35, 45 };
//	public static final int[] NUM_OF_JOBS = { 30, 40, 50, 60 };
//	public static final int[] NUM_OF_JOBS = { 30, 40, 45, 46 }; // SIPHT
	public static final int[] NUM_OF_JOBS = { 30, 40, 50, 60 }; // Ligo

	/* 截止期设置 */
	public static final double[] TIME_OF_DEADLINE = { 1.2, 1.4, 1.6, 1.8, 2.0 };
//	 public static final double[] TIME_OF_DEADLINE = { 1.2};

	/* 虚拟机个数 */
//	public static final double[] PRIVATE_VM_NUM = { 30, 60, 90, 120 };
	public static final double[] PRIVATE_VM_NUM = { 20, 40, 60, 80 };
//	public static final double[] PRIVATE_VM_NUM = { 20 };

	/* 虚拟机个数因子 */
	public static final double[] PRIVATE_VM_FACTOR = { 0.1, 0.2, 0.3, 0.4 };

	/* 每组参数组合生成实例个数 */
	public static final int INSTANCE_NUM = 1;
//	public static final int INSTANCE_NUM = 10;

	// Stage 的数量范围
//	public static final int STAGE_NUM_MAX = 30;
//	public static final int STAGE_NUM_MIN = 30;

	public static final int STAGE_NUM_MAX = 22;
	public static final int STAGE_NUM_MIN = 22;

	// Task 的数量范围
	public static final int TASK_NUM_MAX = 10;

	public static final int TASK_NUM_MIN = 5;

	// Task 指令数
	public static final int TASK_DATA_SIZE_MAX = 10000; // 指令数

	public static final int TASK_DATA_SIZE_MIN = 5000;

	// Task 输入数据量范围
	public static final int TASK_INPUT_SIZE_MAX = 1000; // 单位是Mbit

	public static final int TASK_INPUT_SIZE_MIN = 500;

	// 带宽
	public static final int BANDWIDTH_INTRA = 80; // 单位是：80 Mbps/s，即每秒传输的兆位数
	public static final int BANDWIDTH_INTER = 50;

}
