package com.constant;

/**
 * @Author Ivan 9:42
 * @Description TODO
 */
public class NodeType {
	// 单位租赁价格
	public static final int PRICE_HIGH_LELVEL = 30; // 单位：30元 / h
	public static final int PRICE_MID_LEVLEL = 20;
	public static final int PRICE_LOW_LEVLEL = 10;

	// 单位租赁时间
	public static final String RENT_UNIT_HOUR = "HOUR";
	// public static final String RENT_UNIT_MINUTE = "MINUTE";
	
	// 处理速率
	public static final int PROCESS_RATE_1 = 100; // 单位： 100指令数/秒
	public static final int PROCESS_RATE_2 = 200;
	public static final int PROCESS_RATE_3 = 300;
	
	public static final int SEED_HIGH_LELVEL = 150;
	public static final int SEED_MID_LEVLEL = 100;
	public static final int SEED_LOW_LEVLEL = 50;

	// 带宽
	public static final double BANDWIDTH = 10d;

}
