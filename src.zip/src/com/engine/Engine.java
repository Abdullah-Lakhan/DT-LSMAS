package com.engine;

import java.util.List;

import com.algorithm.Scheduler;
import com.algorithm.fifo.FIFOScheduler;
import com.application.SparkApplication;
import com.constant.Constant;
import com.resource.ResourcePool;
import com.resource.VmType;

/**
 * @Author Ivan 15:47 2019/12/4
 * @Description TODO 处理引擎
 */
public class Engine {

	private Scheduler scheduler;

	private List<VmType> types;

	private SparkApplication application;

	private ResourcePool resourcePool;

	public Engine(List<VmType> types, SparkApplication application, ResourcePool resourcePool) {
		this.types = types;
		this.application = application;
		this.resourcePool = resourcePool;
	}

	/**
	 * 根据相应的算法获取对应的调度器
	 *
	 * @param name 算法名称
	 * @return
	 */
	public Scheduler getSchedulerByType(String name) {
		switch (name) {
		case Constant.Algorithm1: {
			this.scheduler = new FIFOScheduler(application, types, resourcePool);
		}
		case Constant.Algorithm2: {

		}
		case Constant.Algorithm3: {

		}
		}
		return this.scheduler;
	}

	public void process() {
		scheduler.runSchedule();
	}

}
