package com.engine;

import java.util.Map;

import com.algorithm.MyScheduler;
import com.algorithm.Scheduler;
import com.application.SparkApplication;
import com.resource.MyResourcePool;

/**
 * 处理引擎
 * @author ShirleyLee
 *
 */
public class MyEngine {
	private MyResourcePool resourcePool;
	private SparkApplication application;
	private MyScheduler scheduler;
	
	// 构造方法
	public MyEngine() {}
	public MyEngine(MyResourcePool resourcePool, SparkApplication application, MyScheduler scheduler) {
		super();
		this.resourcePool = resourcePool;
		this.application = application;
		this.scheduler = scheduler;
	}
	
	// getter, setter
	public MyResourcePool getResourcePool() {
		return resourcePool;
	}
	public void setResourcePool(MyResourcePool resourcePool) {
		this.resourcePool = resourcePool;
	}
	public SparkApplication getApplication() {
		return application;
	}
	public void setApplication(SparkApplication application) {
		this.application = application;
	}
	public MyScheduler getScheduler() {
		return scheduler;
	}
	public void setScheduler(MyScheduler scheduler) {
		this.scheduler = scheduler;
	}
	
	/**
	 * 启动本次调度
	 */
	public void process() {
		this.scheduler.runSchedule(application, resourcePool);
	}
	
	public void process(Map<String, Integer> map) {
		// TODO Auto-generated method stub
		this.scheduler.runSchedule(application, resourcePool, map);
		
	}
	
}
