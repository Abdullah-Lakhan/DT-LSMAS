package com.generator.sparkapp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import com.constant.Constant;
import com.simulation.app.Application;
import com.utils.RandomNumberUtils;

/**
 * <h1>生成 Spark Application 文件</h1> 因为只有一个数据中心，这样调度的话，始终保证在同一个数据中心中进行
 *
 * Created by DHA on 2019/12/11.
 */
public abstract class AbstractGenerateSparkApp {
	/**
	 * 生成 Spark Application 文件
	 * 
	 * @param pathName 文件路径
	 * @throws Exception
	 */
	public void generateSparkApp(String pathName) throws Exception {
		for (int appId = 0; appId < Constant.NUM_OF_JOBS.length; appId++) { // 生成四个app
			int numOfJob = Constant.NUM_OF_JOBS[appId]; // Job数量

			// 生成 app_* 目录
			File appDir = new File(pathName + "/app_" + appId);
			if (!appDir.exists()) {
				appDir.mkdirs();
			}
			// 生成 app_*.xml 文件
			generateAppFile(numOfJob, appId, pathName);

			// 最后一个Job不生成DAG图
			for (int jobId = 0; jobId < numOfJob; jobId++) {
				// 生成 job_* 目录
				File jobDir = new File(appDir, "/job_" + jobId);
				if (!jobDir.exists()) {
					jobDir.mkdirs();
				}
				// 生成 job_*.xml 文件
//				int numOfStage = RandomNumberUtils.getRandomNumber(10, 15);
				int numOfStage = RandomNumberUtils.getRandomNumber(Constant.STAGE_NUM_MIN, Constant.STAGE_NUM_MAX);
				generateJobFiles(appDir.getAbsolutePath(), jobId, numOfStage);

				// 生成 stage 文件，最后一个Stage不生成Stage.txt
				for (int i = 0; i < numOfStage; i++) {
					generateStageFiles(jobDir, i);
				}
			}
		}
		System.out.println("生成 Spark 应用程序成功！");
	}

	/**
	 * <h2>生成 Job 之间的 DAG</h2>
	 * 
	 * @param numOfJob
	 * @param appId
	 * @return
	 * @throws Exception
	 */
	protected void generateAppFile(int numOfJob, int appId, String pathName) throws Exception {
		Application app = generateWorkflow(numOfJob);
		String fileName = pathName + "/app_" + appId + ".xml";
		File file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		app.printWorkflow(new FileOutputStream(file));
	}

	/**
	 * 生成Stage文件
	 * 
	 * @param jobDir
	 * @param i
	 * @throws IOException
	 */
	private void generateStageFiles(File jobDir, int i) throws IOException {
		File file = new File(jobDir, "stage_" + i + ".txt");
		if (!file.exists()) {
			file.createNewFile();
		}
		// 任务数量
		// int numOfTasks = RandomNumberUtils.getRandomNumber(20, 30);
		int numOfTasks = RandomNumberUtils.getRandomNumber(Constant.TASK_NUM_MIN, Constant.TASK_NUM_MAX);
		// 写入数据
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write(numOfTasks + "");
		bw.newLine();
		bw.flush();
		for (int taskId = 0; taskId < numOfTasks; taskId++) {
			// 随机生成Task的指令数
			// double instrcutions = RandomNumberUtils.getRandomNumber(5000, 10000);
			double instrcutions = RandomNumberUtils.getRandomNumber(Constant.TASK_DATA_SIZE_MIN,
					Constant.TASK_DATA_SIZE_MAX);
			bw.write(taskId + "," + instrcutions);
			bw.newLine();
			bw.flush();
		}
	}

	/**
	 * <h2>生成 Stage 之间的 DAG</h2>
	 * 
	 * @param appDir
	 * @param jobId
	 * @param numOfStage
	 * @return
	 * @throws Exception
	 */
	protected void generateJobFiles(String appDir, int jobId, int numOfStage) throws Exception {
		String fileName = appDir + "/job_" + jobId + ".xml";
		File file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		Application app = generateWorkflow(numOfStage);
		app.printWorkflow(new FileOutputStream(file));
	}

	/**
	 * <h2>生成传统工作流</h2> 我们这里是通过传统工作流来创建 Stage 偏序关系和 Job 偏序关系
	 * 
	 * @param number 需要生成的任务数量
	 * @return {@link Application}
	 */
	protected abstract Application generateWorkflow(int number) throws Exception;
	/*
	 * { String[] args = { "-a", "Montage", "-n", String.valueOf(number) }; String[]
	 * newArgs = Arrays.copyOfRange(args, 2, args.length);
	 * 
	 *//* 工作流实例采用 WorkflowSim 随机生成，共包含两种类型的工作流：Montage 和 CyberShake *//*
																		 * Application app; if
																		 * (RandomNumberUtils.getRandomNumber(1, 2) ==
																		 * 1) { app = new CyberShake(); } else { app =
																		 * new Montage(); }
																		 * app.generateWorkflow(newArgs); return app; }
																		 */

	/**
	 * 在路径pathName下，生成具有jobNum个Job的工作流
	 * 
	 * @param pathName 生成spark文件的路径
	 * @param jobNum   Job数量
	 * @param instance 实例计数，在jobNum个Job数量下的第几个实例
	 * @return 返回这个文件名字
	 * @throws Exception
	 */
	public String generateSparkApp(String pathName, int jobNum, int instance) throws Exception {
		// TODO Auto-generated method stub

		// 生成分类目录
		File file = new File(pathName + "/jobNumber_" + jobNum);
		if (!file.exists()) {
			file.mkdirs();
		}
		// 生成 app_* 目录
		File appDir = new File(pathName + "/jobNumber_" + jobNum + "/app_" + instance);
		if (!appDir.exists()) {
			appDir.mkdirs();
		}
		// 文件名
		String fileName = file + "/app_" + instance + ".xml";
		file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}

		// 生成app文件
		Application app;
		app = generateWorkflow(jobNum);
		app.printWorkflow(new FileOutputStream(file));

		// 生成Job文件
		for (int jobId = 0; jobId < jobNum; jobId++) {
//		for (int jobId = 0; jobId < jobNum - 1; jobId++) { // Sipht专用
			// 生成 job_* 目录
			File jobDir = new File(appDir, "/job_" + jobId);
			if (!jobDir.exists()) {
				jobDir.mkdirs();
			}
			// 生成 job_*.xml 文件
			// int numOfStage = RandomNumberUtils.getRandomNumber(10, 15);
			int numOfStage = RandomNumberUtils.getRandomNumber(Constant.STAGE_NUM_MIN, Constant.STAGE_NUM_MAX);
//			int numOfStage = 26;
			generateJobFiles(appDir.getAbsolutePath(), jobId, numOfStage);
			// for test DHA 5/24/2020
//			generateJobFiles(appDir.getAbsolutePath(), jobId, numOfStage-1);

			// 生成 stage 文件
			for (int i = 0; i < numOfStage; i++) {
//			for (int i = 0; i < numOfStage - 1; i++) { //sipht专用
				generateStageFiles(jobDir, i);
			}
		}
		System.out.println("生成 Spark 应用程序成功！");
		return fileName;
	}
}
