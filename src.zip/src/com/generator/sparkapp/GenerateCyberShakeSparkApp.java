package com.generator.sparkapp;

import java.util.Arrays;

import org.junit.Test;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.CyberShake;

/**
 * <h1>生成 Spark Application 文件</h1> 因为只有一个数据中心，这样调度的话，始终保证在同一个数据中心中进行
 *
 * Created by DHA on 2019/12/11.
 */
public class GenerateCyberShakeSparkApp extends AbstractGenerateSparkApp {

	/**
	 * <h2>生成传统 Montage 工作流</h2> 我们这里是通过传统工作流来创建 Stage 偏序关系和 Job 偏序关系
	 * 
	 * @param number 需要生成的任务数量
	 * @return {@link Application}
	 */
	@Override
	public Application generateWorkflow(int number) throws Exception {
		String[] args = { "-a", "CyberShake", "-n", String.valueOf(number) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);

		/* 工作流实例采用 WorkflowSim 随机生成，共包含两种类型的工作流：Montage 和 CyberShake */
		Application app = new CyberShake();
		app.generateWorkflow(newArgs);
		return app;
	}

	@Test
	public void test() throws Exception {
		GenerateCyberShakeSparkApp sparkApp = new GenerateCyberShakeSparkApp();
		sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_CYBERSHAKE);
	}
}
