package com.generator.sparkapp;

import java.io.FileOutputStream;
import java.util.Arrays;

import org.junit.Test;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.Genome;

public class GenerateGenomeSparkApp extends AbstractGenerateSparkApp {

	// 节点数量没有约束
	@Override
	protected Application generateWorkflow(int number) throws Exception {
		String[] args = { "-a", "Genome", "-n", String.valueOf(number) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);

		Application app = new Genome();
		app.generateWorkflow(newArgs);
		return app;
	}
	
	@Test
	public void test() throws Exception {
		GenerateGenomeSparkApp sparkApp = new GenerateGenomeSparkApp();
//		sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_GENOME);
		String outfile = "Epigenomics_18.xml";
		Application app = sparkApp.generateWorkflow(18);
        app.printWorkflow(new FileOutputStream(outfile));
		System.out.println();
	}
}
