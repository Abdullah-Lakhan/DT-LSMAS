package com.generator.sparkapp;

import java.util.Arrays;

import org.junit.Test;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.LIGO;

public class GenerateLigoSparkApp extends AbstractGenerateSparkApp {

	// 至少21个节点
	@Override
	protected Application generateWorkflow(int number) throws Exception {
		String[] args = { "-a", "Ligo", "-n", String.valueOf(number) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);

		Application app = new LIGO();
		app.generateWorkflow(newArgs);
		return app;
	}
	
	@Test
	public void test() throws Exception {
		GenerateLigoSparkApp sparkApp = new GenerateLigoSparkApp();
		sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_LIGO);
	}
}
