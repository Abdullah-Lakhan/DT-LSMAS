package com.generator.sparkapp;

import java.util.Arrays;

import org.junit.Test;

import com.constant.Constant;
import com.simulation.app.Application;
import com.simulation.app.SIPHT;

public class GenerateSiphtSparkApp extends AbstractGenerateSparkApp {

	// 至少30个节点
	@Override
	protected Application generateWorkflow(int number) throws Exception {
		String[] args = { "-a", "Sipht", "-n", String.valueOf(number) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);

		Application app = new SIPHT();
		app.generateWorkflow(newArgs);
		return app;
	}
	
	@Test
	public void test() throws Exception {
		GenerateSiphtSparkApp sparkApp = new GenerateSiphtSparkApp();
		sparkApp.generateSparkApp(Constant.SPARK_APP_DIR_SIPHT);
	}
}
