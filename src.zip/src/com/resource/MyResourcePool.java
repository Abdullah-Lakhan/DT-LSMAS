package com.resource;

import java.util.List;

/**
 * 资源池=私有云中资源+公有云中资源类型？
 * @author ShirleyLee
 *
 */
public class MyResourcePool {
	// 资源属性
	// 私有云资源固定，用列表表示
	List<MyVM> privateCloud; // 私有云资源列表 这里没有区分资源类型，一切由MyVM对象中属性确定
	// 公有云资源随机，用资源类型表示公有云中资源类型
	List<MyVMType> publicVMType; // 公有云资源类型
	
	// 租赁属性
	List<MyVM> rentVm; // 租赁的公有云资源
	
	// 构造方法
	public MyResourcePool() {}
	
	public MyResourcePool(List<MyVM> privateCloud, List<MyVMType> publicVMType, List<MyVM> rentVm) {
		super();
		this.privateCloud = privateCloud;
		this.publicVMType = publicVMType;
		this.rentVm = rentVm;
	}

	// getter,setter
	public List<MyVM> getPrivateCloud() {
		return privateCloud;
	}
	public void setPrivateCloud(List<MyVM> privateCloud) {
		this.privateCloud = privateCloud;
	}

	public List<MyVMType> getPublicVMType() {
		return publicVMType;
	}
	public void setPublicVMType(List<MyVMType> publicVMType) {
		this.publicVMType = publicVMType;
	}

	public List<MyVM> getRentVm() {
		return rentVm;
	}
	public void setRentVm(List<MyVM> rentVm) {
		this.rentVm = rentVm;
	}

	/**
	 * 清空资源池中的已租赁虚拟机
	 */
	public void reset() {
		// TODO Auto-generated method stub
		this.rentVm.clear();
	}
	
	
}
