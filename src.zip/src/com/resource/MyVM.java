package com.resource;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.application.Task;
import com.constant.Constant;

/**
 * 虚拟机
 * @author ShirleyLee
 *
 */
public class MyVM {
	
	// 基本属性
	private int belongCloud; // 所属的云，取值为表示云的常量
	private int vmId; // id
	private double processSpeed; // 处理速度，以秒为单位
	private String rentUnitTime; // 租赁单位时间，小时
	private double rentUnitPrice; // 租赁单位成本，以小时为单位
	
	// 时间属性
	private double startTime; // 租赁开始时间
	private double endTime; // 租赁结束时间，用于调度结束时，计算该虚拟机的租赁成本
	private double availTime; // 可用时间 ，用于调度过程中，进行任务与VM的映射
	// private double rentEndTime; // 租赁结束时间，以秒为单位，
	
	// 成本属性
	private double totalPrice; // 总租赁成本 以防后面有用
	
	// 映射关系
	private Map<Task, Period> map; // 与Task的匹配关系
	
	private List<Task> tasks;// 使用该虚拟机的任务列表
	
	private boolean used; // 标记该虚拟机是否在使用中

	// 构造方法
	public MyVM() {
		this.totalPrice = 0;
		this.availTime = 0;
		this.map = new HashMap<Task, Period>();
		this.tasks = new LinkedList<Task>();
	}
	public MyVM(int belongCloud, int vmId, double processSpeed, String rentUnitTime, double rentUnitPrice,
			double startTime, double endTime, double availTime, double totalPrice, Map<Task, Period> map) {
		super();
		this.belongCloud = belongCloud;
		this.vmId = vmId;
		this.processSpeed = processSpeed;
		this.rentUnitTime = rentUnitTime;
		this.rentUnitPrice = rentUnitPrice;
		this.startTime = startTime;
		this.endTime = endTime;
		this.availTime = availTime;
		this.totalPrice = totalPrice;
		this.map = map;
		this.tasks = new LinkedList<Task>();
	}

	/**
	 * 通过虚拟机类型初始化虚拟机
	 * @param selectType
	 */
	public MyVM(MyVMType type) {
		this.processSpeed = type.getProcessSpeed();
		this.rentUnitPrice = type.getRentUnitPrice();
		this.rentUnitTime = type.getRentUnitTime();
		this.belongCloud = Constant.PUBLIC_CLOUD;
		this.startTime = 0;
		this.endTime = 0;
		this.availTime = 0;
		this.tasks = new LinkedList<Task>();
	}
	// getter, setter
	public boolean isUsed() {
		return used;
	}
	public void setUsed(boolean used) {
		this.used = used;
	}
	
/*
	public double getRentEndTime() {
		return rentEndTime;
	}
	public void setRentEndTime(double rentEndTime) {
		this.rentEndTime = rentEndTime;
	}
	*/
	public List<Task> getTasks() {
		return tasks;
	}
	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}
	public int getBelongCloud() {
		return belongCloud;
	}
	public void setBelongCloud(int belongCloud) {
		this.belongCloud = belongCloud;
	}
	public int getVmId() {
		return vmId;
	}
	public void setVmId(int vmId) {
		this.vmId = vmId;
	}
	public double getProcessSpeed() {
		return processSpeed;
	}
	public void setProcessSpeed(double processSpeed) {
		this.processSpeed = processSpeed;
	}
	public String getRentUnitTime() {
		return rentUnitTime;
	}
	public void setRentUnitTime(String rentUnitTime) {
		this.rentUnitTime = rentUnitTime;
	}
	public double getRentUnitPrice() {
		return rentUnitPrice;
	}
	public void setRentUnitPrice(double rentUnitPrice) {
		this.rentUnitPrice = rentUnitPrice;
	}
	public double getStartTime() {
		return startTime;
	}
	public void setStartTime(double startTime) {
		this.startTime = startTime;
	}
	public double getEndTime() {
		return endTime;
	}
	public void setEndTime(double endTime) {
		this.endTime = endTime;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Map<Task, Period> getMap() {
		return map;
	}
	public void setMap(Map<Task, Period> map) {
		this.map = map;
	}
	public double getAvailTime() {
		return availTime;
	}
	public void setAvailTime(double availTime) {
		this.availTime = availTime;
	}
	
	/**
	 * 根据VM类型初始化该VM
	 * @param type
	 */
	public void initByVMType(MyVMType type) {
		this.processSpeed = type.getProcessSpeed();
		this.rentUnitTime = type.getRentUnitTime();
		this.rentUnitPrice = type.getRentUnitPrice();
	}
	
}
