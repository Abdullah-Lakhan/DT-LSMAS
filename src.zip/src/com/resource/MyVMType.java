package com.resource;

/**
 * 虚拟机类型 用来表示公有云中的虚拟机
 * @author ShirleyLee
 *
 */
public class MyVMType {
	private double processSpeed; // 处理速度，每秒多少指令数
	private String rentUnitTime; // 租赁单位时间
	private double rentUnitPrice; // 租赁单位成本
	
	// 构造方法
	public MyVMType() {}
	public MyVMType(double processSpeed, String rentUnitTime, double rentUnitPrice) {
		super();
		this.processSpeed = processSpeed;
		this.rentUnitTime = rentUnitTime;
		this.rentUnitPrice = rentUnitPrice;
	}
	
	// getter,setter
	public double getProcessSpeed() {
		return processSpeed;
	}
	public void setProcessSpeed(double processSpeed) {
		this.processSpeed = processSpeed;
	}
	public String getRentUnitTime() {
		return rentUnitTime;
	}
	public void setRentUnitTime(String rentUnitTime) {
		this.rentUnitTime = rentUnitTime;
	}
	public double getRentUnitPrice() {
		return rentUnitPrice;
	}
	public void setRentUnitPrice(double rentUnitPrice) {
		this.rentUnitPrice = rentUnitPrice;
	}
	
	
}
