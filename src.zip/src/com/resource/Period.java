package com.resource;

/**
 * 表示任务的开始执行时间和结束执行时间的类
 * @author ShirleyLee
 *
 */
public class Period {
	private double startTime;  // Task开始时间
	private double endTime; // Task结束时间
	
	public Period() {
		super();
	}
	public Period(double startTime, double endTime) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public double getStartTime() {
		return startTime;
	}
	public void setStartTime(double startTime) {
		this.startTime = startTime;
	}
	public double getEndTime() {
		return endTime;
	}
	public void setEndTime(double endTime) {
		this.endTime = endTime;
	}
	
	
}
