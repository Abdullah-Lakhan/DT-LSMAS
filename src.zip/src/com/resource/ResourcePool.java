package com.resource;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Log;

import com.application.Task;

/**
 * @Author Ivan 14:30 2019/12/3
 *
 * @Description TODO 虚拟机的资源池，用于管理、创建和销毁虚拟机资源
 */
public class ResourcePool {

	// 虚拟机的总数
	private int vmCount;

	// 虚拟机的所有类型
	private List<VmType> types;

	// 释放的虚拟机集合（空闲状态）
	private List<VM> vmReleasedList;

	// 租赁的虚拟机集合
	private List<VM> vmLeasingList;

	public ResourcePool(List<VmType> types) {
		vmCount = 0;
		this.types = new ArrayList<VmType>(types);
		vmReleasedList = new ArrayList<>();
		vmLeasingList = new ArrayList<>();
	}

	public void setTypes(List<VmType> types) {
		this.types = types;
	}

	public List<VmType> getTypes() {
		return types;
	}

	public int getVmCount() {
		return vmCount;
	}

	public List<VM> getVmReleasedList() {
		return vmReleasedList;
	}

	public List<VM> getVmLeasingList() {
		return vmLeasingList;
	}

	// 根据类型租赁新的虚拟机
	public VM leaseNewVm(VmType rentVmType, int BTU) {
		vmCount++;
		VM vm = new VM(rentVmType, vmCount);
		vm.setLeaseBTU(BTU);
		vmLeasingList.add(vm); // 添加新租赁VN到资源池中
		Log.printLine("VM numOfJob" + vm.getVmId() + " is lease on " + BTU + "th BTU.");
		return vm;
	}

	/**
	 * 根据任务资源量和开始时间，确认VM在当前时刻是否可用
	 * @param task
	 * @param startTime ？？？
	 * @return
	 */
	public List<VM> getEligibleVms(Task task, double startTime) {
		List<VM> eligibleVms = new ArrayList<>();
		// 初始化可用VM列表
		for (VM vm : getVmLeasingList()) {
			if (startTime < task.AST) {
				eligibleVms.add(vm);
			}
		}
		return eligibleVms;
	}

	// 将任务task放置到虚拟机VM上执行
	public void placeTaskOnVm(Task task, VM eligibleVm) {
		// 计算任务执行时间
		double runTime = task.durationOnVM(eligibleVm);
		task.AFT = task.AST + runTime;
		eligibleVm.setBusy(true);
		Log.printLine("Task " + task.taskid + " running on type:" + eligibleVm.getType().getName() + " id:"
				+ eligibleVm.getVmId());
		// 未更新VM的最新可用时间？
	}

	/**
	 * 释放在第l个租赁周期结束时 闲置的Vm实例
	 *
	 * @Param
	 * @Return
	 */
	public void releaseIdleVm(int BTU) {

		Iterator<VM> it = vmLeasingList.iterator();

		while (it.hasNext()) {
			VM vm = it.next();
			if (vm.isBusy()) {
				it.remove();
				vm.setReleaseBTU(BTU);
				vm.setBusy(false);
				vmReleasedList.add(vm);
				Log.printLine("VM numOfJob " + vm.getVmId() + " is release on " + BTU + "th BTU.");
			}

		}
	}

	private int getRandom(int min, int max) {
		return new Random().nextInt(max - min + 1) + min;
	}

	/**
	 * 根据相应的策略选择可用的虚拟机
	 */

	public VM selectEligibleVm(Task task, List<VM> eligibleVms, double startTime, int rule) {
		int index = 0;
		switch (rule) {

		case 1: {
			// 后续编写

		}
		case 2: {
			// 后续编写

		}
		// 随机获取一个虚拟机
		default: {
			index = getRandom(0, eligibleVms.size() - 1);
		}
		}
		return eligibleVms.remove(index);
	}

	/**
	 * 计算租赁的费用
	 * @return
	 */
	public double getTotalCost() {
		double cost = 0;
		for (VM vm : getVmReleasedList()) {
			// 计算租赁的单位时间长度
			int numBUT = vm.getReleaseBTU() - vm.getLeaseBTU() + 1;
			cost += numBUT * vm.getType().getPrice_unit();
		}
		return cost;
	}

	/**
	 * 重置资源池
	 */
	public void reset() {
		vmLeasingList.clear();
		vmReleasedList.clear();
		vmCount = 0;
	}

}
