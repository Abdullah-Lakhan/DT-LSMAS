package com.resource;

/**
 * @Author Ivan 9:28
 * @Description TODO
 */
public class VM {
    private VmType type;

    private int vmId;

    private boolean leased;

    private boolean isBusy;

    private int leaseBTU;

    private int releaseBTU;

    public VM() {}
    
    public VM(VmType type, int vmId) {
        this.type = type;
        this.vmId = vmId;
        isBusy = false;
    }

    public boolean isBusy() {
        return isBusy;
    }

    public void setBusy(boolean busy) {
        isBusy = busy;
    }
    
    public VmType getType() {
        return type;
    }

    public int getVmId() {
        return vmId;
    }

    public boolean isLeased() {
        return leased;
    }

    public int getLeaseBTU() {
        return leaseBTU;
    }

    public int getReleaseBTU() {
        return releaseBTU;
    }

    public void setType(VmType type) {
        this.type = type;
    }

    public void setVmId(int vmId) {
        this.vmId = vmId;
    }

    public void setLeased(boolean leased) {
        this.leased = leased;
    }

    public void setLeaseBTU(int leaseBTU) {
        this.leaseBTU = leaseBTU;
    }

    public void setReleaseBTU(int releaseBTU) {
        this.releaseBTU = releaseBTU;
    }
}
