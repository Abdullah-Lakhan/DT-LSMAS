package com.resource;

import com.constant.NodeType;

/**
 * @Author Ivan 15:13
 * @Description TODO
 */
public class VmType {

    private final int id;

    private final double process_rate;

    private final String name;

    private final double price_unit;

    public VmType(int id) {
       this.id = id;
       if (id == 1){
           process_rate = NodeType.PROCESS_RATE_1;
           name = "high";
           price_unit = NodeType.PRICE_HIGH_LELVEL;
       }else if (id == 2){
           process_rate = NodeType.PROCESS_RATE_2;
           name = "mid";
           price_unit = NodeType.PRICE_MID_LEVLEL;
       }else {
           process_rate = NodeType.PROCESS_RATE_3;
           name = "low";
           price_unit = NodeType.PRICE_LOW_LEVLEL;
       }
    }

    public int getId() {
        return id;
    }

    public double getProcess_rate() {
        return process_rate;
    }

    public String getName() {
        return name;
    }

    public double getPrice_unit() {
        return price_unit;
    }

    @Override
    public String toString() {
        return "VmType{" +
                "id=" + id +
                ", process_rate=" + process_rate +
                ", name='" + name + '\'' +
                ", price_unit=" + price_unit +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VmType vmType = (VmType) o;

        return id == vmType.id;
    }

    @Override
    public int hashCode() {
        return id;
    }
}
