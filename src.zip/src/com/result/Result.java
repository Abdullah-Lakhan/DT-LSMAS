package com.result;

/**
 * 算法调度结果类
 * @author ShirleyLee
 *
 */
public class Result {
	public int jobNumber;
	public double theta; // 截止期设置
	public int privateNumber; // 私有云中机器数量
	public int instance; // Spark应用数量
	public String SD;
	public String SS;
	public String RSS;
	public String PSS;
	public String Algorithm;
	public double makespan;
	public double cost;
	public double RPD;
	public double runtime;
	
	
	
	@Override
	public String toString() {
		return "Result [jobNumber=" + jobNumber + ", theta=" + theta + ", privateNumber=" + privateNumber
				+ ", instance=" + instance + ", SD=" + SD + ", SS=" + SS + ", RSS=" + RSS + ", PSS=" + PSS
				+ ", Algorithm=" + Algorithm + ", makespan=" + makespan + ", cost=" + cost + ", RPD=" + RPD
				+ ", runtime=" + runtime + "]";
	}

	// 参数校正
	public Result(int jobNumber, double theta, int privateNumber, int instance, int SD, int SS, int RSS,
			int PSS, double makespan, double cost, double runtime) {
		super();
		this.jobNumber = jobNumber;
		this.theta = theta;
		this.privateNumber = privateNumber;
		this.instance = instance;
		switch (SD) {
		case 1:
			this.SD = "SD1";
			break;
		case 2:
			this.SD = "SD2";
			break;
		case 3:
			this.SD = "SD3";
			break;
		default:
			break;
		}
		switch (SS) {
		case 1:
			this.SS = "SS1";
			break;
		case 2:
			this.SS = "SS2";
			break;
		case 3:
			this.SS = "SS3";
			break;
		default:
			break;
		}
		switch (RSS) {
		case 1:
			this.RSS = "RSS1";
			break;
		case 2:
			this.RSS = "RSS2";
			break;
		case 3:
			this.RSS = "RSS3";
			break;
//		case 4:
//			this.RSS = "RSS4";
//			break;
		default:
			break;
		}
		switch (PSS) {
		case 1:
			this.PSS = "PSS1";
			break;
		case 2:
			this.PSS = "PSS2";
			break;
		case 3:
			this.PSS = "PSS3";
			break;
		default:
			break;
		}
		this.makespan = makespan;
		this.cost = cost;
		this.runtime = runtime;
	}
	
	// 算法比较
	public Result(int jobNumber, double theta, int privateNumber, int instance, int algorithm, double makespan,
			double cost, double runtime) {
		super();
		this.jobNumber = jobNumber;
		this.theta = theta;
		this.privateNumber = privateNumber;
		this.instance = instance;
		switch (algorithm) {
		case 1:
			this.Algorithm = "RBSAS";
			break;
		case 2:
			this.Algorithm = "IHEFT";
//			this.Algorithm = "HEFT";
			break;
		case 3:
			this.Algorithm = "HCOC";
//			this.Algorithm = "FAIR";
			break;
		default:
			break;
		}
		this.makespan = makespan;
		this.cost = cost;
		this.runtime = runtime;
	}
	
	
	
	
	
}
