package com.utils;

import org.junit.Test;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;

/**
 * <h1>生成 Spark 应用工具�?</h1>
 *  不使用
 * Created by DHA on 2019/11/30.
 */
public class ApplicationUtils {

	public static SparkApplication generateSparkApplication() {
		SparkApplication sparkApp = null;
		try {
			sparkApp = new SparkApplication();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (sparkApp == null) {
			System.out.println("创建 Spark 应用失败");
		}
		return sparkApp;
	}

	@Test
	/* 测试生成�? Spark 工作�? */
	public void test() throws Exception {
		SparkApplication app = generateSparkApplication();
		System.out.println("Job num:" + app.jobNum);
		for (Job job : app.jobList) {
			System.out.println("jobId:" + job.jobid + ", num of stage: " + job.stageList.size());
			for (Stage stage : job.stageList) {
				for (Task task : stage.taskList) {
					System.out.println("taskId: " + task.taskid + " data size: " + task.totalInputData);
				}
			}
			System.out.println("====================");
		}
	}
}
