package com.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;
import com.constant.Constant;
import com.resource.MyResourcePool;
import com.resource.MyVM;
import com.resource.MyVMType;

/**
 * 计算参数的工具类
 * @author ShirleyLee
 *
 */
public class CalParaUtils {
	
	
	
	/**
	 * 计算截止期：工作流的最早完工时间 = 最后一个Job的最早完工时间EFT，如果有多个endJob，则取EFT最大的一个
	 * @return
	 */
	public static double calDeadline(SparkApplication app) {
		// TODO 
		Set<Job> jobList = app.getEndJob();
		double maxEFT = Double.MIN_VALUE;
		for(Job job : jobList) {
			maxEFT = Math.max(maxEFT, job.EFT);
		}
		// 设置截止期 TODO：需要设置截止期为x倍的maxEFT
		app.setDeadline(maxEFT);
		app.setEFT(maxEFT);
		return maxEFT;
	}
	
	/**
	 * 设置SparkApp的截止期
	 * @param app
	 */
	public static void setDeadline(SparkApplication app) {
		double[] times = Constant.TIME_OF_DEADLINE;
		//  TODO
		
	}
	
	/**
	 * 估算各种时间参数
	 * @param app
	 */
	public static void calTimeParamters(SparkApplication app, MyResourcePool resourcePool) {
		// TODO 
		// 0.  估计资源池中虚拟机的执行速度
		double speed = 0;
		int count = 0;
		List<MyVM> privateCloud = resourcePool.getPrivateCloud();
		List<MyVMType> publicCloud = resourcePool.getPublicVMType();
		for(int i = 0; i < privateCloud.size(); i++) {
			speed += privateCloud.get(i).getProcessSpeed();
			count++;
		}
		for(int i = 0; i < publicCloud.size(); i++) {
			speed += publicCloud.get(i).getProcessSpeed();
			count++;
		}
		double averageSpeed = speed / count;
		// 0.5 计算平均传输速率
		double averageTransferSpeed = (Constant.BANDWIDTH_INTER + Constant.BANDWIDTH_INTRA) / 2;
		
		// 1. 估计任务的处理时间 = 任务执行时间 + 数据传输时间
		List<Job> jobList = app.jobList;
		for(int i = 0; i < jobList.size(); i++) {
			Job job = jobList.get(i);
			List<Stage> stageList = job.stageList;
			for(int j = 0; j < stageList.size(); j++) {
				Stage stage = stageList.get(j);
				List<Task> taskList = stage.taskList;
				for(int k = 0; k < taskList.size(); k++) {
					Task task = taskList.get(k);
					task.setEstimateProcessTime(task.instructions / averageSpeed);
					// 估算数据传输时间
					double transferTime = 0;
					List<Task> preTask = new ArrayList<Task>(task.getPrecursorTask().keySet());
					for(int m = 0; m < preTask.size(); m++) {
						Task pre = preTask.get(m);
						transferTime = Math.max(transferTime, task.getPrecursorTask().get(pre) / averageTransferSpeed);
					}
					task.setEstimateTotalTime(task.getEstimateProcessTime() + transferTime);
				}
			}
		}
		
		// 1.5 估计Stage的处理时间 = max{其中Task的执行时间}
		for(int i = 0;i < jobList.size(); i++) {
			Job job = jobList.get(i);
			List<Stage> stageList = job.stageList;
			for(int j = 0; j < stageList.size(); j++) {
				Stage stage = stageList.get(j);
				for(int k = 0; k < stage.taskList.size(); k++) {
					Task task = stage.taskList.get(k);
					stage.estimateDuration = Math.max(stage.estimateDuration, task.getEstimateTotalTime());;
				}
			}
		}
		
		// 2. 估计Job，Stage的EST，EFT
		for(int i = 0;i < jobList.size(); i++) {
			Job job = jobList.get(i);
			// 2.1 估计该Job的EST
			if(job.parentJobs == null || job.parentJobs.size() == 0) {
				job.EST = 0; // 即第一个Job的EST=0
			}else {
				for(int m = 0; m < job.parentJobs.size(); m++) {
					job.EST = Math.max(job.EST, job.parentJobs.get(m).EFT);
				}
			}
			double maxEFT = 0;
			// 2.2 估计Stage的EST,EFT
			List<Stage> stageList = job.stageList;
			for(int j = 0; j < stageList.size(); j++) {
				Stage stage = stageList.get(j);
				if(stage.parentStages == null || stage.parentStages.size() == 0) {
					stage.EST = stage.job.EST;
				}else {
					for(int m = 0; m < stage.parentStages.size(); m++) {
						stage.EST = Math.max(stage.EST, stage.parentStages.get(m).EFT);
					}
				}
				stage.EFT = stage.EST + stage.estimateDuration;
				maxEFT = Math.max(maxEFT, stage.EFT);
			}
			job.EFT = maxEFT;
		}
		
		// 3.估计Job，Stage的LST，LFT
		List<Job> reverseJobList = app.reverseJobList;
		double deadline = app.getDeadline(); 
		for(int i = 0; i < reverseJobList.size(); i++) {
			Job job = reverseJobList.get(i);
			// 如果没有后继Job
			if(job.childJobs == null || job.childJobs.size() == 0) {
				job.LFT = deadline;
			}else {
				for(int m = 0; m < job.childJobs.size(); m++) {
					job.LFT = Math.min(job.LFT, job.childJobs.get(m).LST);
				}
			}
			double minLST = Double.MAX_VALUE;
			// 估计其中Stage的LST，LFT
			List<Stage> reverseStageList = job.reverseStageList;
			for(int j = 0; j < reverseStageList.size(); j++) {
				Stage stage = reverseStageList.get(j);
				if(stage.childStages == null || stage.childStages.size() == 0) {
					stage.LFT = stage.job.LFT;
				}else {
					for(int m = 0; m < stage.childStages.size(); m++) {
						stage.LFT = Math.min(stage.LFT, stage.childStages.get(m).LST);
					}
					stage.LST = stage.LFT - stage.estimateDuration;
					minLST = Math.min(minLST, stage.LST);
				}
			}
			// Job的LST
			job.LST = minLST;
		}
	}
}
















