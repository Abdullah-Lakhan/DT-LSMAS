package com.utils;

import java.math.BigDecimal;

import org.junit.Test;

public class CalculateUtils {
	/**
	 * 两个double类型，比较大小
	 * @param d1
	 * @param d2
	 * @return 负值，d1<d2
	 */
	public static int compareDouble(double d1, double d2) {
//		if(d2 - d1  > Math.pow(10, -8)) {
//			return -1;
//		}else {
//			return 1;
//		}
		BigDecimal b1 = null;
		BigDecimal b2 = null;
		try {
			b1 = new BigDecimal(d1);
			b2 = new BigDecimal(d2);
		}catch(Exception e) {
			System.out.println(d1);
			System.out.println(d2);
			e.printStackTrace();
		}
		return b1.compareTo(b2);
	}
	
	@Test
	public void test() {
		System.out.println(1.222221 - 1.222220  > Math.pow(10, -10));
	}
	
}
