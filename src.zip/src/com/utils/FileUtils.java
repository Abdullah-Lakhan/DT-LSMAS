package com.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.workflowsim.utils.Parameters;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.simulation.app.Application;
import com.simulation.app.CyberShake;
import com.simulation.app.Montage;

/**
 * <h1>文件解析工具类</h1> 根据生成的文件来解析生成的工作流
 *
 * Created by DHA on 2019/11/30.
 */
public class FileUtils {

	/* 用于存放工作流的目录 */
	private static final String appDir = "E:\\paper\\data\\";
	// private static final String jobDir = "E:\\paper\\data\\app";

	/**
	 * 
	 * 解析 app.xml 文件 构建该 SparkApplication 中 Job 层面的 DAG
	 * 
	 * @param sparkApp
	 * @throws Exception
	 */
	public static void parseAppFile(SparkApplication sparkApp) throws Exception {
		Map<String, Job> mName2Job = new HashMap<>();
		SAXBuilder builder = new SAXBuilder();
		// 测试代码：解析指定文件
		// String filename = appFile(sparkApp);
		String filename = appDir + "/app0.xml";
		// file文件即app.xml文件
		File file = new File(filename);
		// 解析xml文件
		Document dom = builder.build(file);
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		// 对Job编号
		int jobId = 0;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job":
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Job job;
				synchronized (sparkApp) {
					// 每个Job是关于DAG偏序关系Stage组成
					job = new Job(jobId, sparkApp.instance);
					jobId++;
				}
				mName2Job.put(nodeName, job);
				sparkApp.jobList.add(job);
				break;
			case "child":
				// 建立Job间偏序关系
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Job.containsKey(childName)) {
					Job childJob = (Job) mName2Job.get(childName);
					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Job.containsKey(parentName)) {
							Job parentJob = (Job) mName2Job.get(parentName);
							parentJob.addEdge(childJob);
						}
					}
				}
				break;
			}
		}
		mName2Job.clear();
	}

	/**
	 * <h2>创建 app.xml 文件</h2> 文件中包含该 Applicaiton 中 Job 的偏序关系
	 * 
	 * @param sparkApp
	 * @throws Exception
	 */
	private static String appFile(SparkApplication sparkApp) throws Exception {
		// 生成工作流
		Application app = generateWorkflow(sparkApp.jobNum);

		File file = new File(appDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		String fileName = appDir + "/app" + sparkApp.instance + ".xml";
		file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		// 将生成的工作流保存到xml文件
		app.printWorkflow(new FileOutputStream(file));
		return fileName;
	}

	/**
	 * <h2>解析 job.xml 文件</h2> 构建该 Job 中 Stage 层面的 DAG
	 * 
	 * @param job
	 * @param instance Job所在SparkApplication的编号
	 * @throws Exception
	 */
	public static void parseJobFiles(Job job, int instance) throws Exception {
		Map<String, Stage> mName2Stage = new HashMap<>();
		SAXBuilder builder = new SAXBuilder();
		// 生成Job对应的工作流文件
		// String filename = jobFiles(job, instance);
		// 测试使用：解析指定Job文件
		String filename = appDir + "app" + instance + "/job" + job.jobid + ".xml";
		File file = new File(filename);
		// 解析文件
		Document dom = builder.build(file);
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		int stageId = 0;
		// List<Server> serverList=job.dc.serverList;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job":
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Stage stage;
				synchronized (job) {
					stage = new Stage(stageId, job);
					stageId++;
				}
				mName2Stage.put(nodeName, stage);
				// job 的 stageList 中添加 stage
				job.stageList.add(stage);
				break;
			case "child":
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Stage.containsKey(childName)) {

					Stage childStage = (Stage) mName2Stage.get(childName);
					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Stage.containsKey(parentName)) {
							Stage parentStage = (Stage) mName2Stage.get(parentName);
							// 添加偏序关系
							parentStage.addEdge(childStage);
						}
					}
				}
				break;
			}
		}

		// 设定一部分stage依赖不可移动数据
		/*
		 * int dcId = dcList.size(); HashSet<Stage> startStages = job.getStartStage();
		 * for(Stage stage:startStages){ if(RamdomNumberUtils.getRandomNumber(0, 1) ==
		 * 0){ stage.dc = dcList.get(RamdomNumberUtils.getRandomNumber(0,dcId-1)); } }
		 */
		mName2Stage.clear();
	}

	/**
	 * <h2>创建 job.xml 文件</h2> 文件中包括该 job 中 Stage 的偏序关系
	 * 
	 * @param job      @link Job}
	 * @param instance Job所在SparkApplication的编号
	 * @return 返回该 job 对应的 xml 文件
	 * @throws Exception
	 */
	private static String jobFiles(Job job, int instance) throws Exception {
		Application app = generateWorkflow(job.stageNum);

		// 获得Job文件xml路径
		// 生成指定路径的File（与app序号instance有关，便于多组实验数据生成
		String jobDir = appDir + "app" + instance;
		File file = new File(jobDir);
		if (!file.exists()) {
			file.mkdirs();
		}
		String fileName = jobDir + "/job" + job.jobid + ".xml";
		file = new File(fileName);
		if (!file.exists()) {
			file.createNewFile();
		}
		app.printWorkflow(new FileOutputStream(file));
		return fileName;
	}

	/**
	 * <h2>生成传统工作流</h2> 我们这里是通过传统工作流来创建 Stage 偏序关系和 Job 偏序关系
	 * 
	 * @param number 工作流中包含的任务数
	 * @return
	 */
	private static Application generateWorkflow(int number) throws Exception {
		String[] args = { "-a", "Montage", "-n", String.valueOf(number) };
		String[] newArgs = Arrays.copyOfRange(args, 2, args.length);

		/* 工作流实例采用 WorkflowSim 随机生成，共包含两种类型的工作流：Montage 和 CyberShake */
		// 这里可以添加其他类型的工作流生成模式：Genome, LIGO, SIPHT.
		Application app;
		if (RandomNumberUtils.getRandomNumber(1, 2) == 1) {
			app = new CyberShake();
		} else {
			app = new Montage();
		}
		app.generateWorkflow(newArgs);
		return app;
	}
}
