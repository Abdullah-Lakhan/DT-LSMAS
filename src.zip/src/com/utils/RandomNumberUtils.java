package com.utils;

import java.util.Random;

/**
 * <h1> 生成随机数的工具�? </h1>
 *
 * Created by DHA on 2019/11/28.
 */
public class RandomNumberUtils {

    private RandomNumberUtils(){}

    /**
     * <h2> 产生在[min,max] 之间的随机数 </h2>
     * @param min
     * @param max
     * @return
     */
    public static int getRandomNumber(int min, int max){
        Random random = new Random();
        return (random.nextInt(max - min + 1) + min);
    }

}
