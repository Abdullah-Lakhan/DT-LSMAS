package com.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.workflowsim.utils.Parameters;

import com.application.Job;
import com.application.SparkApplication;
import com.application.Stage;
import com.application.Task;

/**
 * <h1>解析 app 文件，生成 App 应用</h1> Created by DHA on 2019/12/11.
 */
public class SparkAppUtils {

	private SparkAppUtils() {

	}

	/**
	 * 生成SparkApplication
	 * 
	 * @param appId    sparkapp的序号
	 * @param pathName 根路径，选择是cyber类型的工作流，或montage类型的工作流
	 * @return
	 */
	public static SparkApplication getSparkApp(int appId, String pathName) {
		// 获得SparkAppliation对象
		SparkApplication sparkApp = sparkApp(appId, pathName);
		return sparkApp;
	}

	private static SparkApplication sparkApp(int appId, String pathName) {
		SparkApplication sparkApp = new SparkApplication();
		sparkApp.instance = appId; // 序号赋值
		// int numOfJob= Constants.NUM_OF_JOBS[appId];
		// 解析指定文件
		File appFile = new File(pathName, "/app_" + appId + ".xml");

		try {
			// 构建 SparkApplication 中关于 Job 的 DAG，实际上就是解析 app_*.xml 文件
			parseAppFile(sparkApp, appFile);
			sparkApp.jobNum = sparkApp.jobList.size();

			// app_* 目录：即生成该App对应的Job文件目录
			File appDir = new File(pathName, "/app_" + appId);

			File[] files = appDir.listFiles(); // 列举该文件夹中所有文件
			List<Job> jobList = sparkApp.jobList;
			// 解析Job文件，job.xml文件
			if (files != null) {
				for (File file : files) {
					String fileName = file.getName();
					if (fileName.endsWith(".xml")) { // job_*.xml 文件
						int startIndex = fileName.indexOf("_");
						int endIndex = fileName.indexOf(".");
						int jobId = Integer.parseInt(file.getName().substring(startIndex + 1, endIndex));

//						System.out.println("files文件夹中文件个数："+files.length);
//						if (jobId == files.length - 1) {
//							break;
//						}
 
						Job job = jobList.get(jobId);

						// 构建 Job 中关于 Stage 的 DAG，实际上就是解析 job_*.xml 文件，获得Stage间的拓扑关系
						parseJobFile(job, file);

					}
				}
				// 解析Stage文件：获得Task信息
				for (File file : files) {
					if (file.isDirectory()) { // job_* 文件夹，如果是文件夹
						int startIndex = file.getName().indexOf("_");
						int jobId = Integer.parseInt(file.getName().substring(startIndex + 1));

						Job job = jobList.get(jobId);

						// 获得该文件夹下文件
						File[] fileArr = file.listFiles();
						// numOfStage
						job.stageNum = fileArr.length;
						// 遍历文件：stage_*.txt，解析其中的Task
						for (File f : fileArr) { // 解析 stage_*.txt 文件
							parseStageFile(job, f);
						}
						// 获得Job中Stage的拓扑排序
						job.topoSort();
					}
				}

			}
		} catch (Exception e) {
			System.out.println("创建应用失败！");
			e.printStackTrace();
		}
		// 拓扑排序
		sparkApp.topoSort();
		// 建立Task间偏序关系及数据传输量
		for (Job job : sparkApp.jobList) {
			for (Stage stage : job.stageList) {
				stage.generateInputData();
			}
		}
		return sparkApp;
	}

	/**
	 * 解析Stage文件
	 * 
	 * @param job
	 * @param f
	 * @throws IOException
	 */
	private static void parseStageFile(Job job, File f) throws IOException {
		String fName = f.getName();
		int start = fName.indexOf("_");
		int end = fName.indexOf(".");
		int stageId = Integer.parseInt(fName.substring(start + 1, end));
		// 获得
		// TODO
		Stage stage = null;
		try {
			stage = job.stageList.get(stageId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(new FileReader(f));
		String line = br.readLine();
		int numOfTask = Integer.parseInt(line);
		// numOfTask
		stage.taskNum = numOfTask;
		while ((line = br.readLine()) != null) {
			String[] arr = line.trim().split(",");
			int taskId = Integer.parseInt(arr[0]);
			double instrcutions = Double.parseDouble(arr[1]);
			stage.taskList.add(new Task(taskId, instrcutions, stage));
		}
		br.close();

	}

	/**
	 * <h2>解析 app_*.xml 文件</h2> 创建Job对象及偏序关系
	 * 
	 * @param SparkApplication
	 * @param appFile
	 * @throws Exception
	 */
	private static void parseAppFile(SparkApplication sparkApp, File appFile) throws Exception {
		Map<String, Job> mName2Job = new HashMap<>();
		SAXBuilder builder = new SAXBuilder();
		// 解析 xml 文件
		Document dom = builder.build(appFile);
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		int jobId = 0;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job":
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Job job;
				synchronized (sparkApp) {
					// 每个Job是关于DAG偏序关系Stage组成
					// 创建单个Job
					job = new Job(jobId, sparkApp.instance);
					jobId++;
				}
				mName2Job.put(nodeName, job);
				sparkApp.jobList.add(job);
				break;
			case "child":
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Job.containsKey(childName)) {
					Job childJob = (Job) mName2Job.get(childName);
					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Job.containsKey(parentName)) {
							Job parentJob = (Job) mName2Job.get(parentName);
							parentJob.addEdge(childJob);
						}
					}
				}
				break;
			}
		}
		mName2Job.clear();
	}

	/**
	 * <h2>解析 job_*.xml 文件</h2> 构建该 Job 中 Stage 层面的 DAG 实例化Stage对象，并建立Stage间偏序关系
	 * 
	 * @param job
	 * @throws Exception
	 */
	private static void parseJobFile(Job job, File jobFile) throws Exception {
		Map<String, Stage> mName2Stage = new HashMap<String, Stage>();
		SAXBuilder builder = new SAXBuilder();
		Document dom = builder.build(jobFile);
		Element root = dom.getRootElement();
		List<Element> list = root.getChildren();
		int stageId = 0;
		// List<Server> serverList=job.dc.serverList;
		for (Element node : list) {
			switch (node.getName().toLowerCase()) {
			case "job":
				String nodeName = node.getAttributeValue("id");
				Parameters.getRuntimeScale();
				Stage stage;
				synchronized (job) {
					stage = new Stage(stageId, job);
					stageId++;
				}
				mName2Stage.put(nodeName, stage);
				// job 的 stageList 中添加 stage
				job.stageList.add(stage);
				break;
			case "child":
				List<Element> pList = node.getChildren();
				String childName = node.getAttributeValue("ref");
				if (mName2Stage.containsKey(childName)) {

					Stage childStage = (Stage) mName2Stage.get(childName);
					for (Element parent : pList) {
						String parentName = parent.getAttributeValue("ref");
						if (mName2Stage.containsKey(parentName)) {
							Stage parentStage = (Stage) mName2Stage.get(parentName);
							parentStage.addEdge(childStage);
						}
					}
				}
				break;
			}
		}
		mName2Stage.clear();
	}

	/**
	 * 根据文件名，解析app文件
	 * 
	 * @param fileName，格式：绝对路径/app_0.xml
	 * @return
	 */
	public static SparkApplication getSparkApp(String fileName) {
		// 获得SparkAppliation对象
		int startIndex = fileName.lastIndexOf("_");
		int endIndex = fileName.indexOf(".");
		int appID = Integer.parseInt(fileName.substring(startIndex + 1, endIndex));
		String pathName = fileName.substring(0, startIndex - 4);
		SparkApplication sparkApp = sparkApp(appID, pathName);
		return sparkApp;
	}
}
